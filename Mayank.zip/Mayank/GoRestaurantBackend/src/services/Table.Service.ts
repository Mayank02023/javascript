import mongoose from "mongoose";
import { ITable } from "../models/Table.model";
import tableRepository from "../repositories/Table.Repository";
import { ApiError } from "../utils";
import { IPagination } from "../types/Comman.Interface";
import { handlePagination } from "../utils/preparePaginationOptions";

class TableService {
    async addTable(tableData: Partial<ITable>): Promise<ITable> {
        const table = await tableRepository.createTable(tableData);
        if (!table) throw ApiError.internal("Add table process has been failed!.");
        return table;
    }

    async getTableById(tableId: string): Promise<ITable> {
        const table = await tableRepository.getTableById(tableId);
        if (!table) throw ApiError.notFound("Table not found!.");
        return table;
    }

    async getTables(branchId: string, queryOptions: any): Promise<ITable[]> {
        const { page = 1, limit = 2, status } = queryOptions;
        const query: any = {};
        if (branchId) query.branchId = new mongoose.Types.ObjectId(branchId);
        if (status) query.status = status;

        const pagination: IPagination = handlePagination(page, limit);

        const tables = await tableRepository.findTables(query, pagination);
        if (!tables) throw ApiError.notFound("Tables data not found!.");

        return tables;
    }

    async updateTableById(tableId: string, tableData: Partial<ITable>): Promise<ITable> {
        const table = await tableRepository.updateTableById(tableId, tableData);
        if (!table) throw ApiError.notFound("Table update process has been failed!.");
        return table;
    }

    async deleteTableById(tableId: string): Promise<boolean> {
        const table = await tableRepository.deleteTableById(tableId);
        if (!table) throw ApiError.notFound("Table delete process has been failed!.");
        return table;
    }
}

const tableService = new TableService();
export default tableService