import { ApiError } from "../utils";
import Razorpay from "razorpay";
import envConfig from "../config/envConfig";
import crypto from "crypto";
import orderService from "./OrderService";

class PaymentService {
    private razorpay: Razorpay;

    constructor() {
        this.razorpay = new Razorpay({
            key_id: envConfig.RAZORPAY_KEY_ID,
            key_secret: envConfig.RAZORPAY_KEY_SECRET
        });
    }

    public async createOrder(amount: number = 10, currency: string = "INR"): Promise<any> {
        const options = {
            amount: amount * 100,
            currency
        };

        const order = await this.razorpay.orders.create(options);

        if (!order) throw ApiError.conflict("Unknown error occurred.");

        return order;
    }


    public async verifyPayment(paymentData: any): Promise<boolean> {
        const {
            razorpay_order_id: order_id,
            razorpay_payment_id: payment_id,
            razorpay_signature: signature,
            orderId } = paymentData;

        const sign = order_id + "|" + payment_id;

        // Create ExpectedSign
        const generated_signature = crypto.createHmac("sha256", envConfig.RAZORPAY_KEY_SECRET)
            .update(sign.toString())
            .digest("hex");
        if (generated_signature === signature) {
            {

                const paymentDetails = {
                    orderId: order_id,
                    paymentId: payment_id,
                    signature
                }
                orderService.updateOrder(orderId, { paymentMethod: "ONLINE", paymentDetails })

            }
            return true; // Payment is verified
        } else {
            return false;
        }
    }
}

const paymentService = new PaymentService();
export default paymentService;
