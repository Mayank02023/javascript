import { ApiError } from "../utils";
import menuCategoryRepository from "../repositories/MenuCategory.Repository";
import mongoose from "mongoose";
import { IMenuCategory } from "../models/MenuCategory.Model";
import { IPagination } from "../types/Comman.Interface";
import { IMenuCategoryRequest } from "../types/Request.Interface";
import { handlePagination } from "../utils/preparePaginationOptions";

class MenuCategoryService {

    // Check if a user with the same  already exists
    private async isMenuCategoryExist(name: string): Promise<boolean> {
        const existingUser = await menuCategoryRepository.model.findOne({ name });
        return !!existingUser;
    }
    // Add a new category
    async addMenuCategory(branchId: string, menuCategoryData: IMenuCategoryRequest): Promise<IMenuCategory> {
        const { name } = menuCategoryData;

        // Check if category already exists
        const existingCategory = await this.isMenuCategoryExist(name);
        if (existingCategory) {
            throw ApiError.conflict("Category with this name already exists.");
        }

        // Create and save the new category
        const newCategory = await menuCategoryRepository.addMenuCategory({
            ...menuCategoryData,
            branchId: new mongoose.Types.ObjectId(branchId)
        });
        if (!newCategory) {
            throw ApiError.internal("Category creation failed.");
        }

        return newCategory;
    }

    // Add multiple categories at once
    async addManyMenuCategories(branchId: string, menuCategoriesData: IMenuCategoryRequest[]): Promise<{ status: boolean; message: string }> {
        // Track errors for existing categories
        const existingCategories: string[] = [];
        let message = "Multiple menu categories added successfully";

        // Process each category and check if it already exists
        const processedMenuCategories: Partial<IMenuCategory>[] = [];

        for (const item of menuCategoriesData) {
            const { name, description } = item;

            // Check if the category already exists
            const existingCategory = await this.isMenuCategoryExist(name);

            if (existingCategory) {
                existingCategories.push(name);
            } else {
                const menuCategory = new menuCategoryRepository.model({
                    branchId: new mongoose.Types.ObjectId(branchId),
                    name,
                    description
                });
                processedMenuCategories.push(menuCategory);
            }
        }

        if (processedMenuCategories.length === 0) {
            throw ApiError.conflict("All provided categories already exist. No new categories to add.");
        }

        // If there are any existing categories, throw an error with their names
        if (existingCategories.length > 0) {
            message = `Multiple menu categories added successfully. The following categories already exist and were not added again: ${existingCategories.join(", ")}.`;
        }

        // Proceed with adding the new categories
        const result = await menuCategoryRepository.addManyMenuCategories(processedMenuCategories);

        if (!result) {
            throw ApiError.internal("Bulk category creation failed.");
        }

        return { status: true, message };
    }

    // Get category by ID
    async getMenuCategoryById(menuCategoryId: string): Promise<IMenuCategory> {
        const category = await menuCategoryRepository.getMenuCategoryById(menuCategoryId);
        if (!category) throw ApiError.notFound("Category not found.");
        return category;
    }

    // Find categories based on pagination and query
    async findMenuCategories(branchId: string, queryOptions: any): Promise<IMenuCategory[]> {
        const { page, limit, name } = queryOptions;
        const pagination: IPagination = handlePagination(page, limit);

        const query: any = {
            branchId: new mongoose.Types.ObjectId(branchId),
        };

        if (name) query.name = { $regex: name, $options: 'i' };

        const categories = await menuCategoryRepository.getAllMenuCategories(query, pagination);
        if (!categories) {
            throw ApiError.notFound("No categories found.");
        }

        return categories;
    }

    // Update a category by ID
    async updateMenuCategory(menuCategoryId: string, menuCategoryData: Partial<IMenuCategory>): Promise<IMenuCategory> {
        const category = await menuCategoryRepository.getMenuCategoryById(menuCategoryId);
        if (!category) throw ApiError.notFound("Category not found.");

        const { name, description } = menuCategoryData;
        if (!name && !description) throw ApiError.badRequest("atleast one field to be passed: name or description ")
        if (name) category.name = name;
        if (description) category.description = description;

        const updatedCategory = await category.save();
        if (!updatedCategory) {
            throw ApiError.internal("Category update failed.");
        }

        return updatedCategory;
    }

    // delete a category by ID
    async deleteMenuCategory(menuCategoryId: string): Promise<boolean> {
        const result = await menuCategoryRepository.deleteCategory(menuCategoryId);
        if (!result) {
            throw ApiError.notFound("Category not found.");
        }
        return result;
    }

}

const menuCategoryService = new MenuCategoryService();
export default menuCategoryService;
