import mongoose from "mongoose";
import { IMenuItem } from "../models/MenuItem.model";
import menuRepository from "../repositories/Menu.Repository";
import { IMenuItemRequest } from "../types/Request.Interface";
import { ApiError, uploadFileService } from "../utils";
import { IPagination } from "../types/Comman.Interface";
import { handlePagination } from "../utils/preparePaginationOptions";

class MenuService {

    //Check if a user with the same  already exists
    private async isMenuExist(name: string): Promise<boolean> {
        const existingUser = await menuRepository.model.findOne({ name });
        return !!existingUser;
    }

    //Add a new menu item
    async addMenuItem(branchId: string, menuItemData: IMenuItemRequest): Promise<IMenuItem> {
        const { name } = menuItemData;

        //Check if menu item already exists
        const existingMenuItem = await this.isMenuExist(name);
        if (existingMenuItem) throw ApiError.conflict("Menu item with this name already exists.");

        const ingredients = menuItemData.ingredients.map((ingredient) =>
            new mongoose.Types.ObjectId(ingredient));
        // Check if an image file is provided and upload it to Cloudinary
        if (menuItemData.avatar) {
            const avatarUrl = await uploadFileService.uploadOnCloudinary(menuItemData.avatar);
            if (!avatarUrl) {
                throw ApiError.badRequest("Failed to upload avatar to Cloudinary");
            }
            menuItemData.avatar = avatarUrl?.url;
        }
        const menuPayload: Partial<IMenuItem> = {
            ...menuItemData,
            branchId: new mongoose.Types.ObjectId(branchId),
            categoryId: new mongoose.Types.ObjectId(menuItemData.categoryId),
            ingredients
        };

        //Create and save the new menu item
        const newMenuItem = await menuRepository.createMenuItem(menuPayload);
        if (!newMenuItem) {
            throw ApiError.internal("Menu item creation failed.");
        }

        return newMenuItem;
    }

    //Add multiple menu items at once
    async addManyMenuItems(branchId: string, menuItemsData: IMenuItemRequest[]): Promise<{ status: boolean; message: string }> {
        //Track errors for existing menu items
        const existingMenuItems: string[] = [];
        let message = "Multiple menu items added successfully";

        //Process each menu item and check if it already exists
        const processedMenuItems: Partial<IMenuItem>[] = [];

        for (const item of menuItemsData) {
            const { name } = item;

            //Check if the menu item already exists
            const existingMenuItem = await this.isMenuExist(name);

            if (existingMenuItem) {
                existingMenuItems.push(name);
            } else {
                const ingredients = item.ingredients.map((ingredient) =>
                    new mongoose.Types.ObjectId(ingredient));

                const menuPayload: Partial<IMenuItem> = {
                    ...item,
                    branchId: new mongoose.Types.ObjectId(branchId),
                    categoryId: new mongoose.Types.ObjectId(item.categoryId),
                    ingredients
                };

                processedMenuItems.push(menuPayload);
            }
        }

        //Create and save the new menu items
        const newMenuItems = await menuRepository.addManyMenuItems(processedMenuItems);
        if (!newMenuItems) {
            throw ApiError.internal("Menu items creation failed.");
        }

        if (existingMenuItems.length) {
            message = `Multiple menu items added successfully. ${existingMenuItems.length} items already exists.`;
        }

        return { status: true, message };
    }

    //Get a menu item by ID
    async getMenuItemById(menuItemId: string): Promise<IMenuItem> {
        const menu = await menuRepository.getMenuItemById(menuItemId);
        if (!menu) throw ApiError.notFound("Menu item not found.");
        if (menu.isDelete) throw ApiError.gone("Menu item has been deleted.");
        return menu;
    }

    //Get multiple menu items
    async getMenuItems(branchId: string, queryOptions: any): Promise<{ menuItems: IMenuItem[], total: number }> {
        const { page, limit, search, categoryIds, availability, ids } = queryOptions;
        const pagination: IPagination = handlePagination(page, limit);

        const query: any = {
            branchId: new mongoose.Types.ObjectId(branchId),
            isDelete: false,
            availability: true

        };
        if (ids) query._id = { $in: ids.map((id: string) => new mongoose.Types.ObjectId(id)) };
        if (categoryIds) query.categoryId = { $in: categoryIds.map((id: string) => new mongoose.Types.ObjectId(id)) };
        if (availability) query.availability = availability;
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { description: { $regex: search, $options: 'i' } },
            ];
        }


        const total = await menuRepository.model.countDocuments(query);

        const menuItems = await menuRepository.getAllMenuItems(query, pagination);
        if (!menuItems) throw ApiError.notFound("No menu items found.");

        return { menuItems, total };
    }

    //Get multiple menu items
    async getUnavailableMenuItems(branchId: string, queryOptions: any): Promise<IMenuItem[]> {
        const { page, limit } = queryOptions;
        const pagination: IPagination = handlePagination(page, limit);

        const query: any = {
            branchId: new mongoose.Types.ObjectId(branchId),
            isDelete: false,
            availability: false
        };
        const menuItems = await menuRepository.getAllMenuItems(query, pagination);
        if (!menuItems) throw ApiError.notFound("No menu items found.");

        return menuItems;
    }


    //Update a menu item by ID
    async updateMenuItem(menuItemId: string, menuItemData: IMenuItemRequest): Promise<IMenuItem> {
        const menu = await this.getMenuItemById(menuItemId);

        const { name, description, price, categoryId, ingredients, availability } = menuItemData;
        if (name) {
            //Check if menu item already exists
            const existingMenuItem = await this.isMenuExist(name);
            if (existingMenuItem) throw ApiError.conflict("Menu item with this name already exists.");
            menu.name = name;
        }
        if (description) menu.description = description;
        if (price) menu.price = Math.ceil(price);
        if (categoryId) menu.categoryId = new mongoose.Types.ObjectId(categoryId);
        if (availability !== undefined) menu.availability = availability;
        if (ingredients) {
            const menuIngredients = menuItemData.ingredients.map((ingredient) =>
                new mongoose.Types.ObjectId(ingredient));
            menu.ingredients = menuIngredients;
        }

        //Update the menu item
        const updatedMenuItem = await menu.save();
        if (!updatedMenuItem) throw ApiError.internal("Menu item update failed.");

        return updatedMenuItem;
    }

    //Delete a menu item by ID
    async deleteMenuItem(menuItemId: string): Promise<boolean> {
        const result = await menuRepository.updateMenuItem(menuItemId, { isDelete: true });
        if (!result) throw ApiError.notFound("Menu item not found.");
        return true;
    }

    async reactivatedMenuItem(menuItemId: string): Promise<boolean> {
        const result = await menuRepository.updateMenuItem(menuItemId, { isDelete: false });
        if (!result) throw ApiError.notFound("Menu item not found.");
        return true;
    }
    // Permanent delete a menu item by ID
    async deleteMenuItemPermanent(menuItemId: string): Promise<boolean> {
        const result = await menuRepository.deleteMenuItem(menuItemId);
        if (!result) throw ApiError.notFound("Menu item not found.");
        return result;
    }

    //Delete multiple menu items
    async deleteManyMenuItems(menuItemIds: string[]): Promise<boolean> {
        const query = { _id: { $in: menuItemIds.map((id) => new mongoose.Types.ObjectId(id)) } };
        const result = await menuRepository.deleteManyMenuItems(query);
        if (!result) throw ApiError.notFound("Menu items not found.");
        return result;
    }
}

const menuService = new MenuService();
export default menuService;