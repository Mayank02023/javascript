import mongoose from 'mongoose';
import { IAgent } from '../models/Agent.model';  // Assuming you have a new Agent model
import agentRepository from '../repositories/Agent.Repository'; // Assuming you have a new Agent repository
import { ApiError, decodeToken, uploadFileService } from '../utils';
import envConfig from '../config/envConfig';
import { IAuthCredential, IChangePasswordRequest, ITokenResponse, } from '../types/Auth.Interface';
import { IAgentDto, IAgentProfileResponse } from '../types/Agent.Interface';
import restaurantRepository from '../repositories/Restaurant.Repository';

class AgentService {
    // Check if an agent with the same username or phone number already exists
    private async isAgentExist(username?: string, phoneNumber?: string): Promise<boolean> {
        if (!username && !phoneNumber) return false;
        const query = {
            $or: [{ username }, { phoneNumber }]
        };
        const existingAgent = await agentRepository.findAgentByFields(query);
        return !!existingAgent;
    }

    // Generate a JWT access token for agent
    private async generateAccessAndRefreshToken(agent: IAgent): Promise<ITokenResponse> {
        const accessToken = agent.generateAccessToken();
        const refreshToken = agent.generateRefreshToken();
        return { accessToken, refreshToken };
    }

    // Create a new agent service method
    async createAgent(agentData: IAgentDto): Promise<IAgent | null> {
        const { username, phoneNumber } = agentData;

        // Check if the agent already exists
        const agentExists = await this.isAgentExist(username, phoneNumber);

        if (agentExists) {
            throw ApiError.badRequest('Username or phone number already exists.');
        }
        // Check if an image file is provided and upload it to Cloudinary
        if (agentData.avatar) {
            const avatarUrl = await uploadFileService.uploadOnCloudinary(agentData.avatar);
            if (!avatarUrl) {
                throw ApiError.badRequest("Failed to upload avatar to Cloudinary");
            }
            agentData.avatar = avatarUrl?.url;
        }

        // Save the agent to the database
        const createdAgent = await agentRepository.createAgent(agentData);

        // Check if the agent was created successfully
        if (!createdAgent) {
            throw ApiError.internal("Something went wrong while registering the agent");
        }

        // Retrieve the created agent, excluding the password field
        const agentResponse = await agentRepository.getAgentWithoutSensitiveFields(createdAgent._id);

        // Return a successful response with the created agent data
        return agentResponse;
    }

    // Login the agent service method
    async loginAgent(AuthCredential: IAuthCredential) {
        const { username, phoneNumber, password } = AuthCredential;

        // Validate input: Ensure either username or phone number is provided
        if (!username && !phoneNumber) {
            throw ApiError.badRequest("Username or phone number is required");
        }
        if (!password) {
            throw ApiError.badRequest("Password is required");
        }

        const field = {
            $or: [{ username }, { phoneNumber }]
        };
        const agent = await agentRepository.findAgentByFields(field);
        if (!agent) {
            throw ApiError.badRequest("Agent does not exist!");
        }

        // Check if the provided password is correct
        const isPasswordValid = await agent.isPasswordCorrect(password);
        if (!isPasswordValid) {
            throw ApiError.unauthorized("Invalid agent credentials");
        }

        // Generate access and refresh tokens
        const { accessToken, refreshToken } = await this.generateAccessAndRefreshToken(agent);

        if (!accessToken || !refreshToken) {
            throw ApiError.unauthorized("Tokens are not generated!");
        }

        // Update refresh token and agent login status
        await agentRepository.updateAgentById(agent._id, { isLoggedIn: true, refreshToken });

        // Fetch agent data without any sensitive fields
        const agentResponse = await agentRepository.getAgentWithoutSensitiveFields(agent._id);

        // Check if the agent was fetched properly
        if (!agentResponse) {
            throw ApiError.badRequest("Agent does not exist!");
        }

        return {
            agent: agentResponse,
            accessToken,
            refreshToken
        };
    }

    // Logout agent service method
    async logout(agentId: string): Promise<boolean> {
        // Update the agent's isLoggedIn status and clear refreshToken
        const agent = await agentRepository.updateAgentById(agentId, {
            isLoggedIn: false,
            refreshToken: undefined,
        });

        // If agent doesn't exist, throw an appropriate error
        if (!agent) throw ApiError.notFound("Agent does not exist!");

        // Return true if the agent is successfully logged out
        return !agent.isLoggedIn;
    }

    // Refresh token service method to refresh access and refresh tokens for agent
    async refreshAccessToken(incomingRefreshToken: string): Promise<{ accessToken: string; refreshToken: string }> {
        try {
            const refreshTokenSecret = String(envConfig.REFRESH_TOKEN_SECRET);
            // Decode the incoming refresh token using the secret key from environment config
            const decodedToken = decodeToken(incomingRefreshToken, { secret: refreshTokenSecret });

            // If decoding fails or token is invalid, throw an unauthorized error
            if (!decodedToken) throw ApiError.unauthorized("Invalid refresh token.");

            // Find the agent based on the agent ID extracted from the decoded refresh token
            const agent = await agentRepository.findAgentById(decodedToken.id);

            // If agent is not found, throw a not found error
            if (!agent) throw ApiError.notFound("Agent not found!");

            // Compare the incoming refresh token with the one saved in the agent's database
            // If they don't match, it indicates the token is expired, already used, or invalid
            if (incomingRefreshToken !== agent?.refreshToken) throw ApiError.unauthorized("The refresh token is either expired, already used, or invalid.");

            // Generate new access and refresh tokens for the agent
            const { accessToken, refreshToken } = await this.generateAccessAndRefreshToken(agent);

            // Check if the tokens were successfully generated If either access token or refresh token is missing, throw a bad request error
            if (!accessToken || !refreshToken) throw ApiError.badRequest("Failed to generate access and refresh tokens.");

            // Update refresh token and agent login status
            await agentRepository.updateAgentById(agent._id, { isLoggedIn: true, refreshToken });

            // Return the newly generated access and refresh tokens
            return { accessToken, refreshToken };

        } catch (error: any) {
            // Catch any errors (e.g., invalid token, decoding issues) and throw an unauthorized error
            throw ApiError.unauthorized("Invalid refresh token.");
        }
    }

    // Change the current password service method for agent
    async changeCurrentPassword(changePasswordPayload: IChangePasswordRequest): Promise<boolean> {
        const { oldPassword, newPassword, objectId } = changePasswordPayload;

        // Get agent by using agent ID pushed at middleware
        const agent = await agentRepository.findAgentById(objectId);

        if (!agent) throw ApiError.unauthorized("Agent not found. Please log in again.");

        // Check if the old password is correct
        const isPasswordCorrect = await agent.isPasswordCorrect(oldPassword);

        if (!isPasswordCorrect) throw ApiError.badRequest("The old password provided is incorrect.");

        // Ensure new password is different from the old password
        if (oldPassword === newPassword) throw ApiError.badRequest("The new password must be different from the old password.");

        // Update the agent's password
        agent.password = newPassword;

        // Save agent data without re-validating fields
        await agent.save({ validateBeforeSave: false });

        return true;
    }

    // Service for getting the current logged agent
    async getCurrentAgent(agentId: string): Promise<IAgent> {

        // Get agent by using agent id
        const agent = await agentRepository.getAgentWithoutSensitiveFields(agentId);

        if (!agent) throw ApiError.notFound("Agent not found");

        return agent;
    }

    // Update agent details service method
    async updateAgentDetails(agentId: string, agentData: Partial<IAgent>): Promise<IAgent> {
        // Try to update the agent in the repository
        const updatedAgent = await agentRepository.updateAgentById(agentId, agentData);

        // If no agent is found or updated, throw an error with proper message and code
        if (!updatedAgent) {
            throw ApiError.notFound("Agent not found. Unable to update agent with the provided ID.");
        }
        // Return the updated agent object
        return updatedAgent;
    }

    // Update agent avatar service method
    async updateAgentAvatar(agentId: string, avatarLocalPath: string): Promise<string> {
        // Upload the image to Cloudinary
        const avatar = await uploadFileService.uploadOnCloudinary(avatarLocalPath);

        // Check if the upload was successful
        if (!avatar?.url) {
            throw new ApiError(400, "Failed to upload avatar to Cloudinary");
        }
        // Try to update the agent in the repository
        const updatedAgent = await agentRepository.updateAgentById(agentId, { avatar: avatar?.url });

        // If no agent is found or updated, throw an error with proper message and code
        if (!updatedAgent?.avatar) {
            throw ApiError.notFound("Agent not found. Unable to update agent avatar with the provided ID.");
        }
        // Return the updated agent object
        return updatedAgent.avatar;
    }

    // Get agent profile service method
    async getAgentProfile(agentId: string): Promise<IAgentProfileResponse | null> {
        const agentProfile = await agentRepository.model.aggregate([
            {
                $match: { _id: new mongoose.Types.ObjectId(agentId) }
            },
            {
                $lookup: {
                    from: 'restaurants', // The collection to join
                    localField: 'assignedRestaurants', // Field in agent collection
                    foreignField: '_id', // Field in restaurant collection
                    as: 'restaurants' // Alias for joined restaurants
                }
            },
            {
                $unwind: {
                    path: '$restaurants',
                    preserveNullAndEmptyArrays: true // Allow null if no restaurants
                }
            },
            {
                $project: {
                    _id: 1,
                    name: 1,
                    username: 1,
                    email: 1,
                    phoneNumber: 1,
                    avatar: 1,
                    assignedRestaurants: 1,
                    role: 1,
                    status: 1,
                    bankDetails: 1,
                    transactions: 1,
                    isLoggedIn: 1,
                    createdAt: 1,
                    updatedAt: 1,
                    restaurants: {
                        id: '$restaurants._id',
                        name: '$restaurants.name' // Fields from restaurant collection
                    }
                }
            }
        ]);

        if (!agentProfile || agentProfile.length == 0) {
            throw ApiError.badRequest("Agent profile not found!");
        }
        const profile = agentProfile[0] as IAgentProfileResponse;
        return profile;
    }

    async getAgentById(agentId: any): Promise<IAgent> {
        const agent = await agentRepository.findAgentById(agentId);
        if (!agent) throw ApiError.badRequest("Agent not found!");
        return agent;
    }

    // Add assigned restaurant to an agent's assignedRestaurants array
    async addAssignedRestaurant(agentId: string, restaurantId: string): Promise<boolean> {
        // Step 1: Find the agent by agentId
        const agent = await agentRepository.findAgentById(agentId);
        if (!agent) {
            throw ApiError.notFound("Agent not found!");
        }

        const objectRestaurantId = new mongoose.Types.ObjectId(restaurantId)

        // Add the restaurant to the assignedRestaurants array
        agent.assignedRestaurants.push(objectRestaurantId);

        // Step 4: Save the updated agent document
        const updatedAgent = await agent.save();
        if (!updatedAgent) {
            throw ApiError.internal("Failed to assign restaurant to the agent.");
        }

        // Step 5: Return the updated agent
        return updatedAgent ? true : false;
    }
}

const agentService = new AgentService();
export default agentService;
