import { ApiError, getRestockDate } from "../utils";
import { IInventory } from "../models/Inventory.model";
import { IPagination } from "../types/Comman.Interface";
import inventoryRepository from "../repositories/Inventory.Repository";
import mongoose from "mongoose";
import { handlePagination } from "../utils/preparePaginationOptions";
import { IInventoryRequest } from "../types/Request.Interface";

class InventoryService {

    // Add a new inventory item
    async addInventory(inventoryData: IInventoryRequest): Promise<IInventory> {
        const { branchId, name, description, quantity, unit, lowStockThreshold, restockDays } = inventoryData;
        const restockDate = getRestockDate(restockDays)
        const newInventory: Partial<IInventory> = {
            branchId: new mongoose.Types.ObjectId(branchId),
            name,
            description,
            quantity,
            unit,
            lowStockThreshold,
            restockDate
        }
        const inventory = await inventoryRepository.addInventory(newInventory);
        if (!inventory) throw ApiError.internal("Inventory item insertion process failed!.");
        return inventory;
    }

    // Add multiple inventory items at once
    async addManyInventories(branchId: string, inventoriesData: IInventoryRequest[]): Promise<boolean> {
        // Process each inventory item to include the restockDate and branchId conversion
        const processedInventories: Partial<IInventory>[] = inventoriesData.map(item => {
            const inventory = new inventoryRepository.model({
                branchId: new mongoose.Types.ObjectId(branchId),
                name: item.name,
                description: item.description,
                quantity: item.quantity,
                unit: item.unit,
                lowStockThreshold: item.lowStockThreshold,
                restockDate: getRestockDate(item.restockDays),
            });
            return inventory;
        });

        const inventories = await inventoryRepository.addManyInventories(processedInventories);
        if (!inventories) {
            throw ApiError.internal("Bulk inventory insertion process failed.");
        }
        return inventories;
    }

    // Get an inventory item by its ID
    async getInventoryById(inventoryId: string): Promise<IInventory> {
        const inventory = await inventoryRepository.getInventoryById(inventoryId);

        if (!inventory) throw ApiError.notFound("Inventory item not found.");
        if (inventory.isDelete) throw ApiError.gone("Inventory item has been deleted and is no longer available.");

        return inventory;
    }


    // Find inventory items based on a query and pagination
    async findInventories(branchId: string, queryOptions: any): Promise<IInventory[]> {
        const { page, limit, status, name, quantity, lowStockThreshold, restockDate } = queryOptions;

        const query: any = {
            branchId: new mongoose.Types.ObjectId(branchId),
            isDelete: false
        };

        if (status) query.status = status;
        if (name) query.name = { $regex: name, $options: 'i' };
        if (quantity !== undefined) query.quantity = { $gte: quantity };
        if (lowStockThreshold !== undefined) query.lowStockThreshold = { $lte: lowStockThreshold };
        if (restockDate) query.restockDate = { $gte: new Date(restockDate) };

        const pagination: IPagination = handlePagination(page, limit);

        const inventories = await inventoryRepository.findInventories(query, pagination);

        if (!inventories) {
            throw ApiError.notFound("Inventory items not found");
        }

        return inventories;
    }

    // Update an inventory item by its ID
    async updateInventoryById(inventoryId: string, inventoryData: Partial<IInventoryRequest>): Promise<IInventory> {
        const { name, description, quantity, unit, lowStockThreshold, restockDays } = inventoryData;
        const inventory = await inventoryRepository.getInventoryById(inventoryId);
        if (!inventory) throw ApiError.notFound("Inventory item not found.");
        if (inventory.isDelete) throw ApiError.gone("This inventory item has been marked as deleted and cannot be updated.");

        if (name) inventory.name = name;
        if (description) inventory.description = description;
        if (quantity) inventory.quantity = quantity;
        if (unit) inventory.unit = unit;
        if (lowStockThreshold) inventory.lowStockThreshold = lowStockThreshold;
        if (restockDays) inventory.restockDate = getRestockDate(restockDays)


        const updatedInventory = await inventory.save();
        if (!updatedInventory) {
            throw ApiError.notFound("Failed to update inventory item because it no longer exists.");
        }
        return updatedInventory;
    }

    // Mark an inventory item as deleted (soft delete)
    async deleteInventoryById(inventoryId: string): Promise<boolean> {
        const result = await inventoryRepository.deleteInventoryById(inventoryId);
        if (!result) {
            throw ApiError.notFound("Inventory item not found");
        }
        return result;
    }

    // Permanently delete an inventory item
    async deletePermanentInventoryById(inventoryId: string): Promise<boolean> {
        const result = await inventoryRepository.deletePermanentInventoryById(inventoryId);
        if (!result) {
            throw ApiError.notFound("Inventory item not found");
        }
        return result;
    }

    //Delete multiple inventory items
    async deleteManyInventories(inventoryIds: string[]): Promise<boolean> {
        const query = { _id: { $in: inventoryIds.map((id) => new mongoose.Types.ObjectId(id)) } };
        const result = await inventoryRepository.deleteManyInventories(query);
        if (!result) throw ApiError.notFound("Menu items not found.");
        return result;
    }


    // Find inventory items that are below the low stock threshold
    async findLowStockItems(branchId: string, queryOptions: any): Promise<IInventory[]> {
        const lowStockItems = await inventoryRepository.findLowStockItems(branchId);
        if (!lowStockItems) {
            throw ApiError.notFound("No low stock items found");
        }
        return lowStockItems;
    }
}

const inventoryService = new InventoryService();
export default inventoryService;
