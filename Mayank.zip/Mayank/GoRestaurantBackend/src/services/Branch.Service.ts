import mongoose from "mongoose";
import { IBranch } from "../models/Branch.model";
import branchRepository from "../repositories/Branch.Repository";
import { IPagination } from "../types/Comman.Interface";
import { handlePagination } from "../utils/preparePaginationOptions";
import { ApiError } from "../utils";
import { IBranchDto } from "../types/Restaurant.Interface";
import restaurantService from "./Restaurant.service";

class BranchService {
    async addBranch(branchData: Partial<IBranch>): Promise<IBranch> {
        if (!branchData.restaurantId) {
            throw ApiError.badRequest("Restaurant ID is required.");
        }

        // Step 1: Add the branch
        const data = await branchRepository.addNewBranch(branchData);
        if (!data) {
            throw ApiError.notFound("Failed to add the branch.");
        }

        const branchId: string = data._id.toString();
        const restaurantId = branchData.restaurantId.toString();

        try {
            // Step 2: Associate the branch with the restaurant
            const isAssociated = await restaurantService.associateBranch(restaurantId, branchId);
            if (!isAssociated) {
                throw new Error("Branch association failed.");
            }
        } catch (error) {
            // Step 3: Rollback the newly added branch
            await branchRepository.deleteParmanentBranchById(branchId);
            throw ApiError.internal(
                "Branch creation was rolled back due to a failure in the association process."
            );
        }

        // Step 4: Return the created branch if all succeeds
        return data;
    }


    async addManyBranches(branchesData: Partial<IBranch[]>): Promise<boolean> {
        const data = await branchRepository.addManyBranches(branchesData);
        return data;
    }

    async getBranchById(branchId: string): Promise<IBranch> {
        const branch = await branchRepository.getBranchById(branchId);
        if (!branch) throw ApiError.notFound("Branch is not found!.");
        if (branch.isDelete) throw ApiError.notFound("Branch has been deleted!.");

        return branch;
    }

    async getBranchsByRestaurantId(
        restaurantId: string,
        queryOptions: any
    ): Promise<IBranch[]> {
        const { page = 1, limit = 20 } = queryOptions;

        const query: any = {
            isDelete: false,
            restaurantId: new mongoose.Types.ObjectId(restaurantId),
        };

        const pagination: IPagination = handlePagination({ page, limit });

        const branches = await branchRepository.findBranches(query, pagination);
        if (!branches) throw ApiError.notFound("Branch data not found!.");

        return branches;
    }

    async updateBranchById(branchId: string, branchData: Partial<IBranchDto>): Promise<IBranch> {
        const { name, address, restaurantId, managerId, status } = branchData;

        const branch = await this.getBranchById(branchId);

        if (name) branch.name = name;
        if (address) branch.address = address;
        if (restaurantId) branch.restaurantId = new mongoose.Types.ObjectId(restaurantId);
        if (managerId) branch.managerId = new mongoose.Types.ObjectId(managerId);
        if (status) branch.status = status;

        const updatedBranch = await branch.save();

        if (!updatedBranch) {
            // If the update fails, return a 500 error
            throw ApiError.internal("An error occurred while updating the branch. Please try again.");
        }
        // Return the updated branch if successful
        return updatedBranch;
    }

    async deleteBranchById(branchId: string): Promise<boolean> {
        // Attempt to delete the restaurant from the repository
        const isDeleted = await branchRepository.deleteBranchById(branchId);

        // Check if the restaurant was successfully deleted
        if (!isDeleted) {
            throw ApiError.notFound(`Branch with ID "${branchId}" not found. Unable to delete.`);
        }

        // Return true if the deletion was successful
        return true;
    }

}

const branchService = new BranchService();
export default branchService;