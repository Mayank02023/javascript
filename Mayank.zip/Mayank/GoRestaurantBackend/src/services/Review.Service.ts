import { IReview } from "../models/Restaurant.model";
import reviewRepository from "../repositories/Review.Respository";
import { IPagination } from "../types/Comman.Interface";
import { ApiError } from "../utils";
import { handlePagination } from "../utils/preparePaginationOptions";

class ReviewService {
    // Add review for restaurant
    async addReviewToRestaurant(reviewData: Partial<IReview>): Promise<IReview> {
        const review = await reviewRepository.addReview(reviewData);
        if (!review) throw ApiError.notFound('New review did not add');
        return review;
    }

    // List of reviews of a restaurant
    async getReviewsForRestaurant(queryOptions: any): Promise<IReview[]> {
        const { restaurantId, rating, page = 1, limit = 10 } = queryOptions;

        if (!restaurantId) throw ApiError.badRequest("Restaurant id is required!.");

        // Build the query object
        const query: any = {};
        query.restaurantId = restaurantId; // Filter by restaurantId
        if (rating) query.rating = rating; // Filter by rating

        const pagination: IPagination = handlePagination({ page, limit });

        const reviews = await reviewRepository.findReviews(query, pagination);
        if (!reviews) throw ApiError.notFound("Reviews data not found!");
        return reviews;
    }

    
}

const reviewService = new ReviewService();
export default reviewService;