// services/OrderService.ts
import mongoose from "mongoose";
import orderRepository from "../repositories/Order.Repository";
import { IOrder } from "../models/Order.model";
import { IOrderRequest } from "../types/Request.Interface"; // Define this interface as needed
import { ApiError } from "../utils";
import { IPagination, IPaymentMethod } from "../types/Comman.Interface";
import { handlePagination } from "../utils/preparePaginationOptions";
import tableService from "./Table.Service";
import { orderConstant } from "../constants";

class OrderService {
    /**
     * Create a new order.
     * This method converts order items into ObjectId references, calculates the total amount
     * if not provided, and creates the order record.
     */
    async createOrder(branchId: string, orderData: IOrderRequest): Promise<IOrder> {
        // Convert order items' menuItem field to ObjectId
        const items = orderData.items.map((item) => ({
            menuItemId: new mongoose.Types.ObjectId(item.menuItemId),
            quantity: item.quantity,
            price: item.price,
            instructions: item.instructions
        }));

        // Calculate total amount from items if not provided in the request
        let totalAmount = orderData.totalAmount;
        if (!totalAmount) {
            totalAmount = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
        }

        // Prepare the order payload including branch and optional customer info
        const orderPayload: Partial<IOrder> = {
            customerName: orderData.customerName,
            branchId: new mongoose.Types.ObjectId(branchId),
            tableId: new mongoose.Types.ObjectId(orderData.tableId),
            items,
            totalAmount,
            paymentMethod: orderData.paymentMethod,
            orderType: orderData.orderType,
            paymentStatus: orderData.paymentStatus || "INITIATED"
        };

        const newOrder = await orderRepository.createOrder(orderPayload);
        if (!newOrder) {
            throw ApiError.internal("Order creation failed.");
        }

        await tableService.updateTableById(orderData.tableId, { occupiedSeats: orderData.person });

        return newOrder;
    }

    /**
     * Retrieve an order by its ID.
     */
    async getOrderById(orderId: string): Promise<IOrder> {
        return await orderRepository.getOrderById(orderId);
    }

    /**
     * Retrieve orders with pagination and optional filtering.
     * You can filter orders by status or customer, for example.
     */
    async getOrders(
        branchId: string,
        queryOptions: any
    ): Promise<{ orders: IOrder[]; total: number }> {
        const { page, limit, status, customerName, paymentMethod, orderType, paymentStatus, ids, startDate, endDate } = queryOptions;
        const pagination: IPagination = handlePagination(page, limit);

        // Build query filter based on branch and optional filters
        const query: any = {};

        if (ids) query._id = { $in: ids.map((id: string) => new mongoose.Types.ObjectId(id)) };

        if (branchId) {
            query.branchId = new mongoose.Types.ObjectId(branchId)
        }

        if (orderConstant.orderStatus.includes(status)) {
            query.status = status;
        }

        if (orderConstant.paymentMethod.includes(paymentMethod)) {
            query.paymentMethod = paymentMethod;
        }

        if (orderConstant.paymentStatus.includes(paymentStatus)) {
            query.paymentStatus = paymentStatus;
        }

        if (orderConstant.orderType.includes(orderType)) {
            query.orderType = orderType;
        }

        if (customerName) {
            query.customerName = { $regex: customerName, $options: "i" };
        }

        if (startDate && endDate) {

            const startOfDay = new Date(startDate);
            const endOfDay = new Date(endDate);

            startOfDay.setHours(0, 0, 0, 0);
            endOfDay.setHours(23, 59, 59, 999);

            query.createdAt = { $gte: startOfDay, $lte: endOfDay }
        }
        // Retrieve paginated orders
        const orders = await orderRepository.getAllOrders(query, pagination);
        if (!orders) {
            throw ApiError.notFound("No orders found.");
        }


        return { ...orders };
    }

    /**
     * Update an existing order.
     * This can be used to update order status, Cashfree fields, order items, and other order-related fields.
     */
    async updateOrder(orderId: string, orderData: Partial<IOrderRequest>): Promise<IOrder> {
        // Fetch the existing order
        const order = await this.getOrderById(orderId);
        if (!order) {
            throw ApiError.notFound("Order not found.");
        }

        const updateData: Partial<IOrder> = {};

        if (orderData.paymentDetails) updateData.paymentDetails = orderData.paymentDetails;
        if (orderData.status) updateData.status = orderData.status as IOrder["status"];
        if (orderData.paymentStatus) updateData.paymentStatus = orderData.paymentStatus as IOrder["paymentStatus"];
        if (orderData.orderType) updateData.orderType = orderData.orderType as IOrder["orderType"];
        if (orderData.paymentMethod) updateData.paymentMethod = orderData.paymentMethod as IPaymentMethod;
        if (orderData.totalAmount) updateData.totalAmount = orderData.totalAmount;
        if (orderData.customerName) updateData.customerName = orderData.customerName;

        // Update staffId only if it's a valid ObjectId
        if (orderData.staffId && mongoose.isValidObjectId(orderData.staffId)) {
            updateData.staffId = new mongoose.Types.ObjectId(orderData.staffId);
        }

        // Update order items if provided
        if (orderData.items?.length) {
            updateData.items = orderData.items
                .filter(item => mongoose.isValidObjectId(item.menuItemId))
                .map(item => ({
                    menuItemId: new mongoose.Types.ObjectId(item.menuItemId),
                    quantity: item.quantity,
                    price: item.price || 0
                }));
        }

        // Update the order
        const updatedOrder = await orderRepository.updateOrder(orderId, updateData);
        if (!updatedOrder) {
            throw ApiError.internal("Order update failed.");
        }

        return updatedOrder;
    }



    /**
     * Soft delete or cancel an order by its ID.
     * Depending on your business logic, you might want to mark the order as cancelled.
     * Here, we remove the order record.
     */
    async deleteOrder(orderId: string): Promise<boolean> {
        const result = await orderRepository.updateOrder(orderId, { isDeleted: true });
        if (!result) throw ApiError.notFound("Order not found.");
        return true;
    }

    /**
     * Parmanent delete or cancel an order by its ID.
     * Depending on your business logic, you might want to mark the order as cancelled.
     * Here, we remove the order record.
     */
    async deleteOrderParmenet(orderId: string): Promise<boolean> {
        const result = await orderRepository.deleteOrder(orderId);
        if (!result) {
            throw ApiError.notFound("Order not found.");
        }
        return result;
    }
}

const orderService = new OrderService();
export default orderService;
