import mongoose from 'mongoose';
import { IUser } from '../models/User.model';
import userRepository from '../repositories/User.Repository';
import { ApiError, decodeToken, uploadFileService } from '../utils';
import envConfig from '../config/envConfig';
import { IAuthCredential, IChangePasswordRequest, ITokenResponse, IUserDto } from '../types/Auth.Interface';
import { IUserProfileResponse } from '../types/User.Interface';
import branchService from './Branch.Service';
import restaurantService from './Restaurant.service';
import { queryOptions } from '../constants';

class UserService {
    // Check if a user with the same username or phone number already exists
    private async isUserExist(username?: string, phoneNumber?: string): Promise<boolean> {
        if (!username && !phoneNumber) return false;
        const query = {
            $or: [{ username }, { phoneNumber }]
        };
        const existingUser = await userRepository.findUserByFields(query);
        return !!existingUser;
    }

    // Generate a JWT access token
    private async generateAccessAndRefreshToken(user: IUser): Promise<ITokenResponse> {
        const accessToken = user.generateAccessToken();
        const refreshToken = user.generateRefreshToken();
        return { accessToken, refreshToken }
    }

    // Create a new user service method
    async createUser(userData: IUserDto): Promise<IUser | null> {
        let { username, phoneNumber, avatar, branchId, role, restaurantId } = userData;

        // Validate if the user already exists
        const userExists = await this.isUserExist(username, phoneNumber);
        if (userExists) throw ApiError.badRequest("Username or phone number already exists.");

        // Upload avatar if provided
        if (avatar) {
            try {
                const avatarUrl = await uploadFileService.uploadOnCloudinary(avatar);
                if (!avatarUrl) throw new Error(); // If upload fails, throw an error
                userData.avatar = avatarUrl.url;
            } catch (error) {
                throw ApiError.badRequest("Failed to upload avatar to Cloudinary.");
            }
        } else {
            delete userData.avatar;
        }

        // Validate branch and its restaurant association if role is not "owner"
        let branch: any = null;
        if (role !== "owner") {
            if (!branchId) throw ApiError.badRequest("Branch ID is required to create the new user.");
            branch = await branchService.getBranchById(branchId);

            if (!branch) throw ApiError.badRequest("Invalid Branch ID.");
            if (!branch.restaurantId) throw ApiError.badRequest("Restaurant ID is missing for the branch.");
            restaurantId = branch.restaurantId.toString();
        }

        // Create the user
        const createdUser = await userRepository.createUser({
            ...userData,
            restaurantId: new mongoose.Types.ObjectId(restaurantId),
            branchId: branchId ? new mongoose.Types.ObjectId(branchId) : undefined,
        });

        if (!createdUser) throw ApiError.internal("Failed to create the user.");

        if (role === "owner") {
            await restaurantService.updateRestaurantById(restaurantId, { ownerId: createdUser._id });
        } else if (role === "manager" && branchId) {
            await branchService.updateBranchById(branchId, { managerId: createdUser._id })
        }

        // Fetch and return the user excluding sensitive fields
        const user = await userRepository.getUserWithoutSensitiveFields(createdUser._id);
        if (!user) throw ApiError.internal("Create User process failed.");

        return user;
    }


    // Login the user service method
    async loginUser(AuthCredential: IAuthCredential) {

        const { username, phoneNumber, password } = AuthCredential;
        // Validate input: Ensure either username or phone number is provided
        if (!username && !phoneNumber) {
            throw ApiError.badRequest("Username or phone number is required");
        }
        if (!password) {
            throw ApiError.badRequest("Password is required");
        }

        const field = {
            $or: [{ username }, { phoneNumber }]
        }
        const user = await userRepository.findUserByFields(field);
        if (!user) {
            throw ApiError.badRequest("User does not exist!");
        }

        // Check if the provided password is correct
        const isPasswordValid = await user.isPasswordCorrect(password);
        if (!isPasswordValid) {
            throw ApiError.unauthorized("Invalid user credentials");
        }

        // Generate access and refresh tokens
        const { accessToken, refreshToken } = await this.generateAccessAndRefreshToken(user);

        if (!accessToken || !refreshToken) {
            throw ApiError.unauthorized("Tokens are not generated!");
        }

        //Update refresh token and user login status
        await userRepository.updateUserById(user._id, { isLoggedIn: true, refreshToken });

        //Fetch user data with any sensitive fields
        const userResponse = await userRepository.getUserWithoutSensitiveFields(user._id);

        //check is user fetched properlly
        if (!userResponse) {
            throw ApiError.badRequest("User does not exist!");
        }
        return {
            user: userResponse,
            accessToken,
            refreshToken
        }
    }

    // Logout user service method
    async logout(userId: string): Promise<boolean> {
        // Update the user's isLoggedIn status and clear refreshToken
        const user = await userRepository.updateUserById(userId, {
            isLoggedIn: false,
            refreshToken: undefined,
        });

        // If user doesn't exist, throw an appropriate error
        if (!user) throw ApiError.notFound("User does not exist!");

        // Return true if the user is successfully logged out
        return !user.isLoggedIn;
    }

    // Refresh token service method to refresh access and refresh tokens
    async refreshAccessToken(incomingRefreshToken: string): Promise<{ accessToken: string; refreshToken: string }> {
        try {
            const refreshTokenSecret = String(envConfig.REFRESH_TOKEN_SECRET);
            // Decode the incoming refresh token using the secret key from environment config
            const decodedToken = decodeToken(incomingRefreshToken, { secret: refreshTokenSecret });

            // If decoding fails or token is invalid, throw an unauthorized error
            if (!decodedToken) throw ApiError.unauthorized("Invalid refresh token.");

            // Find the user based on the user ID extracted from the decoded refresh token
            const user = await userRepository.findUserById(decodedToken.id);

            // If user is not found, throw a not found error
            if (!user) throw ApiError.notFound("User not found!");

            // Compare the incoming refresh token with the one saved in the user's database
            // If they don't match, it indicates the token is expired, already used, or invalid
            if (incomingRefreshToken !== user?.refreshToken) throw ApiError.unauthorized("The refresh token is either expired, already used, or invalid.");

            // Generate new access and refresh tokens for the user
            const { accessToken, refreshToken } = await this.generateAccessAndRefreshToken(user);

            // Check if the tokens were successfully generated If either access token or refresh token is missing, throw a bad request error
            if (!accessToken || !refreshToken) throw ApiError.badRequest("Failed to generate access and refresh tokens.");

            //Update refresh token and user login status
            await userRepository.updateUserById(user._id, { isLoggedIn: true, refreshToken });

            // Return the newly generated access and refresh tokens
            return { accessToken, refreshToken };

        } catch (error: any) {
            // Catch any errors (e.g., invalid token, decoding issues) and throw an unauthorized error
            throw ApiError.unauthorized("Invalid refresh token.");
        }
    }

    // Change the current password service method
    async changeCurrentPassword(changePasswordPayload: IChangePasswordRequest): Promise<boolean> {
        const { oldPassword, newPassword, objectId } = changePasswordPayload;

        // Get user by using user ID pushed at middleware
        const user = await userRepository.findUserById(objectId);

        if (!user) throw ApiError.unauthorized("User not found. Please log in again.");

        // Check if the old password is correct
        const isPasswordCorrect = await user.isPasswordCorrect(oldPassword);

        if (!isPasswordCorrect) throw ApiError.badRequest("The old password provided is incorrect.");

        // Ensure new password is different from the old password
        if (oldPassword === newPassword) throw ApiError.badRequest("The new password must be different from the old password.");

        // Update the user's password
        user.password = newPassword;

        // Save user data without re-validating fields
        await user.save({ validateBeforeSave: false });

        return true;
    }

    // Service for getting the current logged user
    async getCurrentUser(userId: string): Promise<IUser> {

        // Get user by using user id
        const user = await userRepository.getUserWithoutSensitiveFields(userId);

        if (!user) throw ApiError.notFound("User not found");

        return user
    }

    // update user details service method
    async updateUserDetails(userId: string, userData: Partial<IUser>): Promise<IUser> {

        // Try to update the user in the repository
        const updatedUser = await userRepository.updateUserById(userId, userData);

        // If no user is found or updated, throw an error with proper message and code
        if (!updatedUser) {
            throw ApiError.notFound("User not found. Unable to update user with the provided ID.");
        }
        // Return the updated user object
        return updatedUser;
    }

    // update user avatar service method
    async updateUserAvatar(userId: string, avatarLocalPath: string): Promise<string> {
        // Upload the image to Cloudinary
        const avatar = await uploadFileService.uploadOnCloudinary(avatarLocalPath);

        // Check if the upload was successful
        if (!avatar?.url) {
            throw new ApiError(400, "Failed to upload avatar to Cloudinary");
        }
        // Try to update the user in the repository
        const updatedUser = await userRepository.updateUserById(userId, { avatar: avatar?.url });

        // If no user is found or updated, throw an error with proper message and code
        if (!updatedUser?.avatar) {
            throw ApiError.notFound("User not found. Unable to update user avatar with the provided ID.");
        }
        // Return the updated user object
        return updatedUser.avatar;
    }

    // Get user profile service method
    async getUserProfile(userId: string): Promise<IUserProfileResponse | null> {
        const userProfile = await userRepository.model.aggregate([
            {
                $match: { _id: new mongoose.Types.ObjectId(userId) }
            },
            {
                $lookup: {
                    from: "restaurants",
                    localField: "restaurantId",
                    foreignField: "_id",
                    as: "restaurant"
                }
            },
            {
                $unwind: {
                    path: "$restaurant",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: "branches",
                    localField: "branchId",
                    foreignField: "_id",
                    as: "branch"
                }
            },
            {
                $unwind: {
                    path: "$branch",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $project: {
                    _id: 1,
                    username: 1,
                    email: 1,
                    phoneNumber: 1,
                    avatar: 1,
                    role: 1,
                    shiftId: 1,
                    positionId: 1,
                    demographic: {
                        address: 1,
                        city: 1,
                        state: 1,
                        country: 1,
                        pincode: 1,
                        dob: 1,
                        aadharCard: 1,
                        panCard: 1
                    },
                    isLoggedIn: 1,
                    status: 1,
                    restaurant: {
                        id: "$restaurant._id",
                        name: "$restaurant.name"
                    },
                    branches: {
                        id: "$branch._id",
                        name: "$branch.name"
                    }
                }
            }
        ]);

        if (!userProfile || userProfile.length == 0) {
            throw ApiError.badRequest("User profile not found!")
        }
        const profile = userProfile[0] as IUserProfileResponse;
        if (profile.role == "owner" && profile.restaurant?.id) {
            const branches = await branchService.getBranchsByRestaurantId(profile.restaurant?.id, queryOptions);
            if (branches) {
                profile.branches = branches.map((branch) => ({
                    id: branch._id,
                    name: branch.name
                }));
            }
        }
        return profile
    }

    async getUserById(userId: string): Promise<IUser> {
        if (!userId) throw ApiError.badRequest("User ID is required.");

        const user = await userRepository.model.findById(userId).select("-password -refreshToken")
        if (!user) throw ApiError.notFound("User not found.");
        // if (user.isDelete) throw ApiError.notFound("Restaurant has been deleted!.");
        return user;
    }
}
const userService = new UserService();
export default userService;
