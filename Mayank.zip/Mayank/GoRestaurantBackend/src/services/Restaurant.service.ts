import { IRestaurant } from "../models/Restaurant.model";
import restaurantRepository from "../repositories/Restaurant.Repository";
import { IRestaurantDto } from "../types/Restaurant.Interface";
import { ApiError, uploadFileService } from "../utils";
import { handlePagination } from "../utils/preparePaginationOptions";
import agentService from "./Agent.Service";
import { IPagination } from "../types/Comman.Interface";
import mongoose from "mongoose";

class RestaurantService {
  // Check if a restaurant with the given email or phone number already exists.
  private async doesRestaurantExist(email?: string, phoneNumber?: string): Promise<boolean> {
    if (!email && !phoneNumber) return false;

    const query = {
      $or: [{ email }, { phoneNumber }],
    };

    const existingRestaurants = await restaurantRepository.findRestaurants(query);
    return existingRestaurants.length > 0;
  }

  //  private async getFomatedRestaurant(): Promise<>

  // Create a new restaurant.
  async createRestaurant(restaurantData: IRestaurantDto): Promise<IRestaurant | null> {
    const { name, address, phoneNumber, email, agentId, avatar }: IRestaurantDto = restaurantData;
    const partialRestaurant: Partial<IRestaurant> = {
      name: name,
      address: address,
      phoneNumber: phoneNumber,
      email: email,
      agentId: agentId ? new mongoose.Types.ObjectId(agentId) : undefined,
    }
    // Check if the restaurant already exists.
    const restaurantExists = await this.doesRestaurantExist(email, phoneNumber);
    if (restaurantExists) throw ApiError.badRequest('A restaurant with the provided email or phone number already exists.');

    // Upload avatar to Cloudinary if provided.
    if (avatar) {
      const uploadedAvatar = await uploadFileService.uploadOnCloudinary(avatar);
      if (!uploadedAvatar) throw ApiError.badRequest("Failed to upload avatar.");
      partialRestaurant.avatar = uploadedAvatar.url;
    }

    // Save restaurant to the database.
    const newRestaurant = await restaurantRepository.createRestaurant(partialRestaurant);
    if (!newRestaurant || !newRestaurant.agentId) throw ApiError.internal("Error occurred while creating the restaurant.");
    await agentService.addAssignedRestaurant(newRestaurant.agentId.toString(), newRestaurant._id.toString())
    return newRestaurant;
  }

  // Get a restaurant by its ID.
  async getRestaurantById(restaurantId: string): Promise<IRestaurant> {
    if (!restaurantId) {
      throw ApiError.badRequest("Restaurant ID is required.");
    }

    const [restaurant] = await restaurantRepository.model.aggregate([
      {
        $match: { _id: new mongoose.Types.ObjectId(restaurantId) }
      },
      {
        $lookup: {
          from: "branches", // The branches collection
          localField: "branches", // Array of branch IDs in restaurants
          foreignField: "_id", // Branch IDs in the branches collection
          as: "branchDetails" // Resulting array of branch objects
        }
      },
      {
        $project: {
          _id: { $toString: "$_id" }, // Convert restaurant _id to string
          name: 1,
          address: 1,
          phoneNumber: 1,
          email: 1,
          avatar: 1,
          coverImage: 1,
          owner: { $toString: "$owner" }, // Convert owner ObjectId to string
          agentId: { $toString: "$agentId" }, // Convert agentId ObjectId to string
          branches: {
            $map: {
              input: "$branchDetails",
              as: "branch",
              in: {
                id: { $toString: "$$branch._id" }, // Convert branch _id to string
                name: "$$branch.name"
              }
            }
          },
          subscriptionPlan: 1,
          status: 1,
          isDelete: 1,
          createdAt: 1,
          updatedAt: 1
        }
      }
    ]);

    if (!restaurant) {
      throw ApiError.notFound("Restaurant not found.");
    }

    if (restaurant.isDelete) {
      throw ApiError.notFound("Restaurant has been deleted.");
    }

    return restaurant;
  }


  // Fetch a filtered list of restaurants based on provided fields.
  async getRestaurants(queryOptions: any): Promise<IRestaurant[]> {
    const { page = 1, limit = 10, search, status, agentId, owner } = queryOptions;

    // Build the query object based on filters
    const query: any = {};

    query.isDelete = false;

    if (status) {
      query.status = status; // Filter by status
    }

    if (agentId) {
      query.agentId = agentId; // Filter by agent ID
    }

    if (owner) {
      query.owner = owner; // Filter by owner ID
    }

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } }, // Search by name
        { address: { $regex: search, $options: 'i' } }, // Search by address
      ];
    }
    const pagination: IPagination = handlePagination({ page, limit });

    // Fetch data from the database
    const restaurants = await restaurantRepository.findRestaurants(query, pagination);
    if (!restaurants) throw ApiError.notFound("No restaurants found.");

    return restaurants;
  }

  // Update restaurant by its ID.
  async updateRestaurantById(restaurantId: string, restaurantData: Partial<IRestaurantDto>): Promise<IRestaurant> {
    const { name, address, phoneNumber, email, ownerId, agentId, subscriptionPlan, status } = restaurantData;

    // Calls the repository to get the restaurant data based on the provided ID
    const restaurant = await restaurantRepository.findRestaurantById(restaurantId);
    if (!restaurant) {
      throw ApiError.notFound("Restaurant not found!");
    }

    if (name) restaurant.name = name;
    if (address) restaurant.address = address;
    if (phoneNumber) restaurant.phoneNumber = phoneNumber;
    if (email) restaurant.email = email;
    if (ownerId) restaurant.ownerId = new mongoose.Types.ObjectId(ownerId);
    if (agentId) restaurant.agentId = new mongoose.Types.ObjectId(agentId);
    if (subscriptionPlan) restaurant.subscriptionPlan = new mongoose.Types.ObjectId(subscriptionPlan);
    if (status) restaurant.status = status;

    const updatedRestaurant = await restaurant.save();

    // Throws an error if the restaurant is not found
    if (!updatedRestaurant) throw ApiError.notFound(`Restaurant with ID "${restaurantId}" not found. Please check the ID and try again.`);

    // Returns the updated restaurant document
    return updatedRestaurant;
  }

  // Delete a restaurant by its ID.
  async deleteRestaurantById(restaurantId: string): Promise<boolean> {
    // Attempt to delete the restaurant from the repository
    const isDeleted = await restaurantRepository.deleteRestaurantById(restaurantId);

    // Check if the restaurant was successfully deleted
    if (!isDeleted) {
      throw ApiError.notFound(`Restaurant with ID "${restaurantId}" not found. Unable to delete.`);
    }

    // Return true if the deletion was successful
    return true;
  }

  //Method to associate branch with the restaurant
  async associateBranch(restaurantId: string, branchId: string): Promise<boolean> {
    // Step 1: Find the restaurant by restaurantId
    const restaurant = await restaurantRepository.findRestaurantById(restaurantId);
    if (!restaurant) {
      throw ApiError.notFound("Restaurant not found!");
    }

    const objectBranchId = new mongoose.Types.ObjectId(branchId);

    // Check if the branch is already associated
    const isAlreadyAssociated = restaurant.branches?.some(
      (branch: mongoose.Types.ObjectId) => branch.equals(objectBranchId)
    );

    if (isAlreadyAssociated) {
      throw ApiError.badRequest("Branch is already associated with the restaurant.");
    }

    // Add the branch into restaurant
    if (!restaurant.branches) {
      restaurant.branches = [objectBranchId]
    } else {
      restaurant.branches?.push(objectBranchId)
    }


    // Step 4: Save the updated restaurant document
    const updatedRestaurant = await restaurant.save();
    if (!updatedRestaurant) {
      throw ApiError.internal("Failed to associate branch with the restaurant.");
    }

    return true;
  }
}
const restaurantService = new RestaurantService();
export default restaurantService;
