import mongoose, { Document, Model, Schema } from "mongoose";
import bcrypt from "bcrypt";
import { ApiError } from "../utils";
import jwt from "jsonwebtoken";
import envConfig from "../config/envConfig";

export interface ISuperAdmin extends Document {
  _id: string;
  name: string;
  username: string;
  password: string;
  email: string;
  phoneNumber: string;
  status: 'active' | 'inactive';
  role: 'superAdmin';
  isLoggedIn?: boolean;
  refreshToken?: string;
  createdAt?: Date;
  updatedAt?: Date;

  isPasswordCorrect(password: string): Promise<boolean>;
  generateAccessToken(): string;
  generateRefreshToken(): string;
}

const superAdminSchema: Schema<ISuperAdmin> = new mongoose.Schema<ISuperAdmin>(
  {
    name: { type: String, required: true, unique: true },
    username: { type: String, required: true, unique: true },
    password: {
      type: String,
      required: true,
      minlength: 8,
      validate: {
        validator: (v: string) =>
          /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/.test(v),
        message:
          "Password must be at least 8 characters long and contain letters and numbers.",
      },
    },
    email: { type: String, required: true, unique: true },
    phoneNumber: { type: String, required: true },
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
    role: { type: String, default: 'superAdmin' },
    isLoggedIn: { type: Boolean, default: false },
    refreshToken: { type: String },
  },
  {
    timestamps: true
  }
);
// Pre-save hook to hash the password
superAdminSchema.pre<ISuperAdmin>("save", async function (next) {
  if (!this.isModified("password")) return next();

  try {
    const hashedPassword = await bcrypt.hash(this.password, 10);
    this.password = hashedPassword;
    next();
  } catch (err: any) {
    next(new ApiError(500, "Error hashing password"));
  }
});

// Method to compare passwords
superAdminSchema.methods.isPasswordCorrect = async function (
  password: string
): Promise<boolean> {
  return bcrypt.compare(password, this.password);
};

// Method to generate an access token
superAdminSchema.methods.generateAccessToken = function (): string {
  return jwt.sign(
    {
      id: this._id,
      username: this.username,
      role: "superAdmin",
    },
    envConfig.ACCESS_TOKEN_SECRET,
    {
      expiresIn: envConfig.ACCESS_TOKEN_EXPIRY,
    }
  );
};

// Method to generate a refresh token
superAdminSchema.methods.generateRefreshToken = function (): string {
  return jwt.sign(
    {
      id: this._id,
      role: "superAdmin",
    },
    envConfig.REFRESH_TOKEN_SECRET,
    {
      expiresIn: envConfig.REFRESH_TOKEN_EXPIRY,
    }
  );
};

// Method to validate refresh token
superAdminSchema.methods.isRefreshTokenValid = function (): boolean {
  try {
    jwt.verify(this.refreshToken!, envConfig.REFRESH_TOKEN_SECRET);
    return true;
  } catch {
    return false;
  }
};


const SuperAdminModel: Model<ISuperAdmin> = mongoose.model<ISuperAdmin>("SuperAdmin", superAdminSchema);

export default SuperAdminModel;
