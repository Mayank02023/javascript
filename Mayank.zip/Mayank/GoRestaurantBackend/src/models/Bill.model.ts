import mongoose, { Document, Model, Schema, Types } from "mongoose";

// Define the interface for the Bill model
export interface IBill extends Document {
  order: Types.ObjectId; // Reference to Order model
  amount: number; // Amount for the bill
  tax: number; // Tax applied on the bill
  total: number; // Total bill amount (including tax)
  paymentStatus: 'paid' | 'unpaid'; // Payment status of the bill
  paymentMethod: 'cash' | 'creditCard' | 'debitCard' | 'online'; // Method of payment
  branch: Types.ObjectId; // Reference to Branch model
  createdAt?: Date;
  updatedAt?: Date;
}

// Define the schema for the Bill model
const billSchema: Schema<IBill> = new mongoose.Schema<IBill>(
  {
    order: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
    amount: { type: Number, required: true },
    tax: { type: Number, required: true },
    total: { type: Number, required: true },
    paymentStatus: { 
      type: String, 
      enum: ['paid', 'unpaid'], 
      default: 'unpaid' 
    },
    paymentMethod: { 
      type: String, 
      enum: ['cash', 'creditCard', 'debitCard', 'online'], 
      required: true 
    },
    branch: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch', required: true },
  },
  {
    timestamps: true // Automatically manage createdAt and updatedAt fields
  }
);

// Create the model based on the schema
const Bill: Model<IBill> = mongoose.model<IBill>("Bill", billSchema);

// Export the Bill model for use in other files
export default Bill;
