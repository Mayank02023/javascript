import mongoose, { Document, Model, Schema, Types } from "mongoose";
import { IOrderStatus, IOrderType, IPaymentMethod, IPaymentStatus } from "../types/Comman.Interface";
import { orderConstant } from "../constants";

// Interface for Order Items
export interface IOrderItem {
  menuItemId: Types.ObjectId;
  quantity: number;
  price: number;
  instructions?: string;
}

// Interface for Payment Details
export interface IPaymentDetails {
  paymentId: string;
  orderId: string;
  signature: string;
}

// Interface for Refund Account Details
export interface IRefundAccountDetails {
  accountHolderName: string;
  accountNumber: string;
  ifscCode: string;
  bankName: string;
  upiId?: string;
}

// Interface for Cancellation & Settlement Details
export interface ICancellationDetails {
  reason: string;
  refundStatus: "SETTLED" | "PARTIALLY_REFUNDED" | "FULLY_REFUNDED";
  refundAmount: number;
  settledAmount: number;
  isSettled: boolean;
  settledWithOrderId?: Types.ObjectId;
}

// Main Order Interface
export interface IOrder extends Document {
  _id: string;
  customerName: string;
  branchId: Types.ObjectId;
  tableId?: Types.ObjectId;
  status: IOrderStatus;
  items: IOrderItem[];
  totalAmount: number;
  orderType: IOrderType;
  staffId?: Types.ObjectId;
  paymentStatus: IPaymentStatus;
  paymentMethod: IPaymentMethod;
  paymentDetails?: IPaymentDetails;
  cancellationDetails?: ICancellationDetails;
  isDeleted: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}
// Define the schema for the Order model
const orderSchema: Schema<IOrder> = new mongoose.Schema<IOrder>(
  {
    customerName: { type: String, required: true },
    branchId: { type: mongoose.Schema.Types.ObjectId, ref: "Branch", required: true },
    tableId: {
      type: mongoose.Schema.Types.ObjectId, ref: "Table", required: function () {
        return this.orderType === "DINE_IN";
      },
    },
    status: {
      type: String,
      enum: orderConstant.orderStatus,
      default: "PENDING",
    },
    items: [
      {
        menuItemId: { type: mongoose.Schema.Types.ObjectId, ref: "MenuItem", required: true },
        quantity: { type: Number, required: true },
        price: { type: Number, required: true, min: 1 },
        instructions: { type: String },
        _id: false,
      },
    ],
    totalAmount: { type: Number, required: true, min: 1 },
    orderType: {
      type: String,
      enum: orderConstant.orderType,
      required: true,
    },
    staffId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    paymentStatus: {
      type: String,
      enum: orderConstant.paymentStatus,
      default: "INITIATED",
    },
    paymentMethod: {
      type: String,
      enum: orderConstant.paymentMethod,
      required: true,
    },
    paymentDetails: {
      paymentId: { type: String },
      orderId: { type: String },
      signature: { type: String },
    },
    cancellationDetails: {
      reason: { type: String, trim: true },
      refundStatus: { type: String, enum: ["SETTLED", "PARTIALLY_REFUNDED", "FULLY_REFUNDED"] },
      refundAmount: { type: Number, min: 0 },
      settledAmount: { type: Number, min: 0 },
      isSettled: { type: Boolean, default: false },
      settledWithOrderId: { type: mongoose.Schema.Types.ObjectId, ref: "Order" },
    },
    isDeleted: { type: Boolean, default: false },
  },
  {
    timestamps: true,
  }
);

const OrderModel: Model<IOrder> = mongoose.model<IOrder>("Order", orderSchema);

export default OrderModel;
