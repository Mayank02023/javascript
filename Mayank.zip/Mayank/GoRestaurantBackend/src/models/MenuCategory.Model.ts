import mongoose, { Document, Model, Schema, Types } from "mongoose";

// Define the interface for the MenuCategory model
export interface IMenuCategory extends Document {
    branchId: mongoose.Types.ObjectId;
    name: string;
    description?: string;
    createdAt?: Date;
    updatedAt?: Date;
}

// Define the schema for the MenuCategory model
const menuCategorySchema: Schema<IMenuCategory> = new mongoose.Schema<IMenuCategory>(
    {
        branchId: { type: mongoose.Schema.Types.ObjectId, ref: "Branch", required: true, index: true },
        name: { type: String, required: true, unique: true, index: true },
        description: { type: String },
    },
    {
        timestamps: true,
    }
);

// Create the model based on the schema
const MenuCategoryModel: Model<IMenuCategory> = mongoose.model<IMenuCategory>(
    "MenuCategory",
    menuCategorySchema
);

// Export the MenuItem category model for use in other files
export default MenuCategoryModel;