import {Types, Document} from "mongoose";

interface IAgentTransaction extends Document {
    amount: number;
    type: "credit" | "debit";
    description: string;
    AgentId: Types.ObjectId;
    createdAt?: Date;
    updatedAt?: Date;
}