import mongoose, { Document, Model, Schema, Types } from 'mongoose';

export interface IPlan extends Document {
  name: string;
  description: string;
  price: number;
  duration: 'monthly' | "halfYearly" | 'yearly'; // Or any other plan duration
  features: string[]; // List of features in the plan
  status: 'active' | 'inactive'; // Plan status
  createdAt?: Date;
  updatedAt?: Date;
}

const planSchema: Schema<IPlan> = new mongoose.Schema<IPlan>(
  {
    name: { type: String, required: true, unique: true },
    description: { type: String, required: true },
    price: { type: Number, required: true },
    duration: { type: String, enum: ['monthly', 'yearly'], required: true },
    features: { type: [String], required: true },
    status: { type: String, enum: ['active', 'inactive'], default: 'active' }
  },
  {
    timestamps: true
  }
);

const Plan: Model<IPlan> = mongoose.model<IPlan>('Plan', planSchema);

export default Plan;
