import mongoose, { Document, Model, Schema, Types } from "mongoose";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { ApiError } from "../utils";
import envConfig from "../config/envConfig";

export interface IAgentBankDetail {
  accountNumber: string;
  ifscCode: string;
  bankName: string;
  accountHolderName: string;
  inUse: boolean;
}

export interface IAgentTransaction {
  amount: number;
  type: "credit" | "debit";
  description: string;
  date: Date;
}

export interface IAgent extends Document {
  _id: string;
  name: string;
  username: string;
  password: string;
  email?: string;
  phoneNumber: string;
  avatar: string;
  assignedRestaurants: Types.ObjectId[]; // Reference to Restaurant models
  role: "agent";
  status: "active" | "inactive";
  bankDetails: IAgentBankDetail[];
  transactions: IAgentTransaction[];
  isLoggedIn?: boolean;
  refreshToken?: string;
  createdAt?: Date;
  updatedAt?: Date;
  isPasswordCorrect(password: string): Promise<boolean>;
  generateAccessToken(): string;
  generateRefreshToken(): string;
}

const bankDetailsSchema: Schema<IAgentBankDetail> = new mongoose.Schema<IAgentBankDetail>(
  {
    accountNumber: { type: String, required: true },
    ifscCode: { type: String, required: true },
    bankName: { type: String, required: true },
    accountHolderName: { type: String, required: true },
  }, { _id: false }
);

const transactionSchema: Schema<IAgentTransaction> = new mongoose.Schema<IAgentTransaction>(
  {
    amount: { type: Number, required: true },
    type: { type: String, enum: ["credit", "debit"], required: true },
    description: { type: String, required: true },
    date: { type: Date, default: Date.now },
  }, { _id: false }
);

const agentSchema: Schema<IAgent> = new mongoose.Schema<IAgent>(
  {
    name: { type: String, required: true },
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phoneNumber: { type: String, required: true },
    avatar: { type: String, default: "/path/to/default/avatar.png" },
    assignedRestaurants: [
      { type: mongoose.Schema.Types.ObjectId, ref: "Restaurant" },
    ],
    role: { type: String, default: "agent" },
    status: { type: String, enum: ["active", "inactive"], default: "active" },
    bankDetails: { type: [bankDetailsSchema], default: undefined },
    transactions: { type: [transactionSchema], default: undefined },
    refreshToken: { type: String },
  },
  {
    timestamps: true,
  }
);

// Pre-save hook to hash the password
agentSchema.pre<IAgent>("save", async function (next) {
  if (!this.isModified("password")) return next();

  try {
    const hashedPassword = await bcrypt.hash(this.password, 10);
    this.password = hashedPassword;
    next();
  } catch (err: any) {
    next(err);
  }
});

// Method to compare passwords
agentSchema.methods.isPasswordCorrect = async function (password: string) {
  return await bcrypt.compare(password, this.password);
};

// Method to generate an access token
agentSchema.methods.generateAccessToken = function () {
  try {
    const token = jwt.sign(
      {
        id: this._id,
        name: this.name,
        username: this.username,
        role: this.role,
      },
      envConfig.ACCESS_TOKEN_SECRET,
      {
        expiresIn: envConfig.ACCESS_TOKEN_EXPIRY,
      }
    );
    return token;
  } catch (err) {
    console.error("Error generating access token:", err);
    throw new ApiError(500, "Failed to generate access token.");
  }
};

// Method to generate a refresh token
agentSchema.methods.generateRefreshToken = function () {
  try {
    const token = jwt.sign(
      {
        id: this._id,
      },
      envConfig.REFRESH_TOKEN_SECRET,
      {
        expiresIn: envConfig.REFRESH_TOKEN_EXPIRY,
      }
    );
    return token;
  } catch (err) {
    console.error("Error generating refresh token:", err);
    throw new ApiError(500, "Failed to generate refresh token.");
  }
};

// Method to validate refresh token
agentSchema.methods.isRefreshTokenValid = function (): boolean {
  try {
    jwt.verify(this.refreshToken!, envConfig.REFRESH_TOKEN_SECRET);
    return true;
  } catch {
    return false;
  }
};

const AgentSchema: Model<IAgent> = mongoose.model<IAgent>("Agent", agentSchema);

export default AgentSchema;
