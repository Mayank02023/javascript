import mongoose, { Document, Model, Schema, Types } from "mongoose";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { ApiError } from "../utils"; // Adjust the path as per your project structure
import envConfig from "../config/envConfig";

export interface IUserDemographic {
  address?: string | null;
  city?: string | null;
  state?: string | null;
  country?: string | null;
  pincode?: string | null;
  dob?: Date | null;
  aadharCard?: string | null;
  panCard?: string | null;
}

// Main User Interface
export interface IUser extends Document {
  _id: string;
  name: string
  username: string;
  password: string;
  email?: string;
  phoneNumber: string;
  avatar?: string;
  role: "owner" | "manager" | "staff";

  restaurantId?: Types.ObjectId;
  branchId?: Types.ObjectId;
  shiftId?: Types.ObjectId;
  positionId?: Types.ObjectId;
  demographic?: IUserDemographic;

  isLoggedIn?: boolean;
  status?: "active" | "inactive";
  refreshToken?: string;
  createdAt?: Date;
  updatedAt?: Date;

  isPasswordCorrect(password: string): Promise<boolean>;
  generateAccessToken(): string;
  generateRefreshToken(): string;
  isRefreshTokenValid(): boolean;
}

const userDemographicSchema: Schema<IUserDemographic> = new mongoose.Schema<IUserDemographic>(
  {
    address: { type: String },
    city: { type: String },
    state: { type: String },
    country: { type: String },
    pincode: { type: String },
    dob: { type: Date },
    aadharCard: { type: String },
    panCard: { type: String },
  }, {
  _id: false
}
)

const userSchema: Schema<IUser> = new mongoose.Schema<IUser>(
  {
    name: { type: String, required: true },
    username: { type: String, required: true, unique: true, index: true },
    password: {
      type: String,
      required: true,
      minlength: 8,
      validate: {
        validator: (v: string) =>
          /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/.test(v),
        message:
          "Password must be at least 8 characters long and contain letters and numbers.",
      },
    },
    email: {
      type: String,
      unique: true,
      validate: {
        validator: (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
        message: props => `${props.value} is not a valid email address!`,
      },
    },
    phoneNumber: { type: String, required: true },
    avatar: { type: String, default: "/path/to/default/avatar.png" },
    role: { type: String, enum: ["owner", "manager", "staff"], required: true },
    restaurantId: { type: Types.ObjectId, ref: "Restaurant", index: true },
    branchId: { type: Types.ObjectId, ref: "Branch", index: true },
    shiftId: { type: Types.ObjectId, ref: "Shift" },
    positionId: { type: Types.ObjectId, ref: "Position" },
    demographic: { type: userDemographicSchema, default: null },
    isLoggedIn: { type: Boolean, default: false },
    status: { type: String, enum: ["active", "inactive"], default: "active" },
    refreshToken: { type: String },
  },
  {
    timestamps: true,
    strict: true, // Prevent saving undefined fields
  }
);

// Pre-save hook to hash the password
userSchema.pre<IUser>("save", async function (next) {
  if (!this.isModified("password")) return next();

  try {
    const hashedPassword = await bcrypt.hash(this.password, 10);
    this.password = hashedPassword;
    next();
  } catch (err: any) {
    next(new ApiError(500, "Error hashing password"));
  }
});

// Method to compare passwords
userSchema.methods.isPasswordCorrect = async function (
  password: string
): Promise<boolean> {
  return bcrypt.compare(password, this.password);
};

// Method to generate an access token
userSchema.methods.generateAccessToken = function (): string {
  return jwt.sign(
    {
      id: this._id,
      username: this.username,
      role: this.role,
    },
    envConfig.ACCESS_TOKEN_SECRET,
    {
      expiresIn: envConfig.ACCESS_TOKEN_EXPIRY,
    }
  );
};

// Method to generate a refresh token
userSchema.methods.generateRefreshToken = function (): string {
  return jwt.sign(
    {
      id: this._id,
      role: this.role,
    },
    envConfig.REFRESH_TOKEN_SECRET,
    {
      expiresIn: envConfig.REFRESH_TOKEN_EXPIRY,
    }
  );
};

// Method to validate refresh token
userSchema.methods.isRefreshTokenValid = function (): boolean {
  try {
    jwt.verify(this.refreshToken!, envConfig.REFRESH_TOKEN_SECRET);
    return true;
  } catch {
    return false;
  }
};

// Create and export the model
const UserModel: Model<IUser> = mongoose.model<IUser>("User", userSchema);

export default UserModel;
