import mongoose, { Document, Model, Schema, Types } from "mongoose";

// Define the interface for the Branch model
export interface IBranch extends Document {
  _id: string;
  name: string;
  address: string;
  restaurantId: Types.ObjectId; // Reference to Restaurant model
  managerId?: Types.ObjectId; // Optional reference to User model (Branch manager)
  tables: Types.ObjectId[]; // Reference to Table models
  status: 'open' | 'closed'; // Branch status
  isDelete: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

// Define the schema for the Branch model
const branchSchema: Schema<IBranch> = new mongoose.Schema<IBranch>(
  {
    name: { type: String, required: true },
    address: { type: String, required: true },
    restaurantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true },
    managerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    tables: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Table', default: null }],
    status: { type: String, enum: ['open', 'closed'], default: 'open' },
    isDelete: { type: Boolean, default: false }
  },
  {
    timestamps: true // Automatically manage createdAt and updatedAt fields
  }
);

// Create the model based on the schema
const BranchSchema: Model<IBranch> = mongoose.model<IBranch>("Branch", branchSchema);

// Export the Branch model for use in other files
export default BranchSchema;
