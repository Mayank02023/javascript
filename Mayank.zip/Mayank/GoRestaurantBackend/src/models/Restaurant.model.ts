import mongoose, { Document, Model, Schema, Types } from 'mongoose';



// Review Schema
export interface IReview extends Document {
  restaurantId: Types.ObjectId;  // Reference to Restaurant model
  rating: number;          // Rating given by the user (1-5)
  comment: string;         // Review comment
  createdAt?: Date;
  updatedAt?: Date;
}

export interface IRestaurant extends Document {
  _id: string;
  name: string;
  address: string;
  phoneNumber: string;
  email?: string;
  avatar?: string;
  coverImage?: string;
  ownerId?: Types.ObjectId; // Restaurant Owner (reference to User model)
  agentId?: Types.ObjectId; // Agent who registered the restaurant (reference to Agent model)
  branches?: Types.ObjectId[]; // Reference to Branch models
  subscriptionPlan?: Types.ObjectId;
  status: 'active' | 'inactive';
  isDelete: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

const reviewSchema: Schema<IReview> = new mongoose.Schema<IReview>(
  {
    restaurantId: { type: mongoose.Schema.Types.ObjectId, ref: "Restaurant", required: true },
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, required: true },
  },
  {
    timestamps: true
  }
);

const restaurantSchema: Schema<IRestaurant> = new mongoose.Schema<IRestaurant>(
  {
    name: { type: String, required: true },
    address: { type: String, required: true },
    phoneNumber: { type: String, required: true },
    avatar: { type: String, default: null },
    coverImage: { type: String, default: null },
    email: { type: String, unique: true, default: undefined },
    ownerId: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null }, // Reference to User model (Restaurant Owner)
    agentId: { type: mongoose.Schema.Types.ObjectId, ref: "Agent", default: null }, // Reference to Agent model
    branches: { type: [{ type: mongoose.Schema.Types.ObjectId, ref: "Branch" }], default: null }, // Reference to Branch models
    subscriptionPlan: { type: mongoose.Schema.Types.ObjectId, ref: "Plan", default: null },
    status: { type: String, enum: ["active", "inactive"], default: "active" },
    isDelete: { type: Boolean, default: false }
  },
  {
    timestamps: true
  }
);

const RestaurantSchema: Model<IRestaurant> = mongoose.model<IRestaurant>("Restaurant", restaurantSchema);

const ReviewSchema: Model<IReview> = mongoose.model<IReview>("Review", reviewSchema);

export { RestaurantSchema, ReviewSchema };