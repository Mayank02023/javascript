import mongoose, { Document, Model, Schema, Types } from "mongoose";

export interface ITable extends Document {
  _id: Types.ObjectId;
  capacity: number;
  branchId: Types.ObjectId;
  status: 'occupied' | 'partially occupied' | 'available';
  occupiedSeats: number;
  createdAt?: Date;
  updatedAt?: Date;
}

const tableSchema: Schema<ITable> = new mongoose.Schema<ITable>(
  {
    capacity: { type: Number, required: true },
    branchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch', required: true, index: true },
    status: {
      type: String,
      enum: ['occupied', 'partially occupied', 'available'],
      default: 'available'
    },
    occupiedSeats: {
      type: Number,
      default: 0,
      validate: {
        validator: function (value: number) {
          return value <= this.capacity;
        },
        message: 'Occupied seats cannot exceed table capacity.'
      }
    }
  },
  {
    timestamps: true
  }
);

tableSchema.pre('save', function (next) {
  if (this.occupiedSeats > 0 && this.occupiedSeats < this.capacity) {
    this.status = 'partially occupied';
  } else if (this.occupiedSeats === 0) {
    this.status = 'available';
  } else if (this.occupiedSeats === this.capacity) {
    this.status = 'occupied';
  }
  next();
});


const TableModel: Model<ITable> = mongoose.model<ITable>("Table", tableSchema);

export default TableModel;
