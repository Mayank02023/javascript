import mongoose, { Document, Model, Schema, Types } from "mongoose";

// Define the interface for the Subscription model
export interface ISubscription extends Document {
  restaurant: Types.ObjectId; // Reference to the Restaurant model
  plan: 'basic' | 'premium' | 'enterprise'; // The subscription plan
  startDate: Date; // The subscription start date
  endDate?: Date; // The subscription end date (optional)
  status: 'active' | 'expired'; // The current status of the subscription
  createdAt?: Date;
  updatedAt?: Date;
}

// Define the schema for the Subscription model
const subscriptionSchema: Schema<ISubscription> = new mongoose.Schema<ISubscription>(
  {
    restaurant: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true },
    plan: { type: String, enum: ['basic', 'premium', 'enterprise'], required: true },
    startDate: { type: Date, default: Date.now },
    endDate: { type: Date },
    status: { 
      type: String, 
      enum: ['active', 'expired'], 
      default: 'active' 
    }
  },
  {
    timestamps: true // Automatically manage createdAt and updatedAt fields
  }
);

// Create the model based on the schema
const Subscription: Model<ISubscription> = mongoose.model<ISubscription>("Subscription", subscriptionSchema);

// Export the Subscription model for use in other files
export default Subscription;
