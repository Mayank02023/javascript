import mongoose, { Document, Model, Schema, Types } from "mongoose";

// Define the interface for the MenuItem model
export interface IMenuItem extends Document {
  _id: mongoose.Types.ObjectId;
  branchId: mongoose.Types.ObjectId;
  name: string;
  description?: string;
  price: number;
  avatar?: string;
  categoryId: mongoose.Types.ObjectId;
  ingredients: mongoose.Types.ObjectId[];
  availability: boolean;
  isDelete: boolean;
  createdAt: Date;
  updatedAt: Date;
}



// Define the schema for the MenuItem model
const menuItemSchema: Schema<IMenuItem> = new mongoose.Schema<IMenuItem>(
  {
    name: { type: String, required: true },
    description: { type: String },
    avatar: { type: String, default: "/path/to/default/avatar.png" },
    price: { type: Number, required: true },
    categoryId: { type: mongoose.Schema.Types.ObjectId, ref: 'MenuCategory' },
    branchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch' },
    ingredients: [
      { type: mongoose.Schema.Types.ObjectId, ref: "Inventory" },
    ],
    availability: { type: Boolean, default: true },
    isDelete: { type: Boolean, default: false }
  },
  {
    timestamps: true
  }
);



// Create the model based on the schema
const MenuItemModel: Model<IMenuItem> = mongoose.model<IMenuItem>("MenuItem", menuItemSchema);

// Export the MenuItem model for use in other files
export default MenuItemModel;
