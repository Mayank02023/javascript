import mongoose, { Document, Model, Schema } from "mongoose";

export interface IInventory extends Document {
  _id: mongoose.Types.ObjectId;
  branchId: mongoose.Types.ObjectId;
  name: string;
  description: string;
  quantity: number;
  unit: string;
  lowStockThreshold: number;
  restockDate?: Date;
  status: "inStock" | "lowStock" | "outOfStock";
  isDelete: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Define the schema for the Inventory model
const inventorySchema: Schema<IInventory> = new mongoose.Schema<IInventory>(
  {
    branchId: { type: mongoose.Schema.Types.ObjectId, ref: "Branch", required: true, index: true },
    name: { type: String, required: true, index: true },
    description: { type: String, default: "" },
    quantity: { type: Number, required: true, min: 0 },
    unit: { type: String, required: true },
    lowStockThreshold: { type: Number, required: true, min: 0 },
    restockDate: { type: Date },
    status: { type: String, enum: ["inStock", "lowStock", "outOfStock"], default: "inStock" },
    isDelete: { type: Boolean, default: false }
  },
  {
    timestamps: true,
  }
);

// Index to quickly find items below the low stock threshold for a branch
inventorySchema.index({ branchId: 1, quantity: 1, lowStockThreshold: 1 });

// Pre-save hook to handle the status before saving
inventorySchema.pre<IInventory>("save", function (next) {
  // Automatically update the status based on the quantity and lowStockThreshold
  if (this.quantity <= 0) {
    this.status = "outOfStock";
  } else if (this.quantity <= this.lowStockThreshold) {
    this.status = "lowStock";
  } else {
    this.status = "inStock";
  }

  next();
});

// Create the model based on the schema
const InventoryModel: Model<IInventory> = mongoose.model<IInventory>("Inventory", inventorySchema);

export default InventoryModel;
