import { Types } from "mongoose";

export interface IRestaurantDto {
    name: string;
    address: string;
    phoneNumber: string;
    email?: string;
    avatar?: string;
    coverImage?: string;
    agentId?: string;
    ownerId?: string;
    branch?: string; // Reference to Branch models
    subscriptionPlan?: string;
    status?: 'active' | 'inactive';
    isDelete?: boolean;
}

export interface IBranchDto {
    name: string;
    address: string;
    restaurantId?: string; // Reference to Restaurant model
    managerId?: string; // Optional reference to User model (Branch manager)
    table?: string; // Reference to Table models
    status?: 'open' | 'closed'; // Branch status
    isDelete?: boolean;
}

export interface IRestaurantResponse{
    _id: string;
    name: string;
    address: string;
    phoneNumber: string;
    email?: string;
    avatar?: string;
    coverImage?: string;
    owner?: Types.ObjectId; // Restaurant Owner (reference to User model)
    agentId?: Types.ObjectId; // Agent who registered the restaurant (reference to Agent model)
    branches?: Types.ObjectId[]; // Reference to Branch models
    subscriptionPlan?: Types.ObjectId;
    status: 'active' | 'inactive';
    isDelete: boolean;
    createdAt?: Date;
    updatedAt?: Date;
}