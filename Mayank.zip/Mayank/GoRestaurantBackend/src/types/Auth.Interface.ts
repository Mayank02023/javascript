import { Request } from "express";
import { IUser } from "../models/User.model";
import { IAgent } from "../models/Agent.model";
import { ISuperAdmin } from "../models/SuperAdmin.model";

export interface AuthRequest extends Request {
    user?: IUser | IAgent | ISuperAdmin;
    child?: any
}

export type Role = "superAdmin" | "agent" | "owner" | "manager" | "staff";

// Interface for UserDto
export interface IUserDto {
    name: string
    username: string;
    password: string;
    email?: string;
    restaurantId: string;
    branchId?: string;
    phoneNumber: string;
    avatar?: string;
    role: "owner" | "manager" | "staff";
}


export interface IAuthCredential {
    username: string | undefined;
    phoneNumber: string | undefined;
    password: string;
}

export interface ITokenResponse {
    accessToken: string;
    refreshToken: string;
}

export interface IChangePasswordRequest {
    oldPassword: string;
    newPassword: string;
    objectId: string;
}