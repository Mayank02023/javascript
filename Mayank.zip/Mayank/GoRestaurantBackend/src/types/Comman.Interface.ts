export interface IPaginationOptions {
    page: number;
    pageSize: number;
    limit: number;
    skip: number;
    sort?: any;
    projection?: any
}

export interface IPagination {
    pageSize: number;
    skip: number;
}

export type IOrderStatus = "PENDING" | "CONFIRMED" | "PREPARING" | "READY" | "COMPLETED" | "CANCELLED";

export type IOrderType = "DINE_IN" | "TAKEAWAY";

export type IPaymentStatus = "INITIATED" | "SUCCESS" | "FAILED";

export type IPaymentMethod = "CASH" | "ONLINE";