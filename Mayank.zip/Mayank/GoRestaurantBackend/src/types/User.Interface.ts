import { Types } from "mongoose";

// Interface for UserDemographic
export interface IUserDemographicDto {
    address?: string | null;
    city?: string | null;
    state?: string | null;
    country?: string | null;
    pincode?: string | null;
    dob?: Date | null;
    aadharCard?: string | null;
    panCard?: string | null;
}

// Interface for UserResponse
export interface IUserResponse {
    id: Types.ObjectId; // Unique identifier for the user
    username: string;
    email?: string | null;
    phoneNumber: string;
    avatar?: string | null;
    role: "owner" | "manager" | "staff";
    restaurantId?: Types.ObjectId | null;
    branchId?: Types.ObjectId | null;
    shiftId?: Types.ObjectId | null;
    positionId?: Types.ObjectId | null;
    demographic?: IUserDemographicDto | null;
    isLoggedIn: boolean;
    status: "active" | "inactive";
    createdAt: Date;
    updatedAt: Date;
}


export interface IAuthCredential {
    username: string | undefined;
    phoneNumber: string | undefined;
    password: string;
}

export interface IUserProfileResponse extends Partial<IUserResponse> {
    restaurant?: {
        id: string;
        name: string;
    },
    branches?: {
        id: string;
        name: string;
    }[]
}