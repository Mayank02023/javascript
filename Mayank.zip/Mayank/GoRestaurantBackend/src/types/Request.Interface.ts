import mongoose from "mongoose";
import { IOrderStatus, IOrderType, IPaymentMethod, IPaymentStatus } from "./Comman.Interface";

export
  interface ITableRequest {
  _id: string;
  capacity: number;
  branchid: string;
  status: 'occupied' | 'partially occupied' | 'available';
  occupiedSeats: number;
}
export interface IInventoryRequest {
  branchId: string | mongoose.Types.ObjectId;
  name: string;
  description: string;
  quantity: number
  unit: string;
  lowStockThreshold: number;
  restockDays: number;
}

export interface IMenuCategoryRequest {
  name: string;
  description: string;
}

export interface IMenuItemRequest {
  name: string;
  description: string;
  price: number;
  avatar?: string;
  categoryId: string;
  ingredients: string[];
  availability?: boolean;
}

export interface IOrderRequest {
  customerName: string;
  branchId: string;
  tableId: string;
  person: number;
  items: {
    menuItemId: string;
    price: number;
    quantity: number;
    instructions?: string;
  }[];
  totalAmount: number;
  paymentDetails?: {
    paymentId: string;
    orderId: string;
    signature: string;
  };
  paymentMethod: IPaymentMethod;
  status?: IOrderStatus;
  orderType: IOrderType;
  paymentStatus?: IPaymentStatus;
  staffId?: string;
}