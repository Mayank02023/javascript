import { Types } from "mongoose";
import { IRestaurant } from "../models/Restaurant.model";

// Interface for AgentDto
export interface IAgentDto {
    name: string
    username: string;
    password: string;
    email?: string;
    phoneNumber: string;
    avatar?: string;
}

interface IAgentBankDetail {
    accountNumber: string;
    ifscCode: string;
    bankName: string;
    accountHolderName: string;
    inUse: boolean;
}

interface IAgentTransaction {
    amount: number;
    type: "credit" | "debit";
    description: string;
    date: Date;
}

export interface IAgentResponse extends Document {
    _id: string;
    name: string;
    username: string;
    email?: string;
    phoneNumber: string;
    avatar: string;
    assignedRestaurants: Types.ObjectId[]; // Reference to Restaurant models
    role: "agent";
    status: "active" | "inactive";
    bankDetails: IAgentBankDetail[];
    transactions: IAgentTransaction[];
    isLoggedIn?: boolean;
    createdAt?: Date;
    updatedAt?: Date;
}

export interface IAgentProfileResponse extends Partial<IAgentResponse> {
    restaurants: IRestaurant[],
}