import { Response, NextFunction } from "express";
import { AuthRequest, Role } from "../types/Auth.Interface";
import { ApiError, asyncHandler, sendErrorResponse } from "../utils";
import { isRoleAllowed } from "../utils/accessCheck";
import branchService from "../services/Branch.Service";
import userService from "../services/User.Service";
import tableService from "../services/Table.Service";
import inventoryService from "../services/Inventory.Service";
import menuCategoryService from "../services/MenuCategory.Service";
import { IUser } from "../models/User.model";
import { IAgent } from "../models/Agent.model";
import { ISuperAdmin } from "../models/SuperAdmin.model";
import mongoose from "mongoose";
import menuService from "../services/Menu.Service";


const validateBranchChildAccess = async (branchId: mongoose.Types.ObjectId, user: IUser | IAgent | ISuperAdmin) => {
    // Role-specific branch validation
    if (user.role === "agent" || user.role === "owner") {
        const branch = await branchService.getBranchById(branchId.toString());
        if (!branch) throw ApiError.notFound("Branch not found.");

        if (user.role === "agent") {
            const hasAccess = user.assignedRestaurants.some(
                (restaurant) => restaurant.equals(branch.restaurantId)
            );
            if (!hasAccess) {
                throw ApiError.forbidden("Agent does not have access to this resource.");
            }
        } else if (user.role === "owner") {
            if (!user.restaurantId?.equals(branch.restaurantId)) {
                throw ApiError.forbidden("Owner does not have access to this resource.");
            }
        }
    }

    // Direct branch access for manager or staff roles
    if (user.role === "manager" || user.role === "staff") {
        if (!user.branchId?.equals(branchId)) {
            throw ApiError.forbidden("User does not have access to this resource.");
        }
    }
};

// Middleware to check role access of the authenticated user
export const roleCheck = (allowedRoles: Role[]) => {
    return asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const user = req.user; // Assuming `req.user` contains the authenticated user's details

            if (!user) {
                throw ApiError.unauthorized("Unauthorized");
            }

            if (!isRoleAllowed(user.role, allowedRoles)) {
                throw ApiError.forbidden("Access denied");
            }

            return next();
        } catch (error: any) {
            sendErrorResponse(error, "Role Check Middleware", res);
        }
    });
};

// Middleware to check agent access
export const agentAccessCheck = (allowedRoles: Role[]) => {
    return asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const { agentId } = req.params;
            const user = req.user;

            if (!user) {
                throw ApiError.unauthorized("Unauthorized: User not authenticated.");
            }

            // Check if the user's role is allowed
            if (!isRoleAllowed(user.role, allowedRoles)) {
                throw ApiError.forbidden("Access Denied: Role not authorized.");
            }

            // Allow superAdmin access
            if (user.role === "superAdmin") {
                return next();
            }

            // Specific check for "agent" role
            if (user.role === "agent") {
                if (user._id.toString() === agentId) {
                    return next();
                }
                throw ApiError.badRequest("Access Denied: You cannot access another agent's data.");
            }

            // Default case for unhandled roles
            throw ApiError.forbidden("Access Denied: Invalid role.");
        } catch (error: any) {
            sendErrorResponse(error, "User Access Controller Middleware", res);
        }
    });
};

// Middleware to check user access
export const userAccessCheck = (allowedRoles: Role[]) => {
    return asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const { userId } = req.params;
            const user = req.user;
            const userData = await userService.getUserById(userId);

            if (!user) throw ApiError.unauthorized("Unauthorized: User not authenticated.");

            // Check if the user's role is allowed
            if (!isRoleAllowed(user.role, allowedRoles)) {
                throw ApiError.forbidden("Access Denied: Role not authorized.");
            }

            // SuperAdmin always has access
            if (user.role === "superAdmin") {
                return next();
            }

            // Agent role
            if (user.role === "agent") {
                const hasAccess = user.assignedRestaurants.some(
                    (restaurant) => restaurant.toString() === userData.restaurantId?.toString()
                );
                if (!hasAccess) throw ApiError.forbidden("Agent does not have access to this restaurant.");
                return next();
            }
            if ((user.role === "owner" || user.role === "manager" || user.role === "staff") && user._id === userData._id) {
                return next();
            }
            // Owner role
            if (user.role === "owner") {
                if (!userData?.restaurantId) throw ApiError.badRequest("User does not have any associated restaurant.");
                if (user.restaurantId?.toString() !== userData?.restaurantId?.toString()) {
                    throw ApiError.forbidden("Owner does not have access to this resource.");
                }
                return next();
            }

            // Manager role
            if (user.role === "manager") {
                if (!userData?.branchId) throw ApiError.badRequest("User does not have any associated branch.");
                if (user.branchId?.toString() !== userData?.branchId?.toString()) {
                    throw ApiError.forbidden("Manager does not have access to this branch.");
                }
                return next();
            }

            // Staff role
            if (user.role === "staff") {
                if (user._id?.toString() !== userData?._id?.toString()) {
                    throw ApiError.forbidden("Staff does not have access to this resource.");
                }
                return next();
            }

            // Default: Handle unhandled roles explicitly
            throw ApiError.forbidden("Access Denied: Role not recognized.");
        } catch (error: any) {
            sendErrorResponse(error, "User Access Controller Middleware", res);
        }
    });
};

// Middleware to check restaurant access
export const restaurantAccessCheck = (allowedRoles: Role[]) => {
    return asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const user = req.user;
            if (!user) throw ApiError.unauthorized("Unauthorized user!");

            if (!isRoleAllowed(user.role, allowedRoles)) throw ApiError.forbidden("Access denied");

            const restaurantId: string = req.params.restaurantId;
            if (!restaurantId) throw ApiError.badRequest("Restaurant ID is required.");

            if (user.role === "agent") {
                const hasAccess = user.assignedRestaurants.some(
                    (restaurant) => restaurant.toString() === restaurantId
                );
                if (!hasAccess) {
                    throw ApiError.forbidden("Agent does not have access to this resource.");
                }
            } else if (
                user.role === "owner" ||
                user.role === "manager" ||
                user.role === "staff"
            ) {
                if (user.restaurantId?.toString() !== restaurantId) {
                    throw ApiError.forbidden("User does not have access to this resource.");
                }
            }

            next();
        } catch (error: any) {
            sendErrorResponse(error, "Restaurant Access Check Middleware", res);
        }
    });
};

// Middleware to check branch access
export const branchAccessCheck = (allowedRoles: Role[]) => {
    return asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const user = req.user;
            if (!user) throw ApiError.unauthorized("Unauthorized user!");

            if (!isRoleAllowed(user.role, allowedRoles)) throw ApiError.forbidden("Access denied");

            const branchId: string = req.params.branchId;
            if (!branchId) throw ApiError.badRequest("Branch ID is required.");

            // Role-specific branch validation
            if (user.role === "agent" || user.role === "owner") {
                const branch = await branchService.getBranchById(branchId);
                if (!branch) throw ApiError.notFound("Branch not found.");

                if (user.role === "agent") {
                    const hasAccess = user.assignedRestaurants.some(
                        (restaurant) => restaurant.toString() === branch.restaurantId.toString()
                    );
                    if (!hasAccess) throw ApiError.forbidden("Agent does not have access to this resource.");
                } else if (user.role === "owner") {
                    if (user.restaurantId?.toString() !== branch.restaurantId.toString()) {
                        throw ApiError.forbidden("Owner does not have access to this resource.");
                    }
                }
            }

            // Direct branch access for manager or staff roles
            if (user.role === "manager" || user.role === "staff") {
                if (user.branchId?.toString() !== branchId) {
                    throw ApiError.forbidden("User does not have access to this resource.");
                }
            }

            next();
        } catch (error: any) {
            sendErrorResponse(error, "Branch Access Check", res);
        }
    });
};

export const tableAccessCheck = (allowedRoles: Role[]) => {
    return asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const user = req.user;
            if (!user) throw ApiError.unauthorized("Unauthorized user!");

            if (!isRoleAllowed(user.role, allowedRoles)) throw ApiError.forbidden("Access denied");

            const tableId: string = req.params.tableId;
            if (!tableId) throw ApiError.badRequest("Table ID is required.");

            const table = await tableService.getTableById(tableId);
            if (!table) throw ApiError.notFound("Table not found.");

            // Perform branch-child access check
            await validateBranchChildAccess(table.branchId, user);

            next();
        } catch (error: any) {
            sendErrorResponse(error, "Table Access Check", res);
        }
    });
};

export const inventoryAccessCheck = (allowedRoles: Role[]) => {
    return asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const user = req.user;
            if (!user) throw ApiError.unauthorized("Unauthorized user!");

            if (!isRoleAllowed(user.role, allowedRoles)) throw ApiError.forbidden("Access denied");

            const inventoryId: string = req.params.inventoryId;
            if (!inventoryId) throw ApiError.badRequest("Inventory ID is required.");

            const inventory = await inventoryService.getInventoryById(inventoryId);
            if (!inventory) throw ApiError.notFound("Inventory not found.");

            // Perform branch-child access check
            await validateBranchChildAccess(inventory.branchId, user);

            next();
        } catch (error: any) {
            sendErrorResponse(error, "Inventory Access Check", res);
        }
    });
};

export const menuCategoryAccessCheck = (allowedRoles: Role[]) => {
    return asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const user = req.user;
            if (!user) throw ApiError.unauthorized("Unauthorized user!");

            if (!isRoleAllowed(user.role, allowedRoles)) throw ApiError.forbidden("Access denied");

            const menuCategoryId: string = req.params.menuCategoryId;
            if (!menuCategoryId) throw ApiError.badRequest("Menu Category ID is required.");

            const menuCategory = await menuCategoryService.getMenuCategoryById(menuCategoryId);
            if (!menuCategory) throw ApiError.notFound("Menu category not found.");

            // Perform branch-child access check
            await validateBranchChildAccess(menuCategory.branchId, user);

            next();
        } catch (error: any) {
            sendErrorResponse(error, "Menu Category Access Check", res);
        }
    });
};

export const menuAccessCheck = (allowedRoles: Role[]) => {
    return asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const user = req.user;
            if (!user) throw ApiError.unauthorized("Unauthorized user!");

            if (!isRoleAllowed(user.role, allowedRoles)) throw ApiError.forbidden("Access denied");

            const menuItemId: string = req.params.menuItemId;
            if (!menuItemId) throw ApiError.badRequest("Menu Item ID is required.");

            const menuItem = await menuService.getMenuItemById(menuItemId);
            if (!menuItem) throw ApiError.notFound("Menu Item not found.");

            // Perform branch-child access check
            await validateBranchChildAccess(menuItem.branchId, user);

            next();
        } catch (error: any) {
            sendErrorResponse(error, "Menu Category Access Check", res);
        }
    });
};
