import { Response, NextFunction } from 'express';
import jwt, { JwtPayload } from 'jsonwebtoken';
import UserModel, { IUser } from '../models/User.model'; // Assuming User model is where we store user roles
import ApiError from "../utils/apiError";
import { AuthRequest } from '../types/Auth.Interface';
import { asyncHandler, decodeToken, sendErrorResponse } from '../utils';
import AgentSchema, { IAgent } from '../models/Agent.model';
import SuperAdminModel, { ISuperAdmin } from '../models/SuperAdmin.model';

// Function to decode JWT and return the payload
const decodedJWT = async (accessToken: string, accessTokenSecret: string): Promise<JwtPayload> => {
    if (!accessToken) throw ApiError.unauthorized("Unauthorized request");
    try {
        const decodedToken = jwt.verify(accessToken, accessTokenSecret) as JwtPayload;
        return decodedToken;
    } catch (error) {
        throw ApiError.forbidden("Invalid access token");
    }
};

// This middleware will check if the logged-in user has the required role
export const verifyToken = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
        const accessToken = req.cookies?.accessToken || req.header("Authorization")?.replace("Bearer ", "");
        if (!accessToken) {
            throw ApiError.unauthorized("Unauthorized request: No token provided");
        }

        const accessTokenSecret = String(process.env.ACCESS_TOKEN_SECRET);

        // Decode the incoming token
        const decodedToken = decodeToken(accessToken, { secret: accessTokenSecret });
        if (!decodedToken) throw ApiError.unauthorized("Invalid access token");

        // Fetch user/agent based on role
        let user: IUser | IAgent | ISuperAdmin | null = null;

        if (decodedToken.role === "superAdmin") {
            user = await SuperAdminModel.findById(decodedToken.id);
        } else if (decodedToken.role === "agent") {
            user = await AgentSchema.findById(decodedToken.id);
        } else {
            user = await UserModel.findById(decodedToken.id);
        }

        if (!user || user.status === "inactive") {
            throw ApiError.forbidden("Access denied: SuperAdmin/Agent/User inactive or not found");
        }

        req.user = user; // Attach user to the request
        next(); // Proceed to the next middleware/route handler
    } catch (error: any) {
        sendErrorResponse(error, "Token Verification", res);
    }
}
);
