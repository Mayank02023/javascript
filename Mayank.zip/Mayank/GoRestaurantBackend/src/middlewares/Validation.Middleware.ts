import e, { Request, Response, NextFunction } from 'express';
import { IUser, IUserDemographic } from '../models/User.model';
import { ApiError, asyncHandler, sendErrorResponse } from '../utils';
import { IAgent, IAgentBankDetail, IAgentTransaction, } from '../models/Agent.model';
import { AuthRequest } from '../types/Auth.Interface';
import { Types } from 'mongoose';
import { IRestaurantDto } from '../types/Restaurant.Interface';
import { IRestaurant } from '../models/Restaurant.model';
import { IInventoryRequest, IMenuItemRequest, IOrderRequest } from '../types/Request.Interface';
import { orderConstant } from '../constants';

// Middleware to validate the user data fields for registration
export const validateNewUser = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    const {
        name,
        username,
        password,
        phoneNumber,
        role,
        status = undefined
    } = req.body;
    let message: string = "";

    // Check if all the required fields are provided
    if (!name || !username || !password || !phoneNumber || !role) {
        message = "Missing required fields: name, username, password, phoneNumber and role are required.";
        return next(ApiError.badRequest(message));
    }

    // Validate role
    if (!['owner', 'manager', 'staff'].includes(role)) {
        message = `Invalid role. It must be one of: "owner", "manager", or "staff"`;
        return next(ApiError.badRequest(message));
    }

    // Validate status
    if (status && !['active', 'inactive'].includes(status)) {
        message = `Invalid status. It must be one of: "active" or "inactive".`;
        return next(ApiError.badRequest(message));
    }

    // Check if phone number is a valid string (basic validation example)
    if (typeof phoneNumber !== 'string' || phoneNumber.length < 10) {
        message = `Invalid phone number. It must be a string of at least 10 characters.`;
        return next(ApiError.badRequest(message));
    }

    next();
});

// Middleware to validate the agent data fields for registration
export const validateNewAgent = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
    const {
        name,
        username,
        password,
        phoneNumber,
        status = undefined
    } = req.body;
    let message: string = "";

    // Check if all the required fields are provided
    if (!name || !username || !password || !phoneNumber) {
        message = "Missing required fields: name, username, password and phoneNumber are required.";
        return next(ApiError.badRequest(message));
    }

    // Validate status
    if (status && !['active', 'inactive'].includes(status)) {
        message = `Invalid status. It must be one of: "active" or "inactive".`;
        return next(ApiError.badRequest(message));
    }

    // Check if phone number is a valid string (basic validation example)
    if (typeof phoneNumber !== 'string' || phoneNumber.length < 10) {
        message = `Invalid phone number. It must be a string of at least 10 characters.`;
        return next(ApiError.badRequest(message));
    }

    next();
});

// Middleware to validate the user data fields for update the user
export const validateFieldForUpdateUser = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
    const allowedFields: (keyof IUser | `demographic.${keyof IUserDemographic}`)[] = [
        "name",
        "email",
        "phoneNumber",
        "role",
        "restaurantId",
        "branchId",
        "shiftId",
        "positionId",
        "avatar",
        "demographic.address",
        "demographic.city",
        "demographic.state",
        "demographic.country",
        "demographic.pincode",
        "demographic.dob",
        "demographic.aadharCard",
        "demographic.panCard",
        "status",
    ];

    // Extract the fields from the request body
    const updateFields = Object.keys(req.body);

    let message = "";

    // Check if at least one field is provided
    if (updateFields.length === 0) {
        message = "At least one field must be provided for update.";
        return next(ApiError.badRequest(message));
    }

    // Check if all provided fields are allowed
    const invalidFields = updateFields.filter(
        (field) => !allowedFields.includes(field as keyof IUser | `demographic.${keyof IUserDemographic}`)
    );

    if (invalidFields.length > 0) {
        message = `Invalid fields for update: ${invalidFields.join(", ")}`;
        return next(ApiError.badRequest(message));
    }

    // If validation passes, move to the next middleware or handler
    next();
});

// Middleware to validate the agent data fields for update
export const validateFieldForUpdateAgent = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
    const allowedFields: (keyof IAgent | `bankDetails.${keyof IAgentBankDetail}` | `transactions.${keyof IAgentTransaction}`)[] = [
        "name",
        "email",
        "phoneNumber",
        "avatar",
        "role",
        "status",
        "assignedRestaurants",
        "bankDetails", // Array of bankDetails can be partially updated, so each field within it should be allowed
        "transactions", // Array of transactions can be partially updated, so each field within it should be allowed
    ];

    // Extract the fields from the request body
    const updateFields = Object.keys(req.body);

    let message = "";

    // Check if at least one field is provided
    if (updateFields.length === 0) {
        message = "At least one field must be provided for update.";
        return next(ApiError.badRequest(message));
    }

    // Check if all provided fields are allowed
    const invalidFields = updateFields.filter(
        (field) => !allowedFields.includes(field as keyof IAgent | `bankDetails.${keyof IAgentBankDetail}` | `transactions.${keyof IAgentTransaction}`)
    );

    if (invalidFields.length > 0) {
        message = `Invalid fields for update: ${invalidFields.join(", ")}`;
        return next(ApiError.badRequest(message));
    }

    // If validation passes, move to the next middleware or handler
    next();
});

// Middleware to validate the restaurant data field for create new restaurant
export const validateNewRestaurant = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
    const {
        name,
        address,
        phoneNumber,
        email,
        agentId,
    }: IRestaurantDto = req.body;

    let message: string = "";

    // Check if all required fields are provided
    if (!name || !address || !phoneNumber) {
        message = "Missing required fields: name, address, and phoneNumber are required.";
        return next(ApiError.badRequest(message));
    }

    // Validate phone number (basic validation)
    if (typeof phoneNumber !== "string" || phoneNumber.length < 10) {
        message = "Invalid phone number. It must be a string of at least 10 characters.";
        return next(ApiError.badRequest(message));
    }

    // Validate email (if provided)
    if (email && !/^\S+@\S+\.\S+$/.test(email)) {
        message = "Invalid email format.";
        return next(ApiError.badRequest(message));
    }

    // Validate agentId (if provided)
    if (agentId && !Types.ObjectId.isValid(agentId)) {
        message = "Invalid agentId. It must be a valid MongoDB ObjectId.";
        return next(ApiError.badRequest(message));
    }

    next();
});

// Middleware to validate restaurant data fields for updating an existing restaurant
export const validateUpdateRestaurant = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
    const {
        name,
        address,
        phoneNumber,
        email,
        ownerId,
        agentId,
        branches,
        subscriptionPlan,
        status,
    }: IRestaurant = req.body;

    let message: string = "";

    // Check if at least one property is provided for update
    const updateFields = [name, address, phoneNumber, email, ownerId, agentId, branches, subscriptionPlan, status];
    if (updateFields.every(field => field === undefined || field === null)) {
        message = "At least one property must be provided for update.";
        return next(ApiError.badRequest(message));
    }

    // Only validate fields that are provided in the request body
    // If 'name' is provided, validate it
    if (name && typeof name !== "string") {
        message = "Invalid name format. It should be a valid string.";
        return next(ApiError.badRequest(message));
    }

    // If 'address' is provided, validate it
    if (address && typeof address !== "string") {
        message = "Invalid address format. It should be a valid string.";
        return next(ApiError.badRequest(message));
    }

    // Validate phone number if provided
    if (phoneNumber && (typeof phoneNumber !== "string" || phoneNumber.length < 10)) {
        message = "Invalid phone number. It must be a string of at least 10 characters.";
        return next(ApiError.badRequest(message));
    }

    // Validate email if provided
    if (email && !/^\S+@\S+\.\S+$/.test(email)) {
        message = "Invalid email format.";
        return next(ApiError.badRequest(message));
    }

    // Validate owner (if provided, must be a valid MongoDB ObjectId)
    if (ownerId && !Types.ObjectId.isValid(ownerId)) {
        message = "Invalid ownerId. It must be a valid MongoDB ObjectId.";
        return next(ApiError.badRequest(message));
    }

    // Validate agentId (if provided, must be a valid MongoDB ObjectId)
    if (agentId && !Types.ObjectId.isValid(agentId)) {
        message = "Invalid agentId. It must be a valid MongoDB ObjectId.";
        return next(ApiError.badRequest(message));
    }

    // Validate branches (if provided, each branch must be a valid MongoDB ObjectId)
    if (branches && Array.isArray(branches)) {
        for (let branch of branches) {
            if (!Types.ObjectId.isValid(branch)) {
                message = "Invalid branch ID. It must be a valid MongoDB ObjectId.";
                return next(ApiError.badRequest(message));
            }
        }
    }

    // Validate subscriptionPlan (if provided, must be a non-empty string)
    if (subscriptionPlan && typeof subscriptionPlan !== "string") {
        message = "Invalid subscription plan. It should be a valid string.";
        return next(ApiError.badRequest(message));
    }

    // Validate status (if provided, must be either 'active' or 'inactive')
    if (status && status !== 'active' && status !== 'inactive') {
        message = "Invalid status. It must be either 'active' or 'inactive'.";
        return next(ApiError.badRequest(message));
    }

    next();
});

// Middleware to validate the inventory data fields for adding new Inventory
export const validateNewInventory = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
        const branchId: string = req.params.branchId;
        const { name, description, quantity, unit, lowStockThreshold, restockDays }: IInventoryRequest = req.body;

        const missingFields: string[] = [];
        const invalidFields: string[] = [];

        // Collect missing fields
        if (!branchId) missingFields.push("Branch ID");
        if (!name) missingFields.push("Inventory name");
        if (!description) missingFields.push("Description");
        if (quantity === undefined) missingFields.push("Quantity");
        if (!unit) missingFields.push("Unit");
        if (lowStockThreshold === undefined) missingFields.push("Low stock threshold");
        if (restockDays === undefined) missingFields.push("Restock days");

        // Validate numeric fields and collect invalid field errors
        if (quantity !== undefined && (typeof quantity !== 'number' || quantity <= 0)) {
            invalidFields.push("Quantity");
        }
        if (lowStockThreshold !== undefined && (typeof lowStockThreshold !== 'number' || lowStockThreshold <= 0)) {
            invalidFields.push("Low stock threshold");
        }
        if (restockDays !== undefined && (typeof restockDays !== 'number' || restockDays <= 0)) {
            invalidFields.push("Restock days");
        }

        // Combine error messages
        const errors: string[] = [];
        if (missingFields.length > 0) {
            errors.push(`${missingFields.join(", ")} ${missingFields.length == 0 ? "field is" : "fields are"} missing.`);
        }
        if (invalidFields.length > 0) {
            errors.push(`${invalidFields.join(", ")} ${invalidFields.length == 0 ? "is must be a positive number" : "are must be a positive numbers"} .`);
        }

        // If there are any errors, throw a combined error response
        if (errors.length > 0) {
            throw ApiError.badRequest(errors.join(" "));
        }

        next();
    } catch (error: any) {
        sendErrorResponse(error, "Inventory Fields Validation", res);
    }
});

// Middleware to validate the inventory data fields for updating Inventory
export const validateUpdateInventory = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
        const inventoryId: string = req.params.inventoryId;
        if (!inventoryId) throw ApiError.badRequest("Inventory ID is required.");

        // Validate that at least one field is being updated
        const updateFields = Object.keys(req.body);
        if (updateFields.length === 0) {
            throw ApiError.badRequest("At least one field must be provided for update.");
        }

        // Extract and validate fields if provided
        const { quantity, lowStockThreshold, restockDays }: IInventoryRequest = req.body;

        if (quantity !== undefined && (typeof quantity !== 'number' || quantity <= 0)) {
            throw ApiError.badRequest("Quantity must be a positive number if provided.");
        }

        if (lowStockThreshold !== undefined && (typeof lowStockThreshold !== 'number' || lowStockThreshold <= 0)) {
            throw ApiError.badRequest("Low stock threshold must be a positive number if provided.");
        }

        if (restockDays !== undefined && (typeof restockDays !== 'number' || restockDays <= 0)) {
            throw ApiError.badRequest("Restock days must be a positive number if provided.");
        }

        next();
    } catch (error: any) {
        sendErrorResponse(error, "Inventory Fields Validation - Update Inventory", res);
    }
});

export const validateManyInventories = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
        const inventoriesData: IInventoryRequest[] = req.body;
        if (!Array.isArray(inventoriesData) || inventoriesData.length === 0) {
            throw ApiError.badRequest("An array of inventory data is required.");
        }

        const errors: string[] = [];

        // Loop through each inventory item and validate
        inventoriesData.forEach((inventoryData, index) => {
            const { name, description, quantity, unit, lowStockThreshold, restockDays } = inventoryData;

            const missingFields: string[] = [];
            const invalidFields: string[] = [];

            // Collect missing fields
            if (!name) missingFields.push("Inventory name");
            if (!description) missingFields.push("Description");
            if (quantity === undefined) missingFields.push("Quantity");
            if (!unit) missingFields.push("Unit");
            if (lowStockThreshold === undefined) missingFields.push("Low stock threshold");
            if (restockDays === undefined) missingFields.push("Restock days");

            // Validate numeric fields and collect invalid field errors
            if (quantity !== undefined && (typeof quantity !== 'number' || quantity <= 0)) {
                invalidFields.push("Quantity");
            }
            if (lowStockThreshold !== undefined && (typeof lowStockThreshold !== 'number' || lowStockThreshold <= 0)) {
                invalidFields.push("Low stock threshold");
            }
            if (restockDays !== undefined && (typeof restockDays !== 'number' || restockDays <= 0)) {
                invalidFields.push("Restock days");
            }

            // Combine error messages for this inventory item
            if (missingFields.length > 0) {
                errors.push(`Item ${index + 1}: ${missingFields.join(", ")} ${missingFields.length === 1 ? "field is" : "fields are"} missing.`);
            }
            if (invalidFields.length > 0) {
                errors.push(`Item ${index + 1}: ${invalidFields.join(", ")} ${invalidFields.length === 1 ? "must be a positive number" : "must be positive numbers"} .`);
            }
        });

        // If there are any errors, throw a combined error response
        if (errors.length > 0) {
            throw ApiError.badRequest(errors.join(" "));
        }

        next();
    } catch (error: any) {
        sendErrorResponse(error, "Inventory Fields Validation for Multiple Items", res);
    }
});

export const validateManyManuCategories = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
        const menuCategoriesData: { name: string; description: string }[] = req.body;
        if (!Array.isArray(menuCategoriesData) || menuCategoriesData.length === 0) {
            throw ApiError.badRequest("An array of Menu categories data is required.");
        }

        const errors: string[] = [];

        // Loop through each Menu categories and validate
        menuCategoriesData.forEach((categoryData, index) => {
            const { name, description } = categoryData;

            const missingFields: string[] = [];
            const invalidFields: string[] = [];

            // Collect missing fields
            if (!name) missingFields.push("Menu Category name");
            if (!description) missingFields.push("Description");

            // Validate numeric fields and collect invalid field errors
            if (name !== undefined && (typeof name !== 'string')) {
                invalidFields.push("Menu Category name");
            }
            if (description !== undefined && (typeof description !== 'string')) {
                invalidFields.push("Description");
            }

            // Combine error messages for this inventory item
            if (missingFields.length > 0) {
                errors.push(`Manu Category ${index + 1}: ${missingFields.join(", ")} ${missingFields.length === 1 ? "field is" : "fields are"} missing.`);
            }
            if (invalidFields.length > 0) {
                errors.push(`Manu Category ${index + 1}: ${invalidFields.join(", ")} must be  ${invalidFields.length === 1 ? "a string" : "strings"} .`);
            }
        });

        // If there are any errors, throw a combined error response
        if (errors.length > 0) {
            throw ApiError.badRequest(errors.join(" "));
        }

        next();
    } catch (error: any) {
        sendErrorResponse(error, "Inventory Fields Validation for Multiple Items", res);
    }
});

// Middleware to validate the menu item data fields for adding new Menu item
export const validateNewMenuItem = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const menuItemData = req.body;

        const { name, description, price, categoryId, ingredients } = menuItemData;

        const missingFields: string[] = [];
        const invalidFields: string[] = [];

        // Collect missing fields
        if (!name) missingFields.push("Menu Item name");
        if (!description) missingFields.push("Description");
        if (price === undefined) missingFields.push("Price");
        if (!categoryId) missingFields.push("Category ID");
        if (!ingredients || ingredients.length === 0) missingFields.push("Ingredients");

        // Combine error messages
        if (missingFields.length > 0) {
            throw ApiError.badRequest(`${missingFields.join(", ")} ${missingFields.length === 1 ? "field is" : "fields are"} missing.`);
        }

        // Validate numeric fields and collect invalid field errors
        if (price !== undefined && (typeof price !== "number" || price <= 0)) {
            invalidFields.push("Price must be a positive number");
        }

        if (categoryId !== undefined && typeof categoryId !== "string") {
            invalidFields.push("Category ID must be a string");
        }

        if (ingredients && !Array.isArray(ingredients)) {
            invalidFields.push(`Ingredients must be an array.`);
        }

        if (invalidFields.length > 0) {
            throw ApiError.badRequest(`${invalidFields.join(", ")} must be  ${invalidFields.length === 1 ? "a string" : "strings"} .`);
        }

        next();
    } catch (error: any) {
        sendErrorResponse(error, "Inventory Fields Validation", res);
    }
});

//Middleware to validate the menu item data fields for adding multiple Menu items
export const validateManyMenuItems = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
        const menuItemsData: Partial<IMenuItemRequest>[] = req.body;

        if (!Array.isArray(menuItemsData) || menuItemsData.length === 0) {
            throw ApiError.badRequest("An array of menu items data is required.");
        }

        const validFields = ["name", "description", "price", "categoryId", "ingredients", "availability"];
        const errors: string[] = [];

        // Loop through each menu item and validate
        menuItemsData.forEach((itemData, index) => {
            const missingFields: string[] = [];
            const invalidFields: string[] = [];
            const unexpectedFields: string[] = [];

            // Check for unexpected fields
            Object.keys(itemData).forEach(field => {
                if (!validFields.includes(field)) {
                    unexpectedFields.push(field);
                }
            });

            // Validate missing and invalid fields
            if (!itemData.name) missingFields.push("Name");
            if (!itemData.description) missingFields.push("Description");
            if (itemData.price === undefined) missingFields.push("Price");
            if (!itemData.categoryId) missingFields.push("Category ID");
            if (!itemData.ingredients || !Array.isArray(itemData.ingredients) || itemData.ingredients.length === 0) {
                missingFields.push("Ingredients");
            }

            if (itemData.price !== undefined && (typeof itemData.price !== "number" || itemData.price <= 0)) {
                invalidFields.push("Price must be a positive number");
            }

            if (itemData.categoryId !== undefined && typeof itemData.categoryId !== "string") {
                invalidFields.push("Category ID must be a string");
            }

            if (itemData.ingredients && !Array.isArray(itemData.ingredients)) {
                invalidFields.push("Ingredients must be an array");
            }

            if (itemData.availability !== undefined && typeof itemData.availability !== "boolean") {
                invalidFields.push("Availability must be a boolean");
            }

            // Combine error messages for this menu item
            if (unexpectedFields.length > 0) {
                errors.push(
                    `Menu Item ${index + 1}: Unexpected field(s) provided: ${unexpectedFields.join(", ")}.`
                );
            }
            if (missingFields.length > 0) {
                errors.push(
                    `Menu Item ${index + 1}: Missing ${missingFields.join(", ")} ${missingFields.length === 1 ? "field" : "fields"}.`
                );
            }
            if (invalidFields.length > 0) {
                errors.push(
                    `Menu Item ${index + 1}: ${invalidFields.join(", ")}.`
                );
            }
        });

        // If there are any errors, throw a combined error response
        if (errors.length > 0) {
            throw ApiError.badRequest(errors.join(" "));
        }

        next();
    } catch (error: any) {
        sendErrorResponse(error, "Menu Items Validation", res);
    }
});

// Middleware to validate the menu item data fields for updating Menu item
export const validateUpdateMenuItem = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
        const menuItemId: string = req.params.menuItemId;
        if (!menuItemId) throw ApiError.badRequest("Menu Item ID is required.");

        // Validate that at least one field is being updated
        const updateFields = Object.keys(req.body);
        if (updateFields.length === 0) {
            throw ApiError.badRequest("At least one field must be provided for update.");
        }


        const validFields = ["name", "description", "price", "categoryId", "ingredients", "availability"];
        const invalidFields = updateFields.filter(field => !validFields.includes(field));

        if (invalidFields.length > 0) {
            throw ApiError.badRequest(`Invalid ${invalidFields.length > 1 ? "fields" : "field"} provided: ${invalidFields.join(", ")}`);
        }

        // Extract and validate fields if provided
        const { price, categoryId, ingredients, name, description, availability }: Partial<IMenuItemRequest> = req.body;

        const fieldErrors: string[] = [];

        // Validate specific fields
        if (name !== undefined && typeof name !== "string") {
            fieldErrors.push("Name must be a string");
        }

        if (description !== undefined && typeof description !== "string") {
            fieldErrors.push("Description must be a string");
        }

        if (price !== undefined && (typeof price !== "number" || price <= 0)) {
            fieldErrors.push("Price must be a positive number");
        }

        if (categoryId !== undefined && typeof categoryId !== "string") {
            fieldErrors.push("Category ID must be a string");
        }

        if (ingredients !== undefined && !Array.isArray(ingredients)) {
            fieldErrors.push("Ingredients must be an array");
        }

        if (availability !== undefined && typeof availability !== "boolean") {
            fieldErrors.push("Availability must be a boolean");
        }

        if (fieldErrors.length > 0) {
            throw ApiError.badRequest(`Validation error(s): ${fieldErrors.join(", ")}`);
        }

        next();
    } catch (error: any) {
        sendErrorResponse(error, "Update Menu Item Fields Validation", res);
    }
});


export const validateNewOrder = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
        const {
            customerName,
            branchId,
            staffId,
            tableId,
            person,
            items,
            totalAmount,
            paymentMethod,
            orderType,
            paymentStatus,
        }: IOrderRequest = req.body;

        let message: string = "";

        // Check if required fields are provided
        if (!customerName || !branchId || !tableId || !person || !items || !totalAmount || !paymentMethod || !orderType) {
            message = "Missing required fields: customer name, branchId, tableId, number of person, items, totalAmount, cashfreeOrderId, cashfreeToken, paymentMethod and orderType are required.";
            return next(ApiError.badRequest(message));
        }

        // Check if phone number is a valid string (basic validation example)
        if (typeof customerName !== 'string') {
            message = `Invalid customer name. It must be a string`;
            return next(ApiError.badRequest(message));
        }

        // Validate branchId
        if (!Types.ObjectId.isValid(branchId)) {
            message = "Invalid branchId. It must be a valid MongoDB ObjectId.";
            return next(ApiError.badRequest(message));
        }

        if (!Types.ObjectId.isValid(tableId)) {
            message = "Invalid tableId. It must be a valid MongoDB ObjectId.";
            return next(ApiError.badRequest(message));
        }

        // Validate items array
        if (!Array.isArray(items) || items.length === 0) {
            message = "Invalid items. It must be a non-empty array.";
            return next(ApiError.badRequest(message));
        }

        for (const item of items) {
            if (!item.menuItemId || !Types.ObjectId.isValid(item.menuItemId)) {
                message = "Invalid menuItemId. Each item must have a valid MongoDB ObjectId.";
                return next(ApiError.badRequest(message));
            }

            if (typeof item.price !== "number" || item.price <= 0) {
                message = "Invalid price. It must be a positive number.";
                return next(ApiError.badRequest(message));
            }

            if (typeof item.quantity !== "number" || item.quantity <= 0) {
                message = "Invalid quantity. It must be a positive number.";
                return next(ApiError.badRequest(message));
            }

            if (item.instructions && typeof item.instructions !== "string") {
                message = "Invalid instructions. It must be a string.";
                return next(ApiError.badRequest(message));
            }
        }

        // Validate totalAmount
        if (typeof totalAmount !== "number" || totalAmount <= 0) {
            message = "Invalid totalAmount. It must be a positive number.";
            return next(ApiError.badRequest(message));
        }

        if (typeof person !== "number" || person <= 0) {
            message = "Invalid person. It must be a positive number.";
            return next(ApiError.badRequest(message));
        }

        // Validate paymentMethod
        const validPaymentMethods = orderConstant.paymentMethod;
        if (!validPaymentMethods.includes(paymentMethod)) {
            message = `Invalid paymentMethod. It must be one of ${validPaymentMethods.join(", ")}.`;
            return next(ApiError.badRequest(message));
        }

        // Validate orderType
        const validOrderTypes = orderConstant.orderType;
        if (!validOrderTypes.includes(orderType)) {
            message = `Invalid orderType. It must be one of ${validOrderTypes.join(", ")}.`;
            return next(ApiError.badRequest(message));
        }

        // Validate paymentStatus
        const validPaymentStatuses = orderConstant.paymentStatus;
        if (paymentStatus && !validPaymentStatuses.includes(paymentStatus)) {
            message = `Invalid paymentStatus. It must be one of ${validPaymentStatuses.join(", ")}.`;
            return next(ApiError.badRequest(message));
        }

        // Validate staffId (if provided)
        if (staffId && !Types.ObjectId.isValid(staffId)) {
            message = "Invalid staffId. It must be a valid MongoDB ObjectId.";
            return next(ApiError.badRequest(message));
        }

        next();

    } catch (error: any) {
        sendErrorResponse(error, "Order Fields Validation", res);
    }
});

