// import { Router } from "express";
// import { verifyToken } from "../middlewares/Auth.middleware";
// import { accessCheck } from "../middlewares/AccessCheck.Middleware"; // Use accessCheck
// import {
//     getRestaurantById,
//     getTransactionById,
//     getBranchesByRestaurantId,
//     getBranchById,
//     createBranch,
//     updateBranch,
//     getBranchTables,
//     getBranchInventory,
//     getBranchOrders,
//     getBranchBills,
//     getBranchSubscription,
//     getBranchMenu
// } from "../controllers/Restaurant.Controller";

// const router = Router();

// // Agent can access the restaurant they registered
// router.route("/restaurant/:restaurantId").get(
//     verifyToken,
//     accessCheck("Restaurant", "view"),
//     getRestaurantById
// );

// // Agent can view transaction details
// router.route("/transaction/:transactionId").get(
//     verifyToken,
//     accessCheck("AgentTransaction", "view"),
//     getTransactionById
// );

// // Agent can access branches of a restaurant
// router.route("/restaurant/:restaurantId/branches").get(
//     verifyToken,
//     accessCheck("Restaurant", "viewBranches"),
//     getBranchesByRestaurantId
// );

// // Agent can access a specific branch by branch ID
// router.route("/restaurant/:restaurantId/branch/:branchId").get(
//     verifyToken,
//     accessCheck("Branch", "view"),
//     getBranchById
// );

// // Agent can create a new branch for a restaurant
// router.route("/restaurant/:restaurantId/branch").post(
//     verifyToken,
//     accessCheck("Branch", "create"),
//     createBranch
// );

// // Agent can update details of a branch
// router.route("/restaurant/:restaurantId/branch/:branchId").patch(
//     verifyToken,
//     accessCheck("Branch", "update"),
//     updateBranch
// );

// // Agent can access tables in a specific branch
// router.route("/restaurant/:restaurantId/branch/:branchId/tables").get(
//     verifyToken,
//     accessCheck("Branch", "viewTables"),
//     getBranchTables
// );

// // Agent can access inventory in a specific branch
// router.route("/restaurant/:restaurantId/branch/:branchId/inventory").get(
//     verifyToken,
//     accessCheck("Branch", "viewInventory"),
//     getBranchInventory
// );

// // Agent can view orders in a specific branch
// router.route("/restaurant/:restaurantId/branch/:branchId/orders").get(
//     verifyToken,
//     accessCheck("Branch", "viewOrders"),
//     getBranchOrders
// );

// // Agent can view bills in a specific branch
// router.route("/restaurant/:restaurantId/branch/:branchId/bills").get(
//     verifyToken,
//     accessCheck("Branch", "viewBills"),
//     getBranchBills
// );

// // Agent can view subscription for a restaurant
// router.route("/restaurant/:restaurantId/subscription").get(
//     verifyToken,
//     accessCheck("Restaurant", "viewSubscription"),
//     getBranchSubscription
// );

// // Agent can view menu for a restaurant
// router.route("/restaurant/:restaurantId/menu").get(
//     verifyToken,
//     accessCheck("Restaurant", "viewMenu"),
//     getBranchMenu
// );

// export default router;
