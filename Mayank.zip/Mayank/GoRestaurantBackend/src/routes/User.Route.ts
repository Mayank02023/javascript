import { Router } from 'express';
import {
    changeCurrentUserPassword,
    getCurrentUser,
    getUserProfile,
    loginUser,
    LogoutUser,
    refreshAccessToken,
    updateUserAvatar,
    updateUserDetails,
} from '../controllers/User.Controller';
import { uploadFile } from '../middlewares/Multer.Middleware';
import { validateFieldForUpdateUser } from '../middlewares/Validation.Middleware';
import { verifyToken } from '../middlewares/Auth.middleware';
import { roleCheck, userAccessCheck } from '../middlewares/AccessCheck.Middleware';

const router = Router();


/**
 * @route POST /api/user/login
 * @desc Login a user and return JWT
 * @access Public
 */
router.post("/login", loginUser);

/**
 * @route POST /api/user/logout
 * @desc Logout a user and invalidate JWT
 * @access Private (Any authenticated user)
 */
router.route("/logout").post(
    verifyToken,
    roleCheck(['owner', 'manager', 'staff']),
    LogoutUser);

/**
 * @route POST /api/user/refresh-token
 * @desc Refresh the access token
 * @access Public
 */
router.post("/refresh-token", refreshAccessToken);

/**
 * @route POST /api/user/change-password
 * @desc Change the current user's password
 * @access Private (Any authenticated user)
 */
router.post("/change-password",
    verifyToken,
    roleCheck(['owner', 'manager', 'staff']), // Any role can change their password
    changeCurrentUserPassword
);

/**
 * @route GET /api/user/me
 * @desc Get the current user's details
 * @access Private (Any authenticated user)
 */
router.get("/me",
    verifyToken,
    getCurrentUser
);

/**
 * @route PATCH /api/user/:userId/update-details
 * @desc Update user details
 * @access Private (Any authenticated user)
 */
router.patch("/:userId/update-details",
    verifyToken,
    userAccessCheck(['superAdmin', 'agent', 'owner', 'manager', 'staff']), // Only owners and managers can update user details
    validateFieldForUpdateUser,
    updateUserDetails
);

/**
 * @route PATCH /api/user/:userId/update-avatar
 * @desc Update the user's avatar
 * @access Private (Any authenticated user)
 */
router.patch("/:userId/update-avatar",
    verifyToken,
    userAccessCheck(['superAdmin', 'agent', 'owner', 'manager', 'staff']), // Any role can update their avatar
    uploadFile.single('avatar'),
    updateUserAvatar
);

/**
 * @route GET /api/user/:userId
 * @desc Get a user's profile
 * @access Private (Any authenticated user)
 */
router.get("/:userId",
    verifyToken,
    userAccessCheck(['superAdmin', 'agent', 'owner', 'manager', 'staff']), // Restrict access based on roles
    getUserProfile
);



export default router;
