import { Router } from 'express';
import { verifyToken } from '../middlewares/Auth.middleware';
import { menuCategoryAccessCheck } from '../middlewares/AccessCheck.Middleware';
import { getMenuCategoryById, updateMenuCategoryById, deleteMenuCategoryById } from '../controllers/MenuCategory.Controller';

const router = Router();

router.route("/:menuCategoryId").get(
    verifyToken,
    menuCategoryAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    getMenuCategoryById
);

router.route("/:menuCategoryId").patch(
    verifyToken,
    menuCategoryAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    updateMenuCategoryById
);

router.route("/:menuCategoryId").delete(
    verifyToken,
    menuCategoryAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    deleteMenuCategoryById
);

export default router;