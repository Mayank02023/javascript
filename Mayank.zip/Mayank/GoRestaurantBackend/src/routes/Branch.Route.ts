import { Router } from 'express';
import { verifyToken } from '../middlewares/Auth.middleware';
import { branchAccessCheck } from '../middlewares/AccessCheck.Middleware';
import { deleteBranchById, getBranchById, updateBranchById } from '../controllers/Branch.Controller';
import { uploadFile } from '../middlewares/Multer.Middleware';
import { validateManyInventories, validateManyManuCategories, validateManyMenuItems, validateNewInventory, validateNewMenuItem, validateNewOrder, validateNewUser } from '../middlewares/Validation.Middleware';
import { registerUser } from '../controllers/User.Controller';
import { addTable, getTables } from '../controllers/Table.Controller';
import { addInventory, addManyInventories, findLowStockItems, getInventories } from '../controllers/Inventory.Controller';
import { addManyMenuCategories, addMenuCategory, getMenuCategories } from '../controllers/MenuCategory.Controller';
import { addManyMenuItems, addMenuItem, getMenuItems, getUnavailableMenuItems } from '../controllers/Menu.Controller';
import { createOrder, getOrders, todaysOrders } from '../controllers/Order.Controller';

const router = Router();

router.route("/:branchId").get(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    getBranchById
);

router.route("/:branchId").patch(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager"]),
    updateBranchById
);

router.route("/:branchId").delete(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner"]),
    deleteBranchById
);

router.route('/:branchId/user').post(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager"]), // Restrict access to owners or managers
    uploadFile.single('avatar'),
    validateNewUser,
    registerUser
);


router.route('/:branchId/table').post(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager"]),
    addTable
);

router.route('/:branchId/tables').get(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    getTables
);

router.route('/:branchId/inventory').post(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    validateNewInventory,
    addInventory
);

router.route('/:branchId/bulk-inventories').post(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    validateManyInventories,
    addManyInventories
);

router.route('/:branchId/inventories').get(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    getInventories
);

router.route('/:branchId/low-stock-inventories').get(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    findLowStockItems
);


router.route('/:branchId/menu-item-category').post(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    addMenuCategory
);

router.route('/:branchId/bulk-menu-item-categories').post(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    validateManyManuCategories,
    addManyMenuCategories
);

router.route('/:branchId/menu-item-categories').get(
    getMenuCategories
)

router.route('/:branchId/menu-item').post(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    uploadFile.single('avatar'),
    validateNewMenuItem,
    addMenuItem
);

router.route('/:branchId/bulk-menu-items').post(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    validateManyMenuItems,
    addManyMenuItems
);

router.route('/:branchId/menu-items').get(
    getMenuItems
);

router.route('/:branchId/unavailable-menu-items').get(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    getUnavailableMenuItems
);


router.route('/:branchId/order').post(
    validateNewOrder,
    createOrder
)

router.route('/:branchId/orders').get(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    getOrders
)

router.route('/:branchId/todays-orders').get(
    verifyToken,
    branchAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    todaysOrders
)
export default router;
