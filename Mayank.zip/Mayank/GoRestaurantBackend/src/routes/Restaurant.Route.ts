import { Router, Request, Response } from "express";
import { verifyToken } from "../middlewares/Auth.middleware";
import {
    assignAgentToRestaurant,
    associateBranchWithRestaurant,
    createRestaurant,
    deleteRestaurant,
    getRestaurantById,
    getRestaurants,
    updatedRestaurant
} from "../controllers/Restaurant.Controller";
import { restaurantAccessCheck, roleCheck } from "../middlewares/AccessCheck.Middleware";
import { uploadFile } from "../middlewares/Multer.Middleware";
import { addBranch, addManyBranches, getBranchsByRestaurantId } from "../controllers/Branch.Controller";
import { registerUser } from "../controllers/User.Controller";
import { validateNewUser } from "../middlewares/Validation.Middleware";

const router = Router();


router.route("/create").post(
    verifyToken,
    roleCheck(['superAdmin', 'agent']), // Allow access to super admin or agent
    uploadFile.single('avatar'),
    createRestaurant
);

router.route("/list").get(
    verifyToken,
    roleCheck(['superAdmin', 'agent']), // Allow access to super admin or agent
    getRestaurants
);
router.route("/:restaurantId").get(
    verifyToken,
    restaurantAccessCheck(['superAdmin', 'agent', 'manager', 'owner', 'staff']), // Allow access to all users
    getRestaurantById
);

router.route("/:restaurantId").patch(
    verifyToken,
    restaurantAccessCheck(['superAdmin', 'agent', 'owner']), // Allow access to super admin,  agent or owner
    updatedRestaurant
);

router.route("/:restaurantId/assign-agent").patch(
    verifyToken,
    roleCheck(['superAdmin']),
    assignAgentToRestaurant
);

router.route("/:restaurantId").delete(
    verifyToken,
    restaurantAccessCheck(['superAdmin', 'agent']),
    deleteRestaurant
);


router.route("/:restaurantId/owner").post(
    verifyToken,
    restaurantAccessCheck(['superAdmin', 'agent']),
    uploadFile.single('avatar'),
    validateNewUser,
    registerUser
);


router.route("/:restaurantId/branch").post(
    verifyToken,
    restaurantAccessCheck(["superAdmin", "agent", "owner"]),
    addBranch
);

router.route("/:restaurantId/manybranches").post(
    verifyToken,
    restaurantAccessCheck(["superAdmin", "agent", "owner"]),
    addManyBranches
);

router.route("/:restaurantId/branches").get(
    verifyToken,
    restaurantAccessCheck(["superAdmin", "agent", "owner"]),
    getBranchsByRestaurantId
);

router.route("/:restaurantId/branch").put(
    verifyToken,
    restaurantAccessCheck(["superAdmin", "agent", "owner"]),
    associateBranchWithRestaurant

)

export default router;

