import { Router } from 'express';
import { chat } from '../controllers/AIChat';

const router = Router();


router.route('/').get(
    chat
);

export default router;
