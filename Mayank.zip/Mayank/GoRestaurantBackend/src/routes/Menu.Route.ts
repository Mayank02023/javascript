import { Router } from 'express';
import { verifyToken } from '../middlewares/Auth.middleware';
import { deleteManyMenuItemsbyIds, deleteMenuItemById, deleteMenuItemPermanentById, getMenuItemById, reactivatedMenuItemById, updateMenuItemById } from '../controllers/Menu.Controller';
import { menuAccessCheck } from '../middlewares/AccessCheck.Middleware';
import { validateUpdateMenuItem } from '../middlewares/Validation.Middleware';

const router = Router();

router.route("/permanent-delete-multiple").patch(
    verifyToken,
    deleteManyMenuItemsbyIds
);

router.route("/:menuItemId").get(
    verifyToken,
    menuAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    getMenuItemById
);

router.route("/:menuItemId").patch(
    verifyToken,
    menuAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    validateUpdateMenuItem,
    updateMenuItemById
);

router.route("/:menuItemId").delete(
    verifyToken,
    menuAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    deleteMenuItemById
);

router.route("/:menuItemId/activate-item").patch(
    verifyToken,
    menuAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    reactivatedMenuItemById
);

router.route("/:menuItemId/permanent-delete").delete(
    verifyToken,
    menuAccessCheck(["superAdmin", "agent", "owner", "manager"]),
    deleteMenuItemPermanentById
);




export default router;