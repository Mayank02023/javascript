import { Request, Response, Router } from 'express';
import { options } from '../constants';
import { ApiError, ApiResponse, sendErrorResponse } from '../utils';
import SuperAdminModel, { ISuperAdmin } from '../models/SuperAdmin.model';

const router = Router();

router.route("/register").post(async (req: Request, res: Response) => {
    try {
        // Prepare the data to be saved
        const prepareData = new SuperAdminModel({
            name: "Super Admin",
            username: "superAdminPK",
            password: "Prince9Kurmi",
            email: "superadminpk@gmail.com",
            phoneNumber: "+918755507589"
        });

        // Save the SuperAdmin document to the database
        const superAdmin = await prepareData.save();

        // Check if the save operation was successful
        if (!superAdmin) {
            return res.status(404).json({
                message: "Data not added"
            });
        }

        // Return a success response if the admin was created successfully
        return res.status(201).json({
            message: "Super Admin created successfully",
            data: superAdmin
        });
    } catch (error: any) {
        // Catch any errors and send a 500 server error response
        return res.status(500).json({
            message: "Error processing the request",
            error: error.message
        });
    }
}
);

router.route('/').post(async (req: Request, res: Response) => {
    const { username, phoneNumber, password } = req.body;

    try {
        // Validate input: Ensure either username or phone number is provided
        if (!username && !phoneNumber) {
            throw ApiError.badRequest("Username or phone number is required");
        }
        if (!password) {
            throw ApiError.badRequest("Password is required");
        }

        const field = {
            $or: [{ username }, { phoneNumber }]
        };

        const superAdmin: ISuperAdmin | null = await SuperAdminModel.findOne(field).exec();

        if (!superAdmin) {
            throw ApiError.badRequest("Super Admin does not exist!");
        }

        // Check if the provided password is correct
        const isPasswordValid = await superAdmin.isPasswordCorrect(password);
        if (!isPasswordValid) {
            throw ApiError.unauthorized("Invalid super admin credentials");
        }

        // Generate access and refresh tokens
        const accessToken: string = superAdmin.generateAccessToken();
        const refreshToken: string = superAdmin.generateRefreshToken();

        if (!accessToken || !refreshToken) {
            throw ApiError.internal("Access and refresh token did not generate!");
        }

        // Update refreshToken in the database (make sure it's encrypted or hashed)
        const superAdminData = await SuperAdminModel.findByIdAndUpdate(superAdmin._id, { refreshToken }, { new: true, validateBeforeSave: false })
            .select("-password -refreshToken")
            .exec();

        if (!superAdminData) {
            throw ApiError.internal("Super Admin login process failed!");
        }

        return res
            .status(200)
            .cookie("accessToken", accessToken, options)
            .cookie("refreshToken", refreshToken, options)
            .json(ApiResponse.success(
                { superAdminData, accessToken, refreshToken },
                "Super Admin logged in successfully."
            ));
    } catch (error: any) {
        sendErrorResponse(error, "Super Admin Login", res);
    }
});






export default router;