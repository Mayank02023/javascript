import { Router } from 'express';
import {
    changeAgentPassword,
    getCurrentAgent,
    getAgentProfile,
    loginAgent,
    logoutAgent,
    refreshAgentAccessToken,
    registerAgent,
    updateAgentAvatar,
    updateAgentDetails,
} from '../controllers/Agent.Controller';
import { uploadFile } from '../middlewares/Multer.Middleware';
import { validateFieldForUpdateAgent, validateNewAgent } from '../middlewares/Validation.Middleware';
import { verifyToken } from '../middlewares/Auth.middleware';
import { agentAccessCheck, roleCheck } from '../middlewares/AccessCheck.Middleware';

const router = Router();

/**
 * @route POST /api/agent/register
 * @description Register a new agent (restricted to super admins)
 * @access Private
 */
router.route('/register').post(
    verifyToken,
    roleCheck(['superAdmin']),
    uploadFile.single('avatar'),
    validateNewAgent,
    registerAgent
);

/**
 * @route POST /api/agent/login
 * @description Authenticate an agent and return a JWT token
 * @access Public
 */
router.route('/login').post(loginAgent);

/**
 * @route POST /api/agent/logout
 * @description Logout the agent and invalidate their session
 * @access Private
 */
router.route('/logout').post(verifyToken, logoutAgent);

/**
 * @route POST /api/agent/refresh-token
 * @description Refresh the agent's JWT access token
 * @access Public
 */
router.route('/refresh-token').post(refreshAgentAccessToken);

/**
 * @route PUT /api/agent/change-password
 * @description Allow authenticated agents to change their password
 * @access Private
 */
router.route('/change-password').put(
    verifyToken,
    roleCheck(['agent']),
    changeAgentPassword
);

/**
 * @route GET /api/agent/me
 * @description Retrieve details of the currently authenticated agent
 * @access Private
 */
router.route('/me').get(
    verifyToken, 
    getCurrentAgent);

/**
 * @route PATCH /api/agent/:agentId/update-details
 * @description Update the agent's details (restricted to super admins and agents)
 * @access Private
 */
router.route('/:agentId/update-details').patch(
    verifyToken,
    agentAccessCheck(['superAdmin', 'agent']),
    validateFieldForUpdateAgent,
    updateAgentDetails
);

/**
 * @route PATCH /api/agent/:agentId/update-avatar
 * @description Update the avatar for the authenticated agent
 * @access Private
 */
router.route('/:agentId/update-avatar').patch(
    verifyToken,
    agentAccessCheck(['superAdmin', 'agent']),
    uploadFile.single('avatar'),
    updateAgentAvatar
);

/**
 * @route GET /api/agent/:agentId
 * @description Fetch the profile of a specific agent
 * @access Private
 */
router.route('/:agentId').get(
    verifyToken,
    agentAccessCheck(['superAdmin', 'agent']),
    getAgentProfile
);

export default router;
