import { Router } from 'express';
import { verifyToken } from '../middlewares/Auth.middleware';
import { deleteTableById, getTableById, updateTableById } from '../controllers/Table.Controller';
import { tableAccessCheck } from '../middlewares/AccessCheck.Middleware';

const router = Router();

router.route("/:tableId").get(
    getTableById
);

router.route("/:tableId").patch(
    verifyToken,
    tableAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    updateTableById
);

router.route("/:tableId").delete(
    verifyToken,
    tableAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    deleteTableById
);

export default router;
