import { Router } from 'express';
import { verifyToken } from '../middlewares/Auth.middleware';
import { getInventoryById, updateInventoryById, deleteInventoryById, deletePermanentInventoryById, deleteManyInventoriesbyIds } from '../controllers/Inventory.Controller';
import { inventoryAccessCheck } from '../middlewares/AccessCheck.Middleware';

const router = Router();

router.route("/delete-multiple").patch(
    verifyToken,
    deleteManyInventoriesbyIds
);

router.route("/:inventoryId").get(
    verifyToken,
    inventoryAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    getInventoryById
);

router.route("/:inventoryId").patch(
    verifyToken,
    inventoryAccessCheck(["superAdmin", "agent", "owner", "manager", "staff"]),
    updateInventoryById
);

router.route("/:inventoryId").delete(
    verifyToken,
    inventoryAccessCheck(["superAdmin", "agent", "owner", "manager"]),
    deleteInventoryById
);

router.route("/:inventoryId/permanent-delete").delete(
    verifyToken,
    inventoryAccessCheck(["superAdmin", "agent", "owner", "manager"]),
    deletePermanentInventoryById
);

export default router;
