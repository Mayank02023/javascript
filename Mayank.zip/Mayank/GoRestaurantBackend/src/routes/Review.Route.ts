import { Router } from "express";
import { addRestaurantReview, getRestaurantReviews } from "../controllers/Review.Controller";

const router = Router();

/**
 * @route POST /restaurant/:restaurantId/review
 * @access Public
 */

router.route("/:restaurantId/review").post(
    addRestaurantReview
);

/**
 * @route GET /restaurant/:restaurantId/reviews/:page
 * @access Public
 */

router.route("/:restaurantId/reviews/:page").get(
    getRestaurantReviews
);

export default router;