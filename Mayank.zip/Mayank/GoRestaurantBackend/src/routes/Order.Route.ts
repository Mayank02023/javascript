import { Router } from 'express';
import { getOrderById, getOrders, updateOrderById } from '../controllers/Order.Controller';

const router = Router();

router.route('/my-orders').get(
    getOrders
)

router.route('/:orderId').get(
    getOrderById
);

router.route('/:orderId').put(
    updateOrderById
);


export default router;
