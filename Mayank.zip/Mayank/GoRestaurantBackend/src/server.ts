import dotenv from "dotenv";
import connectDB from './config/connectDB';
import envConfig from './config/envConfig';
import app from "./app";

dotenv.config({
    path: './.env'
})

connectDB()
    .then(() => {
        const port = envConfig.PORT || 8000;

        app.on("error", (err) => {
            console.log("Error", err);
            throw err;
        });

        app.listen(port, () => {
            console.log(`Server running at http://localhost:${port}`);
        });
    })
    .catch((err) => {
        console.log("MONGODB connection failed !! ", err);
    });