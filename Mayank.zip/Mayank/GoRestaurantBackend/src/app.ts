import express, { Application, Request, Response } from "express";
import cookieParser from "cookie-parser";
import cors from "cors";
import dotenv from 'dotenv';

const app: Application = express();

dotenv.config();
// Define allowed origins (could be an environment variable or hardcoded)
const allowedOrigins = [
    process.env.LOCAL_CORS_ORIGIN,
    'http://localhost:5174',
    'http://localhost:5175'
];

// Configure CORS to check if the request's origin is in the allowed origins
app.use(
    cors({
        origin: function (origin, callback) {
            if (!origin || allowedOrigins.indexOf(origin) !== -1) {
                callback(null, true); // Allow the request
            } else {
                callback(new Error("Not allowed by CORS")); // Block the request
            }
        },
        credentials: true, // Allow credentials such as cookies
    })
);


app.use(express.json({ limit: "20kb" }));

app.use(express.urlencoded({ extended: true, limit: "20kb" }));

app.use(express.static("public"));

app.use(cookieParser());

//routes import
import superAdminRoute from "./routes/SuperAdmin.Route";
import agentRoute from "./routes/Agent.Route";
import userRoute from "./routes/User.Route";
import restaurantRoute from "./routes/Restaurant.Route";
import reviewRoute from "./routes/Review.Route";
import branchRoute from "./routes/Branch.Route";
import tableRoute from "./routes/Table.Route";
import inventoryRoute from "./routes/Inventory.Route";
import menuCategoryRoute from "./routes/MenuCategory.Route";
import menuItemRoute from "./routes/Menu.Route";
import orderRoute from "./routes/Order.Route";
import paymentRoute from "./routes/Payment.Route";
import chatRoute from "./routes/Chat";

app.use("/api/v1/super-admin", superAdminRoute);
app.use('/api/v1/user', userRoute);
app.use('/api/v1/agent', agentRoute);
app.use('/api/v1/restaurant', restaurantRoute);
app.use('/api/v1/review', reviewRoute);
app.use('/api/v1/branch', branchRoute);
app.use('/api/v1/table', tableRoute);
app.use('/api/v1/inventory', inventoryRoute);
app.use('/api/v1/menu-item-category', menuCategoryRoute);
app.use('/api/v1/menu-item', menuItemRoute);
app.use('/api/v1/order', orderRoute);
app.use('/api/v1/payment', paymentRoute);
app.use('/api/v1/chat', chatRoute)

export default app;
