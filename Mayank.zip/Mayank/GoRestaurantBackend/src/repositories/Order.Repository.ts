// repositories/Order.Repository.ts

import mongoose from "mongoose";
import OrderModel, { IOrder } from "../models/Order.model";
import { IPagination } from "../types/Comman.Interface";
import BaseRepository from "./Base.Repository";
import { ApiError } from "../utils";

class OrderRepository extends BaseRepository<IOrder> {
  constructor() {
    super(OrderModel);
  }

  // Create a new order
  async createOrder(order: Partial<IOrder>): Promise<IOrder | null> {
    return this.create(order);
  }

  // Get order by ID
  async getOrderById(orderId: string): Promise<IOrder> {
    const order = await this.model.aggregate([
      { $match: { _id: new mongoose.Types.ObjectId(orderId), isDelete: false } },

      {
        $unwind: {
          path: "$items", // Unwind items array
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $lookup: {
          from: "menuitems",
          localField: "items.menuItemId",
          foreignField: "_id",
          as: "menuItem"
        }
      },
      {
        $unwind: {
          path: "$menuItem",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $lookup: {
          from: "users",
          localField: "staffId",
          foreignField: "_id",
          as: "staff"
        }
      },
      {
        $unwind: {
          path: "$staff",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $group: {
          _id: "$_id",
          customerName: { $first: "$customerName" },
          status: { $first: "$status" },
          items: {
            $push: {
              _id: "$menuItem._id",
              name: "$menuItem.name",
              quantity: "$items.quantity",
              price: "$items.price",
              avatar: "$menuItem.avatar"
            }
          },
          totalAmount: { $first: "$totalAmount" },
          orderType: { $first: "$orderType" },
          staff: { $first: { _id: "$staff._id", name: "$staff.name" } },
          paymentMethod: { $first: "$paymentMethod" },
          paymentStatus: { $first: "$paymentStatus" },
          paymentDetails: { $first: "$paymentDetails" },
          createdAt: { $first: "$createdAt" },
          updatedAt: { $first: "$updatedAt" },
        }
      },
    ]);
    if (!order || order.length == 0) {
      throw ApiError.badRequest("Order not found!")
    }
    return order[0] as IOrder;
  }

  // Get all orders with pagination and optional query filtering
  async getAllOrders(query: any, pagination: IPagination): Promise<{ orders: IOrder[]; total: number }> {
    const { pageSize, skip } = pagination;

    const result = await this.model.aggregate([
      { $match: query }, // Apply filters

      {
        $unwind: {
          path: "$items", // Unwind items array
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $lookup: {
          from: "menuitems",
          localField: "items.menuItemId",
          foreignField: "_id",
          as: "menuItem"
        }
      },
      {
        $unwind: {
          path: "$menuItem", // Unwind menuItem to extract details
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $lookup: {
          from: "users",
          localField: "staffId",
          foreignField: "_id",
          as: "staff"
        }
      },
      {
        $unwind: {
          path: "$staff", // Unwind staff to extract details
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $group: {
          _id: "$_id",
          customerName: { $first: "$customerName" },
          status: { $first: "$status" },
          totalAmount: { $first: "$totalAmount" },
          orderType: { $first: "$orderType" },
          staff: { $first: { _id: "$staff._id", name: "$staff.name" } },
          paymentMethod: { $first: "$paymentMethod" },
          paymentStatus: { $first: "$paymentStatus" },
          paymentDetails: { $first: "$paymentDetails" },
          createdAt: { $first: "$createdAt" },
          updatedAt: { $first: "$updatedAt" },
          items: {
            $push: {
              _id: "$menuItem._id",
              name: "$menuItem.name",
              quantity: "$items.quantity",
              price: "$items.price",
              avatar: "$menuItem.avatar"
            }
          }
        }
      },

      // Sort results before pagination
      { $sort: { createdAt: -1 } },

      // Faceted pagination
      {
        $facet: {
          metadata: [{ $count: "total" }], // Count total documents
          data: [{ $skip: skip }, { $limit: pageSize }] // Apply pagination
        }
      }
    ]);

    const orders = result[0]?.data || [];
    const total = result[0]?.metadata[0]?.total || 0;

    return { orders, total };
  }



  // Update an order by ID
  async updateOrder(orderId: string, order: Partial<IOrder>): Promise<IOrder | null> {
    return this.updateById(orderId, order);
  }

  // Delete an order by ID
  async deleteOrder(orderId: string): Promise<boolean> {
    return !!(await this.deleteById(orderId));
  }
}

const orderRepository = new OrderRepository();
export default orderRepository;
