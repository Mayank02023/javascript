import { Model, isValidObjectId } from "mongoose";

/**
 * BaseRepository is a generic class that provides reusable methods for interacting with MongoDB models.
 * It supports basic CRUD operations and additional methods like pagination and query filtering.
 * @template T - The type of the model data being handled.
 */
class BaseRepository<T> {
    public model: Model<T>;

    /**
     * Initializes the BaseRepository with a specific Mongoose model.
     * @param model - The Mongoose model to be used for database operations.
     */
    constructor(model: Model<T>) {
        this.model = model;
    }

    /**
     * Creates a new document in the database.
     * @param data - The data to create a new document.
     * @returns The created document.
     */
    protected async create(data: Partial<T>): Promise<T> {
        const prepareData = new this.model(data);
        return await prepareData.save() as T;
    }

    /**
     * Finds a document by its unique ID.
     * @param id - The ID of the document to find.
     * @returns The found document or null if not found.
     * @throws An error if the ID format is invalid.
     */
    protected async findById(id: string): Promise<T | null> {
        return await this.model.findById(id) as T | null;
    }

    /**
     * Finds a single document based on specific field values.
     * @param fields - The field-value pairs to search for.
     * @returns The found document or null if not found.
     */
    protected async findByFields(fields: Partial<T>): Promise<T | null> {
        return await this.model.findOne(fields) as T | null;
    }

    /**
     * Updates a document by its ID.
     * @param id - The ID of the document to update.
     * @param data - The data to update in the document.
     * @returns The updated document or null if not found.
     * @throws An error if the ID format is invalid.
     */
    protected async updateById(id: string, data: Partial<T>): Promise<T | null> {
        return await this.model.findByIdAndUpdate(id, data, { new: true, validateBeforeSave: false }) as T | null;
    }

    /**
     * Deletes a document by its ID.
     * @param id - The ID of the document to delete.
     * @returns The deleted document or null if not found.
     * @throws An error if the ID format is invalid.
     */
    protected async deleteById(id: string): Promise<T | null> {
        return await this.model.findByIdAndDelete(id) as T | null;
    }

    /**
     * Retrieves all documents from the database with optional query options.
     * @param options - Query options like limit, sort, and projection.
     * @returns An array of all documents.
     */
    protected async findAll(options?: { limit?: number; sort?: any; projection?: any }): Promise<T[]> {
        return await this.model.find({}, options?.projection).sort(options?.sort).limit(options?.limit || 0) as T[];
    }

    /**
     * Finds multiple documents based on fields values with optional query options.
     * @param fields - The field-value pairs to search for.
     * @param options - Query options like limit, sort, and projection.
     * @returns An array of found documents.
     */
    protected async findMoreByFields(fields: Partial<T>, options?: { limit?: number; sort?: any; projection?: any }): Promise<T[]> {
        return await this.model.find(fields, options?.projection).sort(options?.sort).limit(options?.limit || 0) as T[];
    }

    /**
     * Finds documents with pagination support.
     * @param fields - The field-value pairs to search for.
     * @param options - Pagination options including page number, page size, sort, and projection.
     * @returns An object containing the paginated data and total document count.
     */
    protected async findWithPagination(
        fields: Partial<T> = {},
        options: { page: number; pageSize: number; sort?: any; projection?: any }
    ): Promise<{ data: T[]; total: number }> {
        const { page = 1, pageSize = 20, sort = {}, projection = {} } = options;

        const total = await this.model.countDocuments(fields);
        const data = await this.model
            .find(fields, projection)
            .sort(sort)
            .skip((page - 1) * pageSize)
            .limit(pageSize);

        return { data, total };
    }

    /**
    * Finds documents with pagination support.
    * @param options - Pagination options including page number, page size, sort, and projection.
    * @returns An object containing the paginated data and total document count.
    */
    protected async findAllWithPagination(
        options: { page: number; pageSize: number; sort?: any; projection?: any }
    ): Promise<{ data: T[]; total: number }> {
        const { page = 1, pageSize = 10, sort = {}, projection = {} } = options;

        // Validate page and pageSize
        if (page < 1 || pageSize < 1) {
            throw new Error('Page and pageSize must be positive integers');
        }

        // Calculate total documents count
        const total = await this.model.countDocuments();

        // Fetch paginated data
        const data = await this.model
            .find({}, projection) // Empty filter `{}` to find all documents
            .sort(sort)
            .skip((page - 1) * pageSize)
            .limit(pageSize);

        return { data, total };
    }
}

export default BaseRepository;
