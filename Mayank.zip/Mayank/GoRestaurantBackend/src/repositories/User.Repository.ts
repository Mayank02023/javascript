import UserModel, { IUser } from "../models/User.model";
import BaseRepository from "./Base.Repository";


class UserRepository extends BaseRepository<IUser> {
    private sensitiveFields: string[] = ["-password", "-refreshToken"];
    constructor() {
        // Pass the UserModel to the BaseRepository constructor
        super(UserModel)
    }
    private getSensitiveFieldExclusion(): string {
        return this.sensitiveFields.join(" ");
    }

    //Register new user
    async createUser(userData: Partial<IUser>): Promise<IUser | null> {
        const useResponse = await this.create(userData);
        return useResponse;
    }

    // Find user by id
    async findUserById(userId: string): Promise<IUser | null> {
        return this.model.findById(userId)
            .exec();
    }

    // Find user by fields, excluding sensitive fields
    async findUserByFields(fields: Record<string, any>): Promise<IUser | null> {
        return this.model
            .findOne(fields)
            .exec();
    }
    // Update the user data
    async updateUserById(userId: string, data: Partial<IUser>): Promise<IUser | null> {
        return await this.model.findByIdAndUpdate(userId, data, { new: true, validateBeforeSave: false })
            .select(this.getSensitiveFieldExclusion())
            .exec();
    }

    // Find multiple document by fields
    async findUsersByFields(fields: Record<string, any>, options?: { limit?: number; sort?: any; projection?: any }): Promise<IUser[] | null> {
        return await this.model.find(fields, options?.projection).sort(options?.sort).limit(options?.limit || 0)
            .select(this.getSensitiveFieldExclusion()) as IUser[];
    }

    // Custom method to get user without sensitive fields
    async getUserWithoutSensitiveFields(userId: string): Promise<IUser | null> {
        return this.model.findById(userId)
            .select(this.getSensitiveFieldExclusion())
            .exec();
    }

}
const userRepository = new UserRepository();
export default userRepository;