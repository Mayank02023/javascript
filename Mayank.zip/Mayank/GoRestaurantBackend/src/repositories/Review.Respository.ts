import { IReview, ReviewSchema } from "../models/Restaurant.model";
import { IPagination } from "../types/Comman.Interface";
import BaseRepository from "./Base.Repository";

class ReviewRepository extends BaseRepository<IReview> {
    constructor() {
        super(ReviewSchema); // Pass the schema to the BaseRepository constructor
    }
    // Add a new review
    async addReview(reviewData: Partial<IReview>): Promise<IReview | null> {
        return await this.create(reviewData);
    }

    // Fetch review data by ID
    async findReviewById(reviewId: string): Promise<IReview | null> {
        return await this.findById(reviewId);
    }

    // Fetch all reviews of a restaurant with pagination
    async findReviews(query: Record<string, any>, pagination: Partial<IPagination> = {}): Promise<IReview[] | null> {
        const { pageSize, skip } = pagination;

        const reviewQuery = this.model.find(query);

        if (skip !== undefined && pageSize !== undefined) {
            reviewQuery
                .skip(skip)
                .limit(pageSize);
        }
        return await reviewQuery.exec();
    }

    // Update review data by ID
    async updateRestaurantById(reviewId: string, reviewData: Partial<IReview>): Promise<IReview | null> {
        return await this.updateById(reviewId, reviewData);
    }

}

const reviewRepository = new ReviewRepository();
export default reviewRepository;
