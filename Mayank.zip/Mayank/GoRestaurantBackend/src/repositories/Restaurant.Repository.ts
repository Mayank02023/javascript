import { IRestaurant, RestaurantSchema } from "../models/Restaurant.model";
import { IPagination, IPaginationOptions } from "../types/Comman.Interface";
import { IRestaurantDto } from "../types/Restaurant.Interface";
import BaseRepository from "./Base.Repository";

class RestaurantRepository extends BaseRepository<IRestaurant> {
    constructor() {
        super(RestaurantSchema); // Pass the schema to the BaseRepository constructor
    }

    /**
     * Register a new restaurant
     * @param restaurantData - Data to create a restaurant
     * @returns The created restaurant
     */
    async createRestaurant(restaurantData: Partial<IRestaurant>): Promise<IRestaurant> {
        return await this.create(restaurantData);
    }

    /**
     * Fetch restaurant data by ID
     * @param restaurantId - The ID of the restaurant
     * @returns The restaurant data or null if not found
     */
    async findRestaurantById(restaurantId: string): Promise<IRestaurant | null> {
        return await this.findById(restaurantId);
    }

    /**
     * Fetch restaurant data by specific fields
     * @param fields - Properties to search for
     * @returns The restaurant data or null if not found
     */
    async findRestaurantByFields(fields: Record<string, any>): Promise<IRestaurant | null> {
        return await this.findByFields(fields);
    }

    /**
     * Fetch multiple restaurants by specific fields
     * @param fields - Properties to search for
     * @returns The list of matching restaurants or an empty array if none are found
     */
    async findRestaurants(query: any, pagination: Partial<IPagination> = {}): Promise<IRestaurant[]> {
        const { pageSize, skip } = pagination;
        const restaurantQuery = this.model.find(query);

        if (skip !== undefined && pageSize !== undefined) {
            restaurantQuery
                .skip(skip)
                .limit(pageSize);
        }

        return await restaurantQuery.exec();
    }

    /**
     * Update restaurant data by ID
     * @param restaurantId - The ID of the restaurant
     * @param restaurantData - Partial data to update
     * @returns The updated restaurant data or null if not found
     */
    async updateRestaurantById(
        restaurantId: string,
        restaurantData: Partial<IRestaurant>
    ): Promise<IRestaurant | null> {
        return await this.updateById(restaurantId, restaurantData);
    }

    /**
     * Delete a restaurant by ID
     * @param restaurantId - The ID of the restaurant
     * @returns True if deleted, otherwise false
     */
    async deleteRestaurantById(restaurantId: string): Promise<boolean> {
        return !!(await this.updateById(restaurantId, { isDelete: true }));
    }

}

const restaurantRepository = new RestaurantRepository();
export default restaurantRepository;
