import { isValidObjectId } from "mongoose";
import BaseRepository from "./Base.Repository";
import AgentSchema, { IAgent } from "../models/Agent.model";

class AgentRepository extends BaseRepository<IAgent> {
    private sensitiveFields: string[] = ["-password", "-refreshToken"];
    constructor() {
        // Pass the AgentSchema to the BaseRepository constructor
        super(AgentSchema)
    }
    private getSensitiveFieldExclusion(): string {
        return this.sensitiveFields.join(" ");
    }

    //Register new agent
    async createAgent(agentData: Partial<IAgent>): Promise<IAgent | null> {
        const agentResponse = await this.create(agentData);
        return agentResponse;
    }

    // Find agent by id
    async findAgentById(agentId: string): Promise<IAgent | null> {
        return this.model.findById(agentId)
        .exec();
    }

    // Find agent by fields, excluding sensitive fields
    async findAgentByFields(fields: Record<string, any>): Promise<IAgent | null> {
        return this.model
            .findOne(fields)
            .exec();
    }
    // Update the agent data
    async updateAgentById(agentId: string, data: Partial<IAgent>): Promise<IAgent | null> {
        return await this.model.findByIdAndUpdate(agentId, data, { new: true, validateBeforeSave: false })
            .select(this.getSensitiveFieldExclusion())
            .exec();
    }

    // Find multiple document by fields
    async findAgentsByFields(fields: Record<string, any>, options?: { limit?: number; sort?: any; projection?: any }): Promise<IAgent[] | null> {
        return await this.model.find(fields, options?.projection).sort(options?.sort).limit(options?.limit || 0)
            .select(this.getSensitiveFieldExclusion()) as IAgent[];
    }

    // Custom method to get agent without sensitive fields
    async getAgentWithoutSensitiveFields(agentId: string): Promise<IAgent | null> {
        return this.model.findById(agentId)
            .select(this.getSensitiveFieldExclusion())
            .exec();
    }

}
const agentRepository = new AgentRepository();
export default agentRepository;