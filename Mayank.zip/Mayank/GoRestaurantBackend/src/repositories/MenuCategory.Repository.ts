import MenuCategoryModel, { IMenuCategory } from "../models/MenuCategory.Model";
import { IPagination } from "../types/Comman.Interface";
import BaseRepository from "./Base.Repository";

// Create the repository functions for CRUD operations
class MenuCategoryRepository extends BaseRepository<IMenuCategory> {

    constructor() {
        super(MenuCategoryModel)
    }
    // Add a new category
    async addMenuCategory(MenuCategoryData: Partial<IMenuCategory>): Promise<IMenuCategory> {
        return await this.create(MenuCategoryData);
    }

    // Add multiple Menu Categories at once
    async addManyMenuCategories(menuCategoriesData: Partial<IMenuCategory>[]): Promise<boolean> {
        const data = await this.model.insertMany(menuCategoriesData);
        return data ? true : false;
    }

    // Get category by ID
    async getMenuCategoryById(menuCategoryId: string): Promise<IMenuCategory | null> {
        return await this.findById(menuCategoryId);
    }

    // Get all categories
    async getAllMenuCategories(query: any, pagination: IPagination): Promise<IMenuCategory[] | null> {
        const { pageSize, skip } = pagination;
        const categories = await this.model.find(query).skip(skip)
            .limit(pageSize).exec();

        return categories;
    }

    // Update a category by ID
    async updateCategory(menuCategoryId: string, menuCategoryData: Partial<IMenuCategory>): Promise<IMenuCategory | null> {
        return await this.updateById(menuCategoryId, menuCategoryData);
    }

    // Delete a category by ID
    async deleteCategory(menuCategoryId: string): Promise<boolean> {
        return !!(await this.model.findByIdAndDelete(menuCategoryId));
    }
}

const menuCategoryRepository = new MenuCategoryRepository();
export default menuCategoryRepository
