import mongoose from "mongoose";
import BaseRepository from "./Base.Repository";
import { IPagination } from "../types/Comman.Interface";
import InventoryModel, { IInventory } from "../models/Inventory.model";
import { ApiError } from "../utils";

class InventoryRepository extends BaseRepository<IInventory> {
    constructor() {
        super(InventoryModel);
    }

    // Add a new inventory item
    async addInventory(inventoryData: Partial<IInventory>): Promise<IInventory | null> {
        return await this.create(inventoryData);
    }

    // Add multiple inventory items at once
    async addManyInventories(inventoriesData: Partial<IInventory>[]): Promise<boolean> {
        const data = await this.model.insertMany(inventoriesData);
        return data ? true : false;
    }

    // Get an inventory item by its ID
    async getInventoryById(inventoryId: string): Promise<IInventory | null> {
        return await this.findById(inventoryId);
    }

    // Find inventory items based on a query and pagination
    async findInventories(query: any, pagination: IPagination):  Promise<IInventory[]> {
        const { pageSize, skip } = pagination;
        const inventories = await this.model.find(query).skip(skip)
            .limit(pageSize).exec();

        return inventories;
    }

    // Update an inventory item by its ID
    async updateInventoryById(inventoryId: string, inventoryData: Partial<IInventory>): Promise<IInventory | null> {
        return await this.updateById(inventoryId, inventoryData);
    }

    // Mark an inventory item as deleted (soft delete)
    async deleteInventoryById(inventoryId: string): Promise<boolean> {
        return !!(await this.updateById(inventoryId, { isDelete: true }));
    }

    // Permanently delete an inventory item
    async deletePermanentInventoryById(inventoryId: string): Promise<boolean> {
        return !!(await this.model.findByIdAndDelete(inventoryId));
    }

    // Delete multiple menu items
    async deleteManyInventories(query: any): Promise<boolean> {
        const data = await this.model.deleteMany(query);
        return data ? true : false;
    }

    // Find inventory items that are below the low stock threshold
    async findLowStockItems(branchId: string): Promise<IInventory[]> {
        return await this.model.find({
            branchId,
            isDelete: false,
            $expr: {
                $lte: ["$quantity", "$lowStockThreshold"], // Compare quantity with lowStockThreshold
            },
        }).exec();
    }

}

const inventoryRepository = new InventoryRepository();
export default inventoryRepository;


