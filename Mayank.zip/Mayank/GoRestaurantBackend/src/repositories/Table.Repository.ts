import TableModel, { ITable } from "../models/Table.model";
import { IPagination } from "../types/Comman.Interface";
import { ApiError } from "../utils";
import BaseRepository from "./Base.Repository";

class TableRepository extends BaseRepository<ITable> {
    constructor() {
        super(TableModel)
    }

    async createTable(userTable: Partial<ITable>): Promise<ITable | null> {
        return await this.create(userTable);
    }

    async getTableById(tableId: string): Promise<ITable | null> {
        return await this.findById(tableId);
    }

    async findTables(query: any, pagination: Partial<IPagination> = {}): Promise<ITable[] | null> {
        const { pageSize = 20, skip = 0 } = pagination;
        return await this.model.find(query).skip(skip)
            .limit(pageSize).exec();;
    }

    async updateTableById(tableId: string, tableData: Partial<ITable>): Promise<ITable | null> {
        const { capacity, occupiedSeats }: Partial<ITable> = tableData;

        const table = await this.findById(tableId);
        if (!table) throw ApiError.notFound("Table not found!");

        // Update fields if provided
        if (capacity) table.capacity = capacity;
        if (occupiedSeats !== undefined) table.occupiedSeats = table.occupiedSeats + occupiedSeats;

        // Save the table with updated values and status
        return await table.save();
    }


    async deleteTableById(tableId: string): Promise<boolean> {
        return !!(await this.deleteById(tableId));
    }
}

const tableRepository = new TableRepository();
export default tableRepository;