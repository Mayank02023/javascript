import mongoose from "mongoose";
import BranchSchema, { IBranch } from "../models/Branch.model";
import BaseRepository from "./Base.Repository";
import { IPagination, IPaginationOptions } from "../types/Comman.Interface";

class BranchRepository extends BaseRepository<IBranch> {
    constructor() {
        super(BranchSchema)
    }

    async addNewBranch(branchData: Partial<IBranch>): Promise<IBranch | null> {
        return await this.create(branchData);
    }

    async addManyBranches(branchsData: Partial<IBranch[]>): Promise<boolean> {
        const data = await this.model.insertMany(branchsData);
        return data ? true : false;
    }

    async getBranchById(branchId: string): Promise<IBranch | null> {
        return await this.findById(branchId);
    }

    async findBranches(query: any, pagination: IPagination): Promise<IBranch[]> {
        const { pageSize, skip } = pagination;
        const branches = await this.model.find(query).skip(skip)
            .limit(pageSize).exec();

        return branches;
    }

    async updateBranchById(branchId: string, branchData: Partial<IBranch>): Promise<IBranch | null> {
        return await this.updateById(branchId, branchData);
    }

    async deleteBranchById(branchId: string): Promise<boolean> {
        return !!(await this.updateById(branchId, { isDelete: true }));
    }

    async deleteParmanentBranchById(branchId: string): Promise<boolean> {
        return !!(await this.model.findByIdAndDelete(branchId));
    }
}

const branchRepository = new BranchRepository();
export default branchRepository;