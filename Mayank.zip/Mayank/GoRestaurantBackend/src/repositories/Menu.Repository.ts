import MenuItemModel, { IMenuItem } from "../models/MenuItem.model";
import { IPagination } from "../types/Comman.Interface";
import BaseRepository from "./Base.Repository";

class MenuRepository extends BaseRepository<IMenuItem> {
    constructor() {
        super(MenuItemModel);
    }

    // Add a new menu item
    async createMenuItem(menuItem: Partial<IMenuItem>): Promise<IMenuItem | null> {
        return this.create(menuItem);
    }

    // Add multiple menu items at once
    async addManyMenuItems(menuItems: Partial<IMenuItem>[]): Promise<boolean> {
        const data = await this.model.insertMany(menuItems);
        return data ? true : false;
    }

    // Get menu item by ID
    async getMenuItemById(menuId: string): Promise<IMenuItem | null> {
        return this.findById(menuId);
    }

    // Get all menu items
    async getAllMenuItems(query: any, pagination: IPagination): Promise<IMenuItem[] | null> {
        const { pageSize, skip } = pagination;
        const categories = await this.model.find(query).skip(skip)
            .limit(pageSize).exec();

        return categories;
        return this.findAll();
    }

    // Update a menu item by ID
    async updateMenuItem(menuId: string, menuItem: Partial<IMenuItem>): Promise<IMenuItem | null> {
        return this.updateById(menuId, menuItem);
    }

    // Delete a menu item by ID
    async deleteMenuItem(menuId: string): Promise<boolean> {
        return !!this.deleteById(menuId);
    }

    // Delete multiple menu items
    async deleteManyMenuItems(query: any): Promise<boolean> {
        const data = await this.model.deleteMany(query);
        return data ? true : false;
    }
}

const menuRepository = new MenuRepository();
export default menuRepository;