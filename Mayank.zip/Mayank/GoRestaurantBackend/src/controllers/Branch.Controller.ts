import { Response } from 'express'
import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler, sendErrorResponse } from "../utils";
import branchService from '../services/Branch.Service';
import mongoose from 'mongoose';


export const addBranch = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const restaurantId: string = req.params.restaurantId;
        if (!restaurantId) throw ApiError.badRequest("Restaurant ID is required to fetch restaurant details.");

        const { name, address } = req.body;
        if (!restaurantId || !name || !address) throw ApiError.badRequest("Branch name, address and restaurant id is required!.");

        const branch = await branchService.addBranch({ name, address, restaurantId: new mongoose.Types.ObjectId(restaurantId) });
        if (!branch) throw ApiError.notFound("Branch did not add!.");
        return res
            .status(201)
            .json(ApiResponse.success(branch, "Branch created successfully.", 201));
    } catch (error: any) {
        sendErrorResponse(error, "Create Branch", res);
    }
});

export const addManyBranches = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const restaurantId: string = req.params.restaurantId;
        if (!restaurantId) throw ApiError.badRequest("Restaurant ID is required to fetch restaurant details.");

        const data = req.body;
        const isAdded = await branchService.addManyBranches(data);
        if (!isAdded) throw ApiError.notFound("Branches are not added!.");
        return res
            .status(201)
            .json(ApiResponse.success({ isAdded }, "All Branches created successfully.", 201));
    } catch (error: any) {
        sendErrorResponse(error, "Create Many Branches", res);
    }
});

export const getBranchById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const branchId: string = req.params.branchId;
        if (!branchId) throw ApiError.badRequest("Branch ID is required to fetch branch details.");

        const branch = await branchService.getBranchById(branchId);
        return res
            .status(200)
            .json(ApiResponse.success(branch, "Branch fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Fetch Branch", res);
    }
});

export const getBranchsByRestaurantId = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const restaurantId: string = req.params.restaurantId;
        if (!restaurantId) throw ApiError.badRequest("Restaurant ID is required to fetch restaurant details.");

        const branches = await branchService.getBranchsByRestaurantId(restaurantId, req.query)
        return res
            .status(200)
            .json(ApiResponse.success(branches, "All Branches fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Fetch Branch", res);
    }
});

export const updateBranchById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const branchId: string = req.params.branchId;
        if (!branchId) throw ApiError.badRequest("Branch ID is required to fetch restaurant details.");

        // Retrieve the branch by ID
        const branch = await branchService.getBranchById(branchId);
        if (!branch) {
            // Branch not found, return a 404 error
            throw ApiError.notFound("Branch with the provided ID was not found.");
        }

        // Check if the branch is marked as deleted
        if (branch.isDelete) {
            // If the branch is deleted, return a 400 error
            throw ApiError.badRequest("This branch is marked as deleted and cannot be updated.");
        }

        const { name, address, managerId, table, status } = req.body;
        if (![name, address, managerId, table, status].some(Boolean)) {
            throw ApiError.badRequest("At least one of the following fields is required: name, address, manager, tables, or status.");
        }
        const updatedBranch = await branchService.updateBranchById(branchId, req.body);
        return res
            .status(200)
            .json(ApiResponse.success(updatedBranch, "Branch updated successfully."));

    } catch (error: any) {
        sendErrorResponse(error, "Update Branch", res);
    }
});

export const deleteBranchById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required to fetch restaurant details.");

        const isDelete = await branchService.deleteBranchById(branchId);

        return res
            .status(200)
            .json(ApiResponse.success({ isDelete }, "Branch deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Delete Branch", res);
    }
});

