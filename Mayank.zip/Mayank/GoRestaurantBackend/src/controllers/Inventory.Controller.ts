import { Response } from "express";
import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler, sendErrorResponse } from "../utils";
import inventoryService from "../services/Inventory.Service";

export const addInventory = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        let branchId: string = req.params.branchId;
        const inventory = await inventoryService.addInventory({ ...req.body, branchId });
        return res.status(200).json(ApiResponse.success(inventory, "Inventory item added successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Add Inventory", res);
    }
});

export const addManyInventories = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const inventoriesData = req.body;

        const result = await inventoryService.addManyInventories(branchId, inventoriesData);

        return res.status(200).json(ApiResponse.success(result, "Multiple inventory items added successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Add Multiple Inventories", res);
    }
});

export const getInventoryById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { inventoryId } = req.params;

        if (!inventoryId) throw ApiError.badRequest("Inventory ID is required.");

        const inventory = await inventoryService.getInventoryById(inventoryId);

        return res.status(200).json(ApiResponse.success(inventory, "Inventory item fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get Inventory", res);
    }
});

export const getInventories = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const inventories = await inventoryService.findInventories(branchId, req.query);

        return res.status(200).json(ApiResponse.success(inventories, "Inventory items fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get Inventories", res);
    }
});

export const updateInventoryById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { inventoryId } = req.params;
        if (!inventoryId) throw ApiError.badRequest("Inventory ID is required.");

        const updatedInventory = await inventoryService.updateInventoryById(inventoryId, { ...req.body });

        return res.status(200).json(ApiResponse.success(updatedInventory, "Inventory item updated successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Update Inventory", res);
    }
});

export const deleteInventoryById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { inventoryId } = req.params;

        if (!inventoryId) throw ApiError.badRequest("Inventory ID is required.");

        const isDeleted = await inventoryService.deleteInventoryById(inventoryId);

        return res.status(200).json(ApiResponse.success({ isDeleted }, "Inventory item deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Delete Inventory", res);
    }
});

export const deletePermanentInventoryById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { inventoryId } = req.params;

        if (!inventoryId) throw ApiError.badRequest("Inventory ID is required.");

        const isDeleted = await inventoryService.deletePermanentInventoryById(inventoryId);

        return res.status(200).json(ApiResponse.success({ isDeleted }, "Inventory item permanently deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Permanent Delete Inventory", res);
    }
});

// Permanent delete maultiple menu items by IDs
export const deleteManyInventoriesbyIds = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { inventoryIds } = req.body;
        if (!inventoryIds) throw ApiError.badRequest("Inventory IDs are required.");

        const result = await inventoryService.deleteManyInventories(inventoryIds);

        return res.status(200).json(ApiResponse.success(result, "Inventory items permanently deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Permanent delete multiple inventories", res);
    }
});

export const findLowStockItems = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const lowStockItems = await inventoryService.findLowStockItems(branchId, req.query);

        return res.status(200).json(ApiResponse.success(lowStockItems, "Low stock items fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Find Low Stock Items", res);
    }
});
