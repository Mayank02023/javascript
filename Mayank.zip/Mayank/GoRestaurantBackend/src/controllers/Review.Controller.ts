import { Response } from "express"
import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler, sendErrorResponse } from "../utils";
import { IReview } from "../models/Restaurant.model";
import mongoose from "mongoose";
import reviewService from "../services/Review.Service";

// Controller to add review for a restaurant
export const addRestaurantReview = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const restaurantId = req.params.restaurantId;
        const { rating, comment } = req.body;

        if (!restaurantId || !rating || !comment) throw ApiError.badRequest("Restaurant ID, rating, and comment are required.");

        //Prepare Review payload
        const reviewDto: Partial<IReview> = {
            restaurantId: new mongoose.Types.ObjectId(restaurantId),
            rating,
            comment
        }
        const newReview = await reviewService.addReviewToRestaurant(reviewDto);
        return res.status(201).json(ApiResponse.success(newReview, "Review added successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Add Review to Restaurant", res);
    }
});

// Controller to get List of reviews of a restaurant
export const getRestaurantReviews = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { restaurantId } = req.params;

        if (!restaurantId) throw ApiError.badRequest("Restaurant Id is required!.");

        const reviews = await reviewService.getReviewsForRestaurant({ ...req.query, restaurantId });

        return res.status(200).json(ApiResponse.success(reviews, "Restaurant reviews fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get Restaurant Reviews", res);
    }
});