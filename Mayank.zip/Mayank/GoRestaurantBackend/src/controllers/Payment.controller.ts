import { Cashfree } from "cashfree-pg";
import { Request, Response } from "express";
import PaymentService from "../services/Paymant.Service";
import { ApiError, ApiResponse, sendErrorResponse } from "../utils";
import crypto from "crypto";
import envConfig from "../config/envConfig";

export const initiatePayment = async (req: Request, res: Response) => {
    try {
        const amount = Number(req.body.amount);
        const response = await PaymentService.createOrder(amount);
        return res.status(200).json(ApiResponse.success(response, "payment initiated successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Initiate payment", res);
    }
};


export const verifyPayment = async (req: Request, res: Response) => {
    try {
        const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId } = req.body;
        if (!razorpay_order_id && !razorpay_payment_id && !razorpay_signature) throw ApiError.badRequest("order id, payment id and signature are required.");
        const response = await PaymentService.verifyPayment({orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature });
        return res.status(200).json(ApiResponse.success(response, "payment verification successfull."));
    } catch (error: any) {
        sendErrorResponse(error, "Payment verification", res);
    }
};
