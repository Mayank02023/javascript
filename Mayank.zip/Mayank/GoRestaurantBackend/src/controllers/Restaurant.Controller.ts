import { Response } from "express";
import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler, sendErrorResponse } from "../utils";
import { IRestaurantDto } from "../types/Restaurant.Interface";
import restaurantService from "../services/Restaurant.service";
import mongoose, { Types } from "mongoose";
import { IRestaurant, IReview } from "../models/Restaurant.model";



// Controller for create a new restaurant.
export const createRestaurant = asyncHandler(async (req: AuthRequest, res: Response) => {
    const { name, email, phoneNumber, address } = req.body;
    const avatar = req.file?.path;
    const agentId = req.user?._id ? req.user._id : undefined;
    try {

        const restaurantData: IRestaurantDto = { name, email, phoneNumber, address, avatar, agentId };
        const newRestaurant = await restaurantService.createRestaurant(restaurantData);

        if (!newRestaurant) {
            throw ApiError.internal("Failed to create the restaurant due to an internal error.");
        }

        return res
            .status(201)
            .json(ApiResponse.success(newRestaurant, "Restaurant created successfully.", 201));
    } catch (error: any) {
        sendErrorResponse(error, "Create Restaurant", res);
    }
});

// Controller to get a restaurant by its ID.
export const getRestaurantById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const restaurantId: string = req.params.restaurantId;
        if (!restaurantId) throw ApiError.badRequest("Restaurant ID is required to fetch restaurant details.");

        const restaurant = await restaurantService.getRestaurantById(restaurantId);
        if (restaurant?.isDelete) throw ApiError.forbidden("Restaurant has been delete so can't fetch!.");

        return res
            .status(200)
            .json(ApiResponse.success(restaurant, "Restaurant fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get Restaurant by ID", res);
    }
});

// Controller to fetch a filtered list of restaurants based on provided fields.
export const getRestaurants = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const user = req.user;
        if (!user) throw ApiError.unauthorized("Unauthorized user!.");

        if (user.role === "agent") {
            req.query.agentId = user._id
        }

        const filteredRestaurants = await restaurantService.getRestaurants(req.query);
        return res
            .status(200)
            .json(ApiResponse.success(filteredRestaurants, "Filtered restaurant list fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get Filtered Restaurants", res);
    }
});

// Controller to update  a restaurants based on it's Id
export const updatedRestaurant = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const restaurantId: string = req.params.restaurantId;
        if (!restaurantId) throw ApiError.badRequest("Restaurant ID is required to update the restaurant.");

        const restaurantData: IRestaurantDto = { ...req.body };
        const updatedRestaurant = await restaurantService.updateRestaurantById(restaurantId, restaurantData);

        return res
            .status(200)
            .json(ApiResponse.success(updatedRestaurant, "Restaurant updated successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Update Restaurant", res);
    }
});

// Controller to assign agent to Restaurant by Id
export const assignAgentToRestaurant = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const restaurantId = req.params.restaurantId;
        const agentId: string = req.body.agentId;

        if (!restaurantId || !agentId) throw ApiError.badRequest("Restaurant ID and Agent ID are required.");

        const updatedRestaurant = await restaurantService.updateRestaurantById(restaurantId, { agentId });

        return res.status(200).json(ApiResponse.success(updatedRestaurant, "Agent assigned successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Assign Agent to Restaurant", res);
    }
});

// Controller to delete Restaurant by Id
export const deleteRestaurant = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const restaurantId: string = req.params.restaurantId;
        if (!restaurantId) throw ApiError.badRequest("Restaurant ID is required to delete the restaurant.");

        const isDelete = await restaurantService.deleteRestaurantById(restaurantId);
        return res
            .status(200)
            .json(ApiResponse.success({ isDelete }, "Restaurant deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Delete Restaurant", res);
    }
});

// Controller to associate branch with the restaurant
export const associateBranchWithRestaurant = asyncHandler(async (req: AuthRequest, res: Response) => {
    const branchId: string = req.body.branchId;
    const restaurantId: string = req.params.restaurantId;
    try {
        if (!restaurantId) throw ApiError.badRequest("Restaurant ID is required to associate branch with the restaurant.");
        if (!branchId) throw ApiError.badRequest("Branch ID is required to associate branch with the restaurant.");

        const isAssociate = await restaurantService.associateBranch(restaurantId, branchId);
        if (!isAssociate) throw ApiError.internal("Failed to associate branch with the restaurant.");

        return res
            .status(200)
            .json(ApiResponse.success({ isAssociate }, "Branch associate with the restaurant successfully."));

    } catch (error: any) {
        sendErrorResponse(error, "Branch Associate", res);
    }
})

