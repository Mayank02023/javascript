import { Response } from "express";
import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler, sendErrorResponse } from "../utils";
import tableService from "../services/Table.Service";
import mongoose from "mongoose";
import { ITable } from "../models/Table.model";

export const addTable = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        let branchId: string | mongoose.Types.ObjectId = req.params.branchId;
        const { capacity } = req.body;

        if (!branchId) throw ApiError.badRequest("Branch id is required!.");
        if (!capacity) throw ApiError.badRequest("Table capacity is required!.");

        branchId = new mongoose.Types.ObjectId(branchId);
        const table = await tableService.addTable({ capacity, branchId });

        return res.status(200).json(ApiResponse.success(table, "Table added successfully."));

    } catch (error: any) {
        sendErrorResponse(error, "Add Table", res);
    }
});

export const getTableById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { tableId } = req.params;
        if (!tableId) throw ApiError.badRequest("table id is required!.");

        const table = await tableService.getTableById(tableId);

        return res.status(200).json(ApiResponse.success(table, "Table fetched successfully."));

    } catch (error: any) {
        sendErrorResponse(error, "Fetch Table", res);
    }
});

export const getTables = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch id is required!.");

        const tables = await tableService.getTables(branchId, req.query);

        return res.status(200).json(ApiResponse.success(tables, "Tables are fetched successfully."));

    } catch (error: any) {
        sendErrorResponse(error, "Fetach Tables", res);
    }
});

export const updateTableById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { tableId } = req.params;
        if (!tableId) throw ApiError.badRequest("table id is required!.");

        const { capacity, occupiedSeats }: Partial<ITable> = req.body;
        if (!capacity && !occupiedSeats) throw ApiError.badRequest("At least one of the following fields is required: capacity or occupiedSeats.")

        const table = await tableService.updateTableById(tableId, { capacity, occupiedSeats });

        return res.status(200).json(ApiResponse.success(table, "Table updated successfully."));

    } catch (error: any) {
        sendErrorResponse(error, "Update Table", res);
    }
});

export const deleteTableById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { tableId } = req.params;
        if (!tableId) throw ApiError.badRequest("table id is required!.");

        const isDelete = await tableService.deleteTableById(tableId);

        return res.status(200).json(ApiResponse.success({ isDelete }, "Table deleted successfully."));

    } catch (error: any) {
        sendErrorResponse(error, "Delete Table", res);
    }
});