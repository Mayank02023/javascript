import mongoose, { Types } from "mongoose";
import { options } from "../constants";
import { IUser } from "../models/User.model";
import userService from "../services/User.Service";
import { AuthRequest, IAuthCredential, IChangePasswordRequest, IUserDto } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler } from "../utils";
import { Request, Response } from "express"; // Import Response from express

// Controller for registering a new user
export const registerUser = asyncHandler(async (req: AuthRequest, res: Response) => {
    const { name, username, password, email, phoneNumber, role } = req.body;
    const avatar = req.file?.path;
    const { branchId, restaurantId } = req.params;
    try {
        const currentUser = req.user;
        if (!currentUser) throw ApiError.unauthorized("User is not authorized to perform this action.");

        if (currentUser?.role == "manager" && (role == "manager" || role == "owner")) throw ApiError.badRequest("A manager can't add manager/owner.")

        if (role !== "owner" && !branchId) throw ApiError.badRequest("Branch ID is required to create the new user.");

        // Create user data DTO
        const userData: IUserDto = { name, username, password, email, phoneNumber, avatar, role, branchId, restaurantId };

        // Call the user service to create the user
        const user = await userService.createUser(userData);

        if (!user) throw ApiError.internal("Failed to register the user due to an internal error.");

        // Return success response
        res.status(201).json(ApiResponse.success(user, "User registered successfully.", 201));
    } catch (error: any) {
        console.error("Register Error:", error.message);
        res.status(error.statusCode || 500).json(ApiResponse.error(error.message || "An unexpected error occurred while registering the user.", error.statusCode || 500));
    }
});

// Controller for logging in a user
export const loginUser = asyncHandler(async (req: Request, res: Response) => {
    const { username, phoneNumber, password } = req.body;
    const AuthCredentials: IAuthCredential = {
        username,
        phoneNumber,
        password
    }
    try {
        const { user, accessToken, refreshToken } = await userService.loginUser(AuthCredentials);
        // Return a successful response after logging in with user data
        return res
            .status(200)
            .cookie("accessToken", accessToken, options)
            .cookie("refreshToken", refreshToken, options)
            .json(ApiResponse.success(
                { user, accessToken, refreshToken },
                "User logged in successfully."
            ));
    } catch (error: any) {
        console.error("Login Error:", error.message);
        // Return error response
        const statusCode = error.statusCode || 500;
        const errorMessage = `Login Error: ${error.message}` || "Login Error: An unexpected error occurred while loggin the user.";

        return res
            .status(statusCode)
            .json(ApiResponse.error(errorMessage, statusCode));
    }
});

// Controller for user logout
export const LogoutUser = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        // Extract userId from the authenticated user object
        const userId: string | undefined = req?.user?._id;

        if (!userId) throw ApiError.unauthorized("Invalid access token. Please log in again.");

        // Perform logout operation
        const isLoggedOut = await userService.logout(userId);

        if (!isLoggedOut) throw ApiError.notFound("User not found or already logged out.");

        // Clear cookies and return success response
        return res
            .status(200)
            .clearCookie("accessToken", options)
            .clearCookie("refreshToken", options)
            .json(ApiResponse.success({ isLoggedOut }, "User logged out successfully."));
    } catch (error: any) {
        console.error("Logout Error:", error.message);
        // Return error response
        const statusCode = error.statusCode || 500;
        const errorMessage = `Logout Error: ${error.message}` || "Logout Error: An unexpected error occurred while logged the user.";

        return res
            .status(statusCode)
            .json(ApiResponse.error(errorMessage, statusCode));
    }
});

// Controller for refreshing access token for a user
export const refreshAccessToken = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        // Get the refresh token from cookies or request body
        const incomingRefreshToken: string | undefined = req.cookies.refreshToken || req.body.refreshToken;

        // Check if the refresh token is missing or invalid, throw an unauthorized error
        if (!incomingRefreshToken) throw ApiError.unauthorized("Refresh token is missing or invalid.");

        // Call the service to refresh the access token using the incoming refresh token
        const { accessToken, refreshToken } = await userService.refreshAccessToken(incomingRefreshToken);

        // Return a successful response after generating refresh and access token
        return res
            .status(200)
            .cookie("accessToken", accessToken, options)
            .cookie("refreshToken", refreshToken, options)
            .json(ApiResponse.success(
                { accessToken, refreshToken },
                "Access token refreshed successfully."
            ));
    } catch (error: any) {
        console.error("Refresh Token error:", error.message);
        // Return error response
        const statusCode = error.statusCode || 500;
        const errorMessage = `Refresh Token Error: ${error.message}` || "Refresh Token Error: An unexpected error occurred while updating access and refresh token.";

        return res
            .status(statusCode)
            .json(ApiResponse.error(errorMessage, statusCode));
    }
});

// Controller for changing the current password
export const changeCurrentUserPassword = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        // Extract data from the request body
        const { oldPassword = "", newPassword = "" } = req.body;

        // Validate input
        if (!oldPassword || !newPassword) ApiError.badRequest("Both old and new passwords are required.");

        // Get the user ID from params
        const userId = req.params.userId || req.user?._id;

        if (!userId) throw ApiError.unauthorized("User ID not found. Please log in again.");

        // Call the service to handle the password change
        const changePasswordPayload: IChangePasswordRequest = { oldPassword, newPassword, objectId: userId };
        await userService.changeCurrentPassword(changePasswordPayload);

        // Return a success response
        return res.status(200).json(
            ApiResponse.success({ isPasswordChanged: true }, "Password changed successfully.")
        );
    } catch (error: any) {
        console.error("Change password error:", error.message);
        // Return error response
        const statusCode = error.statusCode || 500;
        const errorMessage = `Change password Error: ${error.message}` || "Change password Error: An unexpected error occurred while updating user password details.";

        return res
            .status(statusCode)
            .json(ApiResponse.error(errorMessage, statusCode));
    }
});

// Controller for getting the current logged user
export const getCurrentUser = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        // Get the user ID from the middleware
        const userId = req?.user?._id;

        if (!userId) throw ApiError.unauthorized("User ID not found. Please log in again.");

        const user = await userService.getCurrentUser(userId);

        // Return a successful response of the current logged restaurant
        return res
            .status(200)
            .json(ApiResponse.success(user, "Current user fetched successfully"));
    } catch (error: any) {
        console.error("Current User Error:", error.message);

        // Return error response
        const statusCode = error.statusCode || 500;
        const errorMessage = `Current User Error: ${error.message}` || "Current User Error: An unexpected error occurred while getting current user details.";

        return res
            .status(statusCode)
            .json(ApiResponse.error(errorMessage, statusCode));
    }
})

// Controller to update the details of the currently logged-in user
export const updateUserDetails = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        // Get the user ID from params
        const userId = req.params.userId;

        if (!userId) throw ApiError.unauthorized("User ID not found. Please log in again.");

        const { body } = req;
        // Prepare user data (after validation from middleware)
        const userData: Partial<IUser> = {
            ...body,
            demographic: body.demographic ? { ...body.demographic } : undefined,
        };

        // Call the service to update the user
        const updatedUser = await userService.updateUserDetails(userId, userData);

        // Return a successful response of the update user 
        return res
            .status(200)
            .json(ApiResponse.success(updatedUser, "User details updated successfully"));

    } catch (error: any) {
        console.error("Update User Error:", error.message);

        // Return error response
        const statusCode = error.statusCode || 500;
        const errorMessage = `Update User Error: ${error.message}` || "Update User Error: An unexpected error occurred while updating user details.";

        return res
            .status(statusCode)
            .json(ApiResponse.error(errorMessage, statusCode));
    }
});

// Controller to update the avatar of the currently logged-in user
export const updateUserAvatar = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        // Get the user ID from params
        const userId = req.params.userId;

        if (!userId) throw ApiError.unauthorized("User ID not found. Please log in again.");

        // Get the file path from the request file property added by middleware
        const avatarLocalPath = req.file?.path;

        // Check if an image file is provided
        if (!avatarLocalPath) throw ApiError.badRequest("Avatar file is missing");

        //Call the update user avatar service
        const updatedAvatar = await userService.updateUserAvatar(userId, avatarLocalPath);

        // Return a successful response of the updated user avatar 
        return res
            .status(200)
            .json(ApiResponse.success({ newAvatar: updatedAvatar }, "User avatar updated successfully"));

    } catch (error: any) {
        console.error("Update user avatar error:", error.message);

        // Return error response
        const statusCode = error.statusCode || 500;
        const errorMessage = `Update user avatar error: ${error.message}` || "Update user avatar error: An unexpected error occurred while updating user avatar.";

        return res
            .status(statusCode)
            .json(ApiResponse.error(errorMessage, statusCode));
    }
})

// Controller to get profile of the currently logged-in user
export const getUserProfile = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { userId } = req.params;

        if (!userId?.trim()) throw new ApiError(400, "Username is missing");

        const userProfile = await userService.getUserProfile(userId);

        // Respond with the updated restaurant avatar
        return res
            .status(200)
            .json(ApiResponse.success(userProfile, "User profile fetched successfully"));
    } catch (error: any) {
        console.error("User profile error:", error.message);

        // Return error response
        const statusCode = error.statusCode || 500;
        const errorMessage = `User profile error: ${error.message}` || "User profile error: An error occurred while  fetching user profile data.";

        return res
            .status(statusCode)
            .json(ApiResponse.error(errorMessage, statusCode));
        throw new ApiError(500, "An error occurred while  fetching restaurant profile data.");
    }
});




