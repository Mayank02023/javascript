import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler } from "../utils";
import { Response } from "express";
import { generateContent } from "../utils/AI/generateContent";
import { textToSpeech } from "../utils/AI/textToSpeech";

export const chat = asyncHandler(async (req: AuthRequest, res: Response) => {
    const { prompt } = req.query;
    try {
        if (!prompt) throw ApiError.badRequest("prompt is required.");

        // Validate that prompt is a string
        if (typeof prompt !== 'string') throw ApiError.badRequest("Prompt must be a string.");
        const apiKey = 'AIzaSyDsqmYsixhDIbFZqssCNb7HjJqo93PHV-M';

        // Generate content based on the input prompt
        const responseText: string = await generateContent(apiKey, prompt);

        // Check if a response was generated
        if (!responseText) {
            console.log("Failed: No response generated.");
            throw ApiError.internal("No response generated")
        }

        // Convert the generated text to speech (non-blocking)
        textToSpeech(responseText).catch(err =>
            console.error("Error in text-to-speech:", err)
        );

        return res
            .status(200)
            .json(ApiResponse.success(responseText, "Branch deleted successfully."));
    } catch (err: any) {
        console.error(err);
        return res.status(500).json({ message: err.message, error: true });
    }
});