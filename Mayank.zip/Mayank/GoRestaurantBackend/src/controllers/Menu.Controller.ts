import { Response } from "express";
import menuService from "../services/Menu.Service";
import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler, sendErrorResponse } from "../utils";

// Add a menu item
export const addMenuItem = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        const avatar = req.file?.path;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const menuItemData = { ...req.body, avatar };

        const newMenuItem = await menuService.addMenuItem(branchId, menuItemData);

        return res.status(201).json(ApiResponse.success(newMenuItem, "Menu item added successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Add menu item", res);
    }
});

// Add multiple menu items
export const addManyMenuItems = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const menuItemsData = req.body;

        const result = await menuService.addManyMenuItems(branchId, menuItemsData);

        return res.status(201).json(ApiResponse.success({ isAdded: result.status }, result.message));
    } catch (error: any) {
        sendErrorResponse(error, "Add multiple menu items", res);
    }
});

// Get menu item by ID
export const getMenuItemById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { menuItemId } = req.params;
        if (!menuItemId) throw ApiError.badRequest("Menu item ID is required.");

        const menuItem = await menuService.getMenuItemById(menuItemId);

        return res.status(200).json(ApiResponse.success(menuItem, "Menu item fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get menu item", res);
    }
});

// Get all menu items
export const getMenuItems = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const menuItemsData = await menuService.getMenuItems(branchId, req.query);
        return res.status(200).json(ApiResponse.success(menuItemsData, "Menu items fetched successfully."));


    } catch (error: any) {
        sendErrorResponse(error, "Get all menu items", res);
    }
});

// Get all menu items
export const getUnavailableMenuItems = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const menuItems = await menuService.getUnavailableMenuItems(branchId, req.query);

        return res.status(200).json(ApiResponse.success(menuItems, "Menu items fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get all menu items", res);
    }
});

// Update a menu item by ID
export const updateMenuItemById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { menuItemId } = req.params;
        if (!menuItemId) throw ApiError.badRequest("Menu item ID is required.");

        const menuItemData = req.body;

        const updatedMenuItem = await menuService.updateMenuItem(menuItemId, menuItemData);

        return res.status(200).json(ApiResponse.success(updatedMenuItem, "Menu item updated successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Update menu item", res);
    }
});

// Soft delete a menu item by ID
export const deleteMenuItemById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { menuItemId } = req.params;
        if (!menuItemId) throw ApiError.badRequest("Menu item ID is required.");

        const result = await menuService.deleteMenuItem(menuItemId);

        return res.status(200).json(ApiResponse.success(result, "Menu item deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Delete menu item", res);
    }
});

// Re-Active deleted menu item by ID
export const reactivatedMenuItemById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { menuItemId } = req.params;
        if (!menuItemId) throw ApiError.badRequest("Menu item ID is required.");

        const result = await menuService.reactivatedMenuItem(menuItemId);

        return res.status(200).json(ApiResponse.success(result, "Menu item has been activate successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Re-Active menu item", res);
    }
});

// Permanent delete a menu item by ID
export const deleteMenuItemPermanentById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { menuItemId } = req.params;
        if (!menuItemId) throw ApiError.badRequest("Menu item ID is required.");

        const result = await menuService.deleteMenuItem(menuItemId);

        return res.status(200).json(ApiResponse.success(result, "Menu item permanently deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Permanent delete menu item", res);
    }
});

// Permanent delete maultiple menu items by IDs
export const deleteManyMenuItemsbyIds = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { menuItemIds } = req.body;
        if (!menuItemIds) throw ApiError.badRequest("Menu item IDs are required.");

        const result = await menuService.deleteManyMenuItems(menuItemIds);

        return res.status(200).json(ApiResponse.success(result, "Menu items permanently deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Permanent delete multiple menu items", res);
    }
});
