import { Response } from "express";
import orderService from "../services/OrderService";
import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler, sendErrorResponse } from "../utils";
import { IOrderRequest } from "../types/Request.Interface";

// Create a new order
export const createOrder = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const orderData: IOrderRequest = req.body;

        const newOrder = await orderService.createOrder(branchId, orderData);

        return res.status(201).json(ApiResponse.success(newOrder, "Order created successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Create order", res);
    }
});

// Get order by ID
export const getOrderById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { orderId } = req.params;
        if (!orderId) throw ApiError.badRequest("Order ID is required.");

        const order = await orderService.getOrderById(orderId);

        return res.status(200).json(ApiResponse.success(order, "Order fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get order", res);
    }
});

// Get all orders
export const getOrders = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        const { ids } = req.query;
        if (!branchId && !ids) throw ApiError.badRequest("Branch ID Or Order id is required.");

        const ordersData = await orderService.getOrders(branchId, req.query);
        return res.status(200).json(ApiResponse.success({
            orders: ordersData.orders,
            total: ordersData.total
        }, "Orders fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get all orders", res);
    }
});

export const todaysOrders = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const startDate = new Date();
        startDate.setHours(0, 0, 0, 0);

        const endDate = new Date();
        endDate.setHours(23, 59, 59, 999);
        const ordersData = await orderService.getOrders(branchId, { startDate, endDate });
        return res.status(200).json(ApiResponse.success({
            orders: ordersData.orders,
            total: ordersData.total
        }, "Orders fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get all orders", res);
    }
});

// Update an order by ID
export const updateOrderById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { orderId } = req.params;
        if (!orderId) throw ApiError.badRequest("Order ID is required.");

        const orderData = req.body;

        const updatedOrder = await orderService.updateOrder(orderId, orderData);

        return res.status(200).json(ApiResponse.success(updatedOrder, "Order updated successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Update order", res);
    }
});

// Delete an order by ID
export const deleteOrderById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { orderId } = req.params;
        if (!orderId) throw ApiError.badRequest("Order ID is required.");

        const result = await orderService.deleteOrder(orderId);

        return res.status(200).json(ApiResponse.success(result, "Order deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Delete order", res);
    }
});

// Permanent delete an order by ID
export const deleteOrderPermanentById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { orderId } = req.params;
        if (!orderId) throw ApiError.badRequest("Order ID is required.");

        const result = await orderService.deleteOrder(orderId);

        return res.status(200).json(ApiResponse.success(result, "Order permanently deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Permanent delete order", res);
    }
});
