import { options } from "../constants";
import { IAgent } from "../models/Agent.model";  // Assuming you have an Agent model
import agentService from "../services/Agent.Service";  // Assuming you have an agentService
import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler, sendErrorResponse } from "../utils";
import { Request, Response } from "express";

// Controller for registering a new agent
export const registerAgent = asyncHandler(async (req: Request, res: Response) => {
    const { name, username, password, email, phoneNumber, role } = req.body;
    const avatar = req.file?.path;
    try {
        // Create agent data DTO
        const agentData = { name, username, password, email, phoneNumber, avatar, role };

        // Call the agent service to create the agent
        const agent = await agentService.createAgent(agentData);

        if (!agent) {
            throw ApiError.internal("Failed to register the agent due to an internal error.");
        }

        // Return success response
        return res
            .status(201)
            .json(ApiResponse.success(agent, "Agent registered successfully.", 201));
    } catch (error: any) {
        sendErrorResponse(error, "Register", res);
    }
});

// Controller for logging in an agent
export const loginAgent = asyncHandler(async (req: Request, res: Response) => {
    const { username, phoneNumber, password } = req.body;
    const authCredentials = { username, phoneNumber, password };
    try {
        const { agent, accessToken, refreshToken } = await agentService.loginAgent(authCredentials);
        return res
            .status(200)
            .cookie("accessToken", accessToken, options)
            .cookie("refreshToken", refreshToken, options)
            .json(ApiResponse.success(
                { agent, accessToken, refreshToken },
                "Agent logged in successfully."
            ));
    } catch (error: any) {
        sendErrorResponse(error, "Login", res);
    }
});

// Controller for agent logout
export const logoutAgent = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const agentId: string | undefined = req?.user?._id;

        if (!agentId) throw ApiError.unauthorized("Invalid access token. Please log in again.");

        const isLoggedOut = await agentService.logout(agentId);

        if (!isLoggedOut) throw ApiError.notFound("Agent not found or already logged out.");

        return res
            .status(200)
            .clearCookie("accessToken", options)
            .clearCookie("refreshToken", options)
            .json(ApiResponse.success({ isLoggedOut }, "Agent logged out successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Logout", res);
    }
});

// Controller for refreshing agent access token
export const refreshAgentAccessToken = asyncHandler(async (req: Request, res: Response) => {
    try {
        const incomingRefreshToken: string | undefined = req.cookies.refreshToken || req.body.refreshToken;

        if (!incomingRefreshToken) throw ApiError.unauthorized("Refresh token is missing or invalid.");

        const { accessToken, refreshToken } = await agentService.refreshAccessToken(incomingRefreshToken);

        return res
            .status(200)
            .cookie("accessToken", accessToken, options)
            .cookie("refreshToken", refreshToken, options)
            .json(ApiResponse.success(
                { accessToken, refreshToken },
                "Access token refreshed successfully."
            ));
    } catch (error: any) {
        sendErrorResponse(error, "Refresh Token", res);
    }
});

// Controller for changing agent password
export const changeAgentPassword = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { oldPassword = "", newPassword = "" } = req.body;

        if (!oldPassword || !newPassword) throw ApiError.badRequest("Both old and new passwords are required.");

        const agentId = req?.user?._id;

        if (!agentId) throw ApiError.unauthorized("Agent ID not found. Please log in again.");

        const changePasswordPayload = { oldPassword, newPassword, objectId: agentId };
        await agentService.changeCurrentPassword(changePasswordPayload);

        return res.status(200).json(
            ApiResponse.success({ isPasswordChanged: true }, "Password changed successfully.")
        );
    } catch (error: any) {
        sendErrorResponse(error, "Change password", res);
    }
});

// Controller for getting current agent details
export const getCurrentAgent = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const agentId = req?.user?._id;

        if (!agentId) throw ApiError.unauthorized("Agent ID not found. Please log in again.");

        const agent = await agentService.getCurrentAgent(agentId);

        return res
            .status(200)
            .json(ApiResponse.success(agent, "Current agent fetched successfully"));
    } catch (error: any) {
        sendErrorResponse(error, "Current Agent", res);
    }
});

// Controller to update agent details
export const updateAgentDetails = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const agentId: string = req.params.agentId;
        if (!agentId) throw ApiError.unauthorized("Agent ID not found. Please log in again.");

        const { body } = req;
        const agentData: Partial<IAgent> = { ...body };

        const updatedAgent = await agentService.updateAgentDetails(agentId, agentData);

        return res
            .status(200)
            .json(ApiResponse.success(updatedAgent, "Agent details updated successfully"));
    } catch (error: any) {
        sendErrorResponse(error, "Update Agent", res);

    }
});

// Controller to update the avatar of the current agent
export const updateAgentAvatar = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const agentId = req?.user?._id;

        if (!agentId) throw ApiError.unauthorized("Agent ID not found. Please log in again.");

        const avatarLocalPath = req.file?.path;

        if (!avatarLocalPath) throw ApiError.badRequest("Avatar file is missing");

        const updatedAvatar = await agentService.updateAgentAvatar(agentId, avatarLocalPath);

        return res
            .status(200)
            .json(ApiResponse.success({ newAvatar: updatedAvatar }, "Agent avatar updated successfully"));
    } catch (error: any) {
        console.error("Update agent avatar error:", error.message);
        sendErrorResponse(error, "Update agent avatar", res);

    }
});

// Controller to get profile of the currently logged-in agent
export const getAgentProfile = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { agentId } = req.params;

        if (!agentId?.trim()) throw new ApiError(400, "Agent id is missing");

        const agentProfile = await agentService.getAgentProfile(agentId);

        // Respond with the updated restaurant avatar
        return res
            .status(200)
            .json(ApiResponse.success(agentProfile, "Agent profile fetched successfully"));
    } catch (error: any) {
        sendErrorResponse(error, "Agent profile", res);
    }
});

export const addAssignedRestaurant = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { restaurantId } = req.params;
        const { agentId } = req.body;
        if (!restaurantId || !agentId) throw ApiError.badRequest("Restaurant Id and Agent Id are required!.");
        const isAssigned = await agentService.addAssignedRestaurant(agentId, restaurantId);
        // Respond with the updated restaurant avatar
        return res
            .status(200)
            .json(ApiResponse.success({isAssigned}, "Agent profile fetched successfully"));
    } catch (error: any) {
        sendErrorResponse(error, "Agent profile", res);
    }
});



