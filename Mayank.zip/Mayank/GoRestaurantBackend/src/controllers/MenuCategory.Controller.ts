import { Response } from "express";
import { AuthRequest } from "../types/Auth.Interface";
import { ApiError, ApiResponse, asyncHandler, sendErrorResponse } from "../utils";
import menuCategoryService from "../services/MenuCategory.Service";

// Add a single menu category
export const addMenuCategory = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const branchId: string = req.params.branchId;
        const { name, description } = req.body;

        // Validate inputs
        if (!branchId) throw ApiError.badRequest("Branch Id is required.");
        if (!name || !description) throw ApiError.badRequest("Category name and description are required.");

        const menuCategory = await menuCategoryService.addMenuCategory(branchId, { name, description });

        return res.status(200).json(ApiResponse.success(menuCategory, "Menu category added successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Add new menu category", res);
    }
});

// Add multiple menu categories
export const addManyMenuCategories = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const branchId: string = req.params.branchId;
        const menuCategoriesData = req.body;

        // Validate inputs
        if (!branchId) throw ApiError.badRequest("Branch Id is required.");
        if (!Array.isArray(menuCategoriesData)) throw ApiError.badRequest("Menu categories data must be an array.");

        const result = await menuCategoryService.addManyMenuCategories(branchId, menuCategoriesData);

        return res.status(200).json(ApiResponse.success({ isAdded: result.status }, result.message));
    } catch (error: any) {
        sendErrorResponse(error, "Failed to add multiple menu categories", res);
    }
});

// Get menu category by ID
export const getMenuCategoryById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { menuCategoryId } = req.params;
        if (!menuCategoryId) throw ApiError.badRequest("Menu category Id is required.");

        const category = await menuCategoryService.getMenuCategoryById(menuCategoryId);

        return res.status(200).json(ApiResponse.success(category, "Menu category fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Get menu category by ID", res);
    }
});

// Find menu categories with pagination and filters
export const getMenuCategories = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { branchId } = req.params;
        if (!branchId) throw ApiError.badRequest("Branch ID is required.");

        const categories = await menuCategoryService.findMenuCategories(branchId, req.query);

        return res.status(200).json(ApiResponse.success(categories, "Menu categories fetched successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Find menu categories", res);
    }
});

// Update a menu category by ID
export const updateMenuCategoryById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { menuCategoryId } = req.params;
        if (!menuCategoryId) throw ApiError.badRequest("Menu category Id is required.");

        const menuCategoryData = req.body;

        const updatedCategory = await menuCategoryService.updateMenuCategory(menuCategoryId, menuCategoryData);

        return res.status(200).json(ApiResponse.success(updatedCategory, "Menu category updated successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Update menu category", res);
    }
});

// Soft delete a menu category by ID
export const deleteMenuCategoryById = asyncHandler(async (req: AuthRequest, res: Response) => {
    try {
        const { menuCategoryId } = req.params;
        if (!menuCategoryId) throw ApiError.badRequest("Menu category Id is required.");

        const result = await menuCategoryService.deleteMenuCategory(menuCategoryId);

        return res.status(200).json(ApiResponse.success(result, "Menu category deleted successfully."));
    } catch (error: any) {
        sendErrorResponse(error, "Delete menu category", res);
    }
});

