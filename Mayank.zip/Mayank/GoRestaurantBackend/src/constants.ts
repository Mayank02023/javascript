export const DB_NAME = "GoRestaurantBackend";

export const options = {
    httpOnly: true,
    secure: true
}

export const queryOptions = { page: 1, limit: 20 };

export const orderConstant = {
    orderStatus: ['PENDING', 'CONFIRMED', 'PREPARING', 'READY', 'COMPLETED', 'CANCELLED'],
    orderType: ['DINE_IN', 'TAKEAWAY'],
    paymentStatus: ['INITIATED', 'SUCCESS', 'FAILED'],
    paymentMethod: ['CASH', 'ONLINE']

}