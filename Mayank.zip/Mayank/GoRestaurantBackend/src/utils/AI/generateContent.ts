import { GenerateContentResult, GoogleGenerativeAI } from '@google/generative-ai';

/**
 * Utility function to generate content using Google's Gemini AI model.
 * @param apiKey - Your Google API Key.
 * @param prompt - The prompt to send to the AI model.
 * @param model - The AI model to use (default: "gemini-1.5-flash").
 * @returns A Promise that resolves with the generated content from the model.
 */
export async function generateContent(
    apiKey: string,
    prompt: string,
): Promise<string> {
    try {
        // Initialize the GoogleGenerativeAI client
        const genAI = new GoogleGenerativeAI(apiKey);

        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp",
        });

        const generationConfig = {
            temperature: 1,
            topP: 0.95,
            topK: 40,
            maxOutputTokens: 8192,
            responseMimeType: "text/plain",
        };

        const chatSession = model.startChat({
            generationConfig,
            history: [
            ],
        });

        // Generate content using the provided prompt.
        // We assume the returned result matches the GenerateContentResult interface.
        const result = await chatSession.sendMessage(prompt);

        // Return the generated text response.
        return result.response.text();
    } catch (error: any) {
        console.error('Error generating content:', error);
        throw new Error('Error generating content from the AI model');
    }
}




