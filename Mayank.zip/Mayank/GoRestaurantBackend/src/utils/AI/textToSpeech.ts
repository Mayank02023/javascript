import say from 'say';

/**
 * Utility function to convert text to speech.
 * @param text - The text to convert to speech.
 * @param voice - The voice to use (default is 'Alex').
 * @param speed - The speed of speech (default is 1.0).
 * @returns A Promise that resolves when speech is finished, or rejects with an error.
 */
export function textToSpeech(
  text: string,
  voice: string = 'Alex',
  speed: number = 1.0
): Promise<void> {
  return new Promise((resolve, reject) => {
    say.speak(text, voice, speed, (err: string | null) => {
      if (err) {
        return reject(err);
      }
      resolve();
    });
  });
}
