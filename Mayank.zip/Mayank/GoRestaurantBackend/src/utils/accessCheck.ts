// Helper function to handle role-based access control
export const isRoleAllowed = (userRole: string, allowedRoles: string[]): boolean => {
    return allowedRoles.includes(userRole);
};

// // Helper function to check if manager can access the profile
// export const isAgentAllowed = (userData: any, user: any): boolean => {
// };

// Helper function to check if manager can access the profile
export const isManagerAllowed = (userData: any, user: any): boolean => {
    return userData?.branchId === user?.branchId;
};

// Helper function to check if owner can access the profile
export const isOwnerAllowed = (userData: any, user: any): boolean => {
    return userData?.restaurantId === user?.restaurantId;
};