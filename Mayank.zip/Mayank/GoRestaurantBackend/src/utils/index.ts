import ApiResponse from "../utils/apiResponse";
import uploadFileService from "../utils/cloudinary";
import { asyncHandler } from "../utils/asyncHandler";
import ApiError from "../utils/apiError";
import { decodeToken } from "./decodeToken";
import { sendErrorResponse } from "./sendErrorResponse";

const getRestockDate = (restockDays: number) => {
    const todayDate = new Date();
    const newDate = new Date(todayDate);
    newDate.setDate(todayDate.getDate() + restockDays);
    return newDate;
}

export {
    ApiError,
    ApiResponse,
    asyncHandler,
    uploadFileService,
    decodeToken,
    sendErrorResponse,
    getRestockDate
}