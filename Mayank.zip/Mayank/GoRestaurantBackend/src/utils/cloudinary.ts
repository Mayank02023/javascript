import { v2 as Cloudinary, UploadApiResponse } from "cloudinary";
import fs from 'fs';

class UploadFileService {
    private cloud_name: string;
    private api_key: string;
    private api_secret: string;
    private cloudinaryService: typeof Cloudinary;

    constructor() {
        this.cloud_name = String(process.env.CLOUDINARY_CLOUD_NAME);
        this.api_key = String(process.env.CLOUDINARY_API_KEY);
        this.api_secret = String(process.env.CLOUDINARY_API_SECRET);

        // Configure Cloudinary with environment variables
        this.cloudinaryService = Cloudinary;
        this.cloudinaryService.config({
            cloud_name: this.cloud_name,
            api_key: this.api_key,
            api_secret: this.api_secret,
        });
    }

    /**
        * Upload a file to Cloudinary.
        * @param localFilePath The path to the local file to be uploaded.
        * @returns A Promise resolving to the upload response or null if an error occurs.
    */
    public async uploadOnCloudinary(localFilePath: string): Promise<UploadApiResponse | null> {
        if (!localFilePath) return null;

        try {
            // Upload the file to Cloudinary
            const response: UploadApiResponse = await this.cloudinaryService.uploader.upload(localFilePath);

            // Log success message
            console.log("File has been uploaded successfully on Cloudinary:", response.url);

            return response;
        } catch (err) {
            console.error("Error uploading file to Cloudinary:", err);
            return null;
        } finally {
            // Remove the saved temporary file once the operation is finished
            if (fs.existsSync(localFilePath)) {
                fs.unlinkSync(localFilePath);
            }
        }
    }
}

const uploadFileService = new UploadFileService();

export default uploadFileService;
