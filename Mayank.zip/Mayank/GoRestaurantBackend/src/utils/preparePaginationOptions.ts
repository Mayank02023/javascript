import { IPagination, IPaginationOptions } from "../types/Comman.Interface";

export function preparePaginationOptions(body: any = {}): IPaginationOptions {
    const { page = 1, sortBy, pageSize = 20 } = body;

    const validatedPage = Math.max(1, parseInt(page, 10) || 1);
    const validatedPageSize = Math.max(1, parseInt(pageSize, 10) || 20);

    const skip = (validatedPage - 1) * validatedPageSize;
    const limit = validatedPageSize;

    return {
        page: validatedPage,
        pageSize: validatedPageSize,
        skip,
        limit,
        sort: sortBy || {},
    };
}

export const handlePagination = (page: any = 1, limit: any = 20): IPagination => {
    const pageNumber = isNaN(Number(page)) ? 1 : parseInt(page as string, 10);
    const pageSize = isNaN(Number(limit)) ? 20 : parseInt(limit as string, 10);
    const skip = (pageNumber - 1) * pageSize;

    return { pageSize, skip };
};
