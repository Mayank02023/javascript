import jwt, { JwtPayload } from 'jsonwebtoken';

interface DecodeTokenOptions {
    secret: string;
}

export const decodeToken = (token: string, options: DecodeTokenOptions): JwtPayload | null => {
    try {
        // Verify and decode the token using the provided secret
        return jwt.verify(token, options.secret) as JwtPayload;
    } catch (error) {
        console.error('Error decoding token:', error);
        return null; // Return null if the token is invalid
    }
};
