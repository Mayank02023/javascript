class ApiResponse {
    statusCode: number;
    data: any | null;
    message: string;
    success: boolean;

    constructor(statusCode: number, data: any = null, message: string = "Success") {
        this.statusCode = statusCode;
        this.data = data;
        this.message = message;
        this.success = statusCode >= 200 && statusCode < 400;
    }

    static success(data: any, message = "Success", statusCode = 200): ApiResponse {
        return new ApiResponse(statusCode, data, message);
    }

    static error(message: string, statusCode = 500, data: any = null): ApiResponse {
        return new ApiResponse(statusCode, data, message);
    }
}

export default ApiResponse;
