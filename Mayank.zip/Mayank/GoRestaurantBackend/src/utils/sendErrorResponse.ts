import { Response } from 'express';
import ApiResponse from './apiResponse';

export const sendErrorResponse = (
    error: { statusCode?: number; message?: string },
    defaultMessage: string,
    res: Response
) => {
    const statusCode = error.statusCode || 500;
    const errorMessage = `${defaultMessage} Error: ${error.message}`;
    console.error(errorMessage);
    return res
        .status(statusCode)
        .json(ApiResponse.error(errorMessage, statusCode));
};
