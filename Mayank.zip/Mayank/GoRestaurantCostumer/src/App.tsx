
import { FluentProvider, Spinner, webLightTheme } from '@fluentui/react-components';
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { Navbar } from './Components';
import { useState } from 'react';
import { InfiniteScrollList } from './Pages';
import ChatMessageBox from './Pages/ChatMessageBox';
const router = createBrowserRouter([
  {
    path: '/',
    element: <Navbar />,
    children: [
      {
        path: '/:branchId/menu',
        element: <InfiniteScrollList />,
      },
      {
        path: '/chat/',
        element: <ChatMessageBox />

      },
      {
        path: '*',  // Catch-all route for unknown paths
        element: <div>404 - Page Not Found</div>,  // You can customize this with a more elaborate 404 component
      },
    ]
  }
]);
export default function App() {
  const [loading] = useState(false);



  return (
    <FluentProvider theme={webLightTheme}>
      {!loading ? (<RouterProvider router={router} />) : <Spinner />}
    </FluentProvider>
  );
}