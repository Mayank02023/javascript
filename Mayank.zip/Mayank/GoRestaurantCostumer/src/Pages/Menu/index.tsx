import React, { useCallback, useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { Container, MenuItem, SortAnFilter } from "../../Components";
import { useMenuContext } from "../../Context/MenuContext";
import { setMenuItems } from "../../Context/MenuContext/menuActions";
import menuController from "../../DataProvider/Controllers/menuController";
import { IFilter } from "../../Components/SortAnFilter";

const PAGE_SIZE = 20;

const Menu: React.FC = () => {
    const { state, dispatch } = useMenuContext();
    const { branchId } = useParams<{ branchId: string }>();

    const [filter, setFilter] = useState<IFilter>({
        price: 0,
        categories: [],
        searchQuery: "",
    });

    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(false);
    const [hasMore, setHasMore] = useState(true);

    const observer = useRef<IntersectionObserver | null>(null);
    const lastElementRef = useRef<HTMLDivElement | null>(null);

    // ✅ Fetch Menu Data
    const fetchMenuData = useCallback(async (pageNumber: number, reset = false) => {
        if (!branchId || loading || (pageNumber > 1 && !hasMore)) return;

        setLoading(true);
        try {
            const response = await menuController.getMenuList(branchId, {
                page: pageNumber,
                limit: PAGE_SIZE,
                search: filter.searchQuery || undefined,
                categoryIds: filter.categories.length > 0 ? filter.categories : undefined,
            });

            if (!response.success) {
                console.error("Error fetching menu items:", response.message);
                return;
            }

            const newData = response.data?.menuItems || [];
            dispatch(
                setMenuItems({
                    menuItems: reset ? newData : [...state.menuItems, ...newData],
                    totalItems: response.data?.total || 0,
                })
            );

            setHasMore(newData.length === PAGE_SIZE);
        } catch (error) {
            console.error("Error fetching menu items:", error);
        } finally {
            setLoading(false);
        }
    }, [branchId, filter, state.menuItems, dispatch]);

    // ✅ Fetch when `page` changes
    useEffect(() => {
        if (page > 1) fetchMenuData(page);
    }, [page]);

    // ✅ Fetch when `filter` changes
    useEffect(() => {
        setPage(1); // Reset page number first
        fetchMenuData(1, true);
    }, [filter]);

    // ✅ Infinite Scrolling
    useEffect(() => {
        if (!lastElementRef.current || loading || !hasMore) return;

        const observerCallback = (entries: IntersectionObserverEntry[]) => {
            if (entries[0].isIntersecting) {
                setPage((prev) => prev + 1);
            }
        };

        observer.current = new IntersectionObserver(observerCallback, { threshold: 1.0 });
        observer.current.observe(lastElementRef.current);

        return () => observer.current?.disconnect();
    }, [loading, hasMore]);

    return (
        <Container>
            <SortAnFilter
                branchId={branchId}
                totalItems={state.totalItems || 0}
                filter={filter}
                setFilter={setFilter}
            />
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-1 py-4">
                {state.menuItems.map((food) => (
                    <MenuItem
                        key={food._id}
                        image="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Cheeseburger.jpg/640px-Cheeseburger.jpg"
                        altText={food.name}
                        name={food.name}
                        price={food.price}
                        onClick={() => console.log(`food: ${food.name}`)}
                    />
                ))}
            </div>
            <div ref={lastElementRef} style={{ height: "20px" }} />
        </Container>
    );
};

export default Menu;
