import { ICart } from "../../types";


export const setCartData = (cartItems: ICart[]) => ({
    type: 'SET_DATA',
    payload: cartItems,
});

export const updateCart = (cartItem: ICart) => ({
    type: 'UPDATE',
    payload: cartItem,
});

export const deleteCart = (cartId: string) => ({
    type: 'DELETE',
    payload: cartId,
});
