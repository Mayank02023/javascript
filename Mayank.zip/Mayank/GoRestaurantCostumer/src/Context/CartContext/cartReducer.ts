import { ICart } from "../../types";


export interface CartState {
    cartItems: ICart[];
}
type Action =
    | { type: 'SET_DATA'; payload: ICart[] }
    | { type: 'UPDATE'; payload: ICart }
    | { type: 'DELETE'; payload: string };



export const cartReducer = (state: CartState, action: Action): CartState => {
    switch (action.type) {
        case 'SET_DATA':
            return { ...state, cartItems: action.payload };
        case 'UPDATE':
            return {
                ...state,
                cartItems: state.cartItems.map((cart) =>
                    cart._id === action.payload._id ? action.payload : cart
                ),
            };
        case 'DELETE':
            return {
                ...state,
                cartItems: state.cartItems.filter(
                    (cart) => cart._id !== action.payload
                ),
            };
        default:
            return state;
    }
};
