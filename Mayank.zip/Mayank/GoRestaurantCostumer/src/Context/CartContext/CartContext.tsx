// CategoryContext.tsx
import React, { createContext, useReducer, useContext, ReactNode } from 'react';
import { cartReducer, CartState, } from './cartReducer';
import { ICart } from '../../types';


interface CartContextType {
    state: { cartItems: ICart[] };
    dispatch: React.Dispatch<any>;
}

const initialState: CartState = {
    cartItems: [],
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [state, dispatch] = useReducer(cartReducer, initialState);

    return (
        <CartContext.Provider value={{ state, dispatch }}>
            {children}
        </CartContext.Provider>
    );
};

export const useCartContext = (): CartContextType => {
    const context = useContext(CartContext);
    if (!context) {
        throw new Error('useCartContext must be used within a CartProvider');
    }
    return context;
};
