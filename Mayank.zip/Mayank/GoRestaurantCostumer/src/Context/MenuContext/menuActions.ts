import { IMenuItem } from '../../types';
import { MenuState } from '../MenuContext/menuReducer';

export const setMenuItems = (payload: MenuState) => ({
    type: 'SET_DATA',
    payload: payload,
});

export const updateMenuItem = (menuItem: IMenuItem) => ({
    type: 'UPDATE',
    payload: menuItem,
});

export const deleteMenuItem = (menuItemId: string) => ({
    type: 'DELETE',
    payload: menuItemId,
});
