// GlobalContext.tsx
import React, { ReactNode } from 'react';
import { CategoryProvider } from './CategoryContext';
import { MenuProvider } from './MenuContext';

interface GlobalContextProps {
    children: ReactNode;
}

const GlobalContext: React.FC<GlobalContextProps> = ({ children }) => {
    return (
        <CategoryProvider>
            <MenuProvider>
                {children}
            </MenuProvider>
        </CategoryProvider>
    );
};

export default GlobalContext;
