// categoryActions.ts
import { ICategory } from '../../types';

export const setCategoryData = (data: ICategory[]) => ({
  type: 'SET_CATEGORY_DATA',
  payload: data,
});

export const updateCategory = (category: ICategory) => ({
  type: 'UPDATE_CATEGORY',
  payload: category,
});

export const deleteCategory = (categoryId: string) => ({
  type: 'DELETE_CATEGORY',
  payload: categoryId,
});
