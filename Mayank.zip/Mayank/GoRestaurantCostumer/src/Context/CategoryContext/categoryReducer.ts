// categoryReducer.ts
import { ICategory } from '../../types';


type Action =
  | { type: 'SET_CATEGORY_DATA'; payload: ICategory[] }
  | { type: 'UPDATE_CATEGORY'; payload: ICategory }
  | { type: 'DELETE_CATEGORY'; payload: string };

export interface State {
  categoryData: ICategory[];
}

export const categoryReducer = (state: State, action: Action): State => {
  switch (action.type) {
    case 'SET_CATEGORY_DATA':
      return { ...state, categoryData: action.payload };
    case 'UPDATE_CATEGORY':
      return {
        ...state,
        categoryData: state.categoryData.map((category) =>
          category._id === action.payload._id ? action.payload : category
        ),
      };
    case 'DELETE_CATEGORY':
      return {
        ...state,
        categoryData: state.categoryData.filter(
          (category) => category._id !== action.payload
        ),
      };
    default:
      return state;
  }
};
