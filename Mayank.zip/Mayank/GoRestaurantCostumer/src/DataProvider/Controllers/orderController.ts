import { IOrder } from "../../types";
import { ApiResponse } from "../../Util/apiHandler";
import BaseService from "../Services/baseService";

class OrderController extends BaseService<IOrder> {

    public async createOrder(branchId: string, orderData: IOrder): Promise<ApiResponse<IOrder | null>> {
        return await this.post(`branch/${branchId}/order`, orderData);
    }

    public async getOrderItem(orderId: string): Promise<ApiResponse<IOrder | null>> {
        return await this.get(`order/${orderId}`);
    }

    public async getOrdersList(branchId: string, query: Record<string, any> = {}): Promise<ApiResponse<IOrder[] | null>> {
        return await this.getList(`order/${branchId}/menu-items`, query);
    }

    public async updateOrder(orderId: string, orderData: IOrder): Promise<ApiResponse<IOrder | null>> {
        return await this.put(`order/${orderId}`, orderData);
    }

    public async cancelOrder(orderId: string, orderData: IOrder): Promise<ApiResponse<IOrder | null>> {
        return await this.put(`order/${orderId}`, orderData);
    }
}
const orderController = new OrderController();
export default orderController;