import React, { useEffect, useState } from "react";
import QuantityControl from "./QuantityControl";

interface MenuItemProps {
    name: string;        // Unique identifier for the category
    image: string;  // Path to the image
    altText: string;   // Alternative text for the image
    price: number;     // Category title
    onClick?: () => void;  // Optional click handler
}

const MenuItem: React.FC<MenuItemProps> = ({ name, image, altText, price, onClick }) => {
    const [qty, setQty] = useState(0);
    const [isInCart, setIsInCart] = useState(false);
    useEffect(() => {
        if (qty === 0) {
            setIsInCart(false);
        }
    }, [qty, isInCart]);
    return (
        <div
            key={name}
            className="relative h-auto w-auto text-center py-2 px-0 rounded-xl shadow-lg bg-white dark:bg-gray-800"
            onClick={onClick}>
            <img src={image} alt={altText} className="h-32 w-32 mx-auto rounded-full shadow-lg" />
            <span className="block text-base font-semibold capitalize dark:text-white pt-3">{name}</span>
            <div className="price-tag flex items-center gap-2 justify-between rounded-lg p-2 mt-2">
                <span className="block text-lg font-semibold uppercase dark:text-white">₹{Math.ceil(price)}0</span>
                {/* Add to Cart Button */}
                {isInCart ? (
                    <QuantityControl qty={qty} setQty={setQty} />
                ) : (
                    <button
                        type="button"
                        onClick={() => {
                            setIsInCart(true);
                            setQty(1);
                        }}
                        className="font-serif flex items-center justify-center px-3 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:bg-blue-700 dark:hover:bg-blue-800 dark:focus:ring-blue-900"
                        aria-label="Add to cart"
                    >
                        Add to cart
                    </button>


                )}
            </div>
            {isInCart && (
                <span
                    className="absolute top-0 right-0 dark:bg-gray-600 rounded-full p-1.5"
                    onClick={() => setQty(0)}
                >
                    <svg className="w-5 h-5 text-gray-600 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18 17.94 6M18 18 6.06 6" />
                    </svg>
                </span>
            )}
        </div>
    );
};

export default MenuItem;
