import { useState, useRef, useEffect, useCallback } from "react";
import SearchBar from "./SearchBar";
import categoryController from "../DataProvider/Controllers/categoryController";
import { ICategory } from "../types";
import { setCategoryData } from "../Context/CategoryContext/categoryActions";
import { useCategoryContext } from "../Context/CategoryContext";

export interface IFilter {
    price: number;
    categories: string[];
    searchQuery: string;
}

interface ISortAnFilterProps {
    filter: IFilter;
    setFilter: (filter: IFilter) => void;
    totalItems: number;
    branchId?: string;
}


const SortAnFilter: React.FC<ISortAnFilterProps> = ({ filter, totalItems, setFilter, branchId }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const { state, dispatch } = useCategoryContext();


    const toggleDropdown = () => {
        setIsOpen((prevState) => !prevState);
    };

    const handleClickOutside = (event: MouseEvent) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
            setIsOpen(false);
        }
    };

    useEffect(() => {
        if (isOpen) {
            document.addEventListener("mousedown", handleClickOutside);
        } else {
            document.removeEventListener("mousedown", handleClickOutside);
        }

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [isOpen]);

    const loadMoreData = useCallback(async (pageNumber: number = 1) => {
        if (!branchId || loading) return;
        setLoading(true);

        try {
            const response = await categoryController.getCategoryList(branchId, {
                page: pageNumber,
                limit: 20,
                search: filter.searchQuery || undefined,
            });

            if (response.success) {
                const categories: ICategory[] = response.data || [];
                dispatch(setCategoryData(categories));
            } else {
                console.error("Error fetching category items:", response.message);
            }
        } catch (error) {
            console.error("Error fetching menu items:", error);
        }

        setLoading(false);
    }, [branchId, dispatch, loading]);

    useEffect(() => {
        loadMoreData();
    }, [branchId, dispatch]);

    const handleSelectCategory = (id: string, isSelected: boolean) => {
        setFilter({
            ...filter,
            categories: isSelected
                ? filter.categories.filter((category) => category !== id)
                : [...filter.categories, id]
        });
    };

    return (
        <div className="flex gap-2 items-center pb-1 w-full relative">
            <button
                onClick={toggleDropdown}
                type="button"
                className="w-28 inline-flex items-center py-2 px-3 text-base font-medium bg-[#ebedec] rounded-lg border border-[#ebedec] hover:bg-[#e3e3e3] focus:outline-none dark:bg-blue-600 dark:hover:bg-blue-70"
            >
                <svg className="w-5 h-5 me-0.5 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="M18.796 4H5.204a1 1 0 0 0-.753 1.659l5.302 6.058a1 1 0 0 1 .247.659v4.874a.5.5 0 0 0 .2.4l3 2.25a.5.5 0 0 0 .8-.4v-7.124a1 1 0 0 1 .247-.659l5.302-6.059c.566-.646.106-1.658-.753-1.658Z" />
                </svg>
                {`Filter(${totalItems})`}
            </button>
            {isOpen && (
                <aside ref={dropdownRef} className="absolute top-12 left-0 z-40 w-64 rounded h-auto">
                    <div className="h-full p-0.5 overflow-y-auto rounded bg-white dark:bg-gray-800">
                        <div className="p-2 border-b border-gray-200 dark:border-gray-600">
                            <div className=" flex justify-between items-center">
                                <span className="max-w-lg text-2xl font-bold leading-normal text-gray-900 dark:text-white">
                                    Categories</span>
                                {filter.categories.length > 0 && (
                                    <span
                                        className="text-sm font-normal text-blue-500 dark:text-white"
                                        onClick={() => setFilter({ ...filter, categories: [] })}
                                    >
                                        Reset
                                    </span>
                                )}
                            </div>
                            <div className="flex items-center gap-1 mt-2 flex-wrap">
                                {state.categoryData.map((category) => {
                                    const isSelected = filter.categories.includes(category._id);
                                    return (
                                        <button
                                            type="button"
                                            onClick={() => {
                                                handleSelectCategory(category._id, isSelected);
                                            }}
                                            key={category._id}
                                            className={`py-2 px-4 mb-2 text-base font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 flex-grow
                                            ${isSelected && "!bg-blue-700 !text-gray-100"}
                                            `}
                                        >
                                            {category.name}
                                        </button>
                                    )
                                })}
                            </div>
                        </div>
                    </div>
                </aside>

            )
            }
            <SearchBar handleSubmit={(searchQuery: string) => setFilter({ ...filter, searchQuery })} />
            <button
                type="submit"
                className="w-24 inline-flex items-center py-2 px-3 text-base font-medium bg-[#ebedec] rounded-lg border border-[#ebedec] hover:bg-[#e3e3e3] focus:outline-none dark:bg-blue-600 dark:hover:bg-blue-70"
            >
                <svg className="w-5 h-5 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 20V10m0 10-3-3m3 3 3-3m5-13v10m0-10 3 3m-3-3-3 3" />
                </svg>
                SortBy
            </button>
        </div >
    );
};

export default SortAnFilter;
