export interface IApiResponse<T> {
    statusCode: number;
    data: T | null;
    message: string;
    success: boolean;
}

export interface ICategory {
    _id: string;
    name: string;
    description: string;
    createdAt: string;
    updatedAt: string;
}

export interface IMenuItem {
    _id: string; // ObjectId as string
    branchId: string;
    name: string;
    description?: string;
    price: number;
    avatar?: string;
    categoryId: string;
    ingredients: string[]; // Convert ObjectId[] to string[]
    availability: boolean;
    isDeleted: boolean; // Renamed to camelCase for consistency
    createdAt: string; // Convert Date to string (ISO format)
    updatedAt: string;
}

export interface ICart {
    _id: string;
    branchId: string;
    menuItemId: string;
    quantity: number;
}

export interface IOrder {
    id: number;
    user_id: number;
    total: number;
    created_at: string;
    updated_at: string;
}
