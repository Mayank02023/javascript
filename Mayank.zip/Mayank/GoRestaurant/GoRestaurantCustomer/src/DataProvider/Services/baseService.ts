import { ApiResponse } from "../../Util/apiHandler";
import axiosInstance from "./axiosInstance";

class BaseService<T> {
    protected async get<U>(url: string, query: Record<string, unknown> | undefined = undefined): Promise<ApiResponse<T | U | null>> {
        const response = await axiosInstance.get(url,
            {
                params: query
            }
        );
        return await response.data;
    }

    protected async getList<U>(url: string, query: Record<string, unknown>): Promise<ApiResponse<U | null>> {
        const response = await axiosInstance.get(url, {
            params: query
        });
        return await response.data;
    }

    protected async post<U>(url: string, body: object): Promise<ApiResponse<U | T | null>> {
        const response = await axiosInstance.post(url, body);
        return await response.data;
    }

    protected async put(url: string, body: object): Promise<ApiResponse<T | null>> {
        const response = await axiosInstance.put(url, body);
        return await response.data;
    }
}

export default BaseService;