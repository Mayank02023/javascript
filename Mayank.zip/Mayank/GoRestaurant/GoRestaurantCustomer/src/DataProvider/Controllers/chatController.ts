import { ApiResponse } from "../../Util/apiHandler";
import BaseService from "../Services/baseService";

class ChatController extends BaseService<string> {
    public async chat(prompt: string): Promise<ApiResponse<string | null>> {
        return await this.get(`chat/`, { prompt });
    }
}

const chatController = new ChatController();
export default chatController;