import { IMenuItem } from "../../Types";
import { ApiResponse } from "../../Util/apiHandler";
import BaseService from "../Services/baseService";

class MenuController extends BaseService<IMenuItem> {

    public async getMenuItem(menuItemId: string): Promise<ApiResponse<IMenuItem | null>> {
        return await this.get(`menu-item/${menuItemId}`);
    }

    public async getMenuList(branchId: string, query: Record<string, unknown> = {}): Promise<ApiResponse<{ menuItems: IMenuItem[], total: number } | null>> {
        return await this.getList<{ menuItems: IMenuItem[], total: number }>(`branch/${branchId}/menu-items`, query);
    }
}
const menuController = new MenuController();
export default menuController;