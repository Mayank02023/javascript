import { ITable } from "../../Types";
import { ApiResponse } from "../../Util/apiHandler";
import BaseService from "../Services/baseService";

class TableController extends BaseService<ITable> {

    public async getTable(tableId: string): Promise<ApiResponse<ITable | null>> {
        return await this.get(`table/${tableId}`);
    }
}
const tableController = new TableController();
export default tableController;