import { ICategory } from "../../types";
import { ApiResponse } from "../../Util/apiHandler";
import BaseService from "../Services/baseService";

class CategoryController extends BaseService<ICategory> {

    public async getCategoryItem(categoryId: string): Promise<ApiResponse<ICategory | null>> {
        return await this.get(`menu-item-category/${categoryId}`);
    }

    public async getCategoryList(branchId: string, query: Record<string, any> = {}): Promise<ApiResponse<ICategory[] | null>> {
        return await this.getList<ICategory[]>(`branch/${branchId}/menu-item-categories`, query);
    }
}
const categoryController = new CategoryController();
export default categoryController;