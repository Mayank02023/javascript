import { IInitiatePaymentResponse, IRazorpayResponse } from "../../Types";
import { ApiResponse } from "../../Util/apiHandler";
import axiosInstance from "../Services/axiosInstance";

class PaymentController {

    public async initiatePayment(paymentData: { amount: number; currency?: string }): Promise<ApiResponse<IInitiatePaymentResponse | null>> {
        const response = await axiosInstance.post(`/payment/initiate`, paymentData);
        return response.data;
    }

    public async verifyPayment(paymentData: IRazorpayResponse): Promise<ApiResponse<boolean | null>> {
        const response = await axiosInstance.post(`/payment/verify`, paymentData);
        return response.data;
    }


}
const paymentController = new PaymentController();
export default paymentController;