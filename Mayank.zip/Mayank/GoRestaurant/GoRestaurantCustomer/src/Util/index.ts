export const getOrdersFromLocalStorage = (): string[] => {
    try {
        const storedOrders = localStorage.getItem("Orders");
        return storedOrders ? JSON.parse(storedOrders) : [];
    } catch (error) {
        console.error("Error retrieving orders from localStorage:", error);
        return []; // Return an empty array if an error occurs
    }
};


