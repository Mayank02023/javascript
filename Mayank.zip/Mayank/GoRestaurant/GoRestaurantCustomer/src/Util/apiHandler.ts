export interface ApiResponse<T> {
    statusCode: number;
    data: T | null;
    message: string;
    success: boolean;
}

export const handleApiResponse = <T>(response: ApiResponse<T>) => {
    if (response.success) {
        // Success case
        return {
            data: response.data,
            message: response.message,
            statusCode: response.statusCode,
        };
    } else {
        // Error case
        console.error(`API Error: ${response.message}`);
        return {
            error: true,
            message: response.message,
            statusCode: response.statusCode,
            data: response.data,
        };
    }
};