import { ITable } from "../Types";

export const checkTableAvailable = (table: ITable) => {
    return table.capacity > table.occupiedSeats;

}