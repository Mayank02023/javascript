/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useReducer, useContext, ReactNode, useEffect, useRef } from 'react';
import { cartReducer, CartState } from './cartReducer';
import { ICart } from '../../Types';

interface CartContextType {
    cartState: { cartItems: ICart[] };
    dispatch: React.Dispatch<any>;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const initialState: CartState = {
    cartItems: [],
};

export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [cartState, dispatch] = useReducer(cartReducer, initialState);
    const isFirstRender = useRef(true);

    //Sync cart state with localStorage whenever it changes
    useEffect(() => {
        if (isFirstRender.current) {
            isFirstRender.current = false;
            return;
        }
        localStorage.setItem("Cart", JSON.stringify(cartState.cartItems));
    }, [cartState.cartItems]);

    return (
        <CartContext.Provider value={{ cartState, dispatch }}>
            {children}
        </CartContext.Provider>
    );
};

export const useCartContext = (): CartContextType => {
    const context = useContext(CartContext);
    if (!context) {
        throw new Error('useCartContext must be used within a CartProvider');
    }
    return context;
};
