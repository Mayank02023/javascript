// index.ts
export { CartProvider, useCartContext } from './CartContext';
