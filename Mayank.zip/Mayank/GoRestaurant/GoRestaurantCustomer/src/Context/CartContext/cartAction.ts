import { ICart } from '../../Types';


export const setCartData = (cartItems: ICart[]) => ({
    type: 'SET_DATA',
    payload: cartItems,
});

export const setCart = (cartItem: ICart) => ({
    type: 'INSERT_DATA',
    payload: cartItem,
});

export const updateCart = (cartItem: ICart) => ({
    type: 'UPDATE',
    payload: cartItem,
});

export const deleteCart = (cartId: string) => ({
    type: 'DELETE',
    payload: cartId,
});
