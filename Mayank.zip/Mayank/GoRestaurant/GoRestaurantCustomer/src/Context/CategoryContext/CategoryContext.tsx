// CategoryContext.tsx
import React, { createContext, useReducer, useContext, ReactNode } from 'react';
import { categoryReducer, State, } from './categoryReducer';
import { ICategory } from '../../Types';


interface CategoryContextType {
    state: { categoryData: ICategory[] };
    dispatch: React.Dispatch<any>;
}

const initialState: State = {
    categoryData: [],
};

const CategoryContext = createContext<CategoryContextType | undefined>(undefined);

export const CategoryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [state, dispatch] = useReducer(categoryReducer, initialState);

    return (
        <CategoryContext.Provider value={{ state, dispatch }}>
            {children}
        </CategoryContext.Provider>
    );
};

export const useCategoryContext = (): CategoryContextType => {
    const context = useContext(CategoryContext);
    if (!context) {
        throw new Error('useCategoryContext must be used within a CategoryProvider');
    }
    return context;
};
