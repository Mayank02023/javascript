// index.ts
export { CategoryProvider, useCategoryContext } from './CategoryContext';
