// orderReducer.ts
import { IOrder, IOrderRequest } from "../../Types";

// Define the shape of our order state
export interface OrderState {
    order: IOrderRequest;
    myOrders: { orders: IOrder[]; total: number };
}

// Provide a default order (current order) state
export const defaultOrder: IOrderRequest = {
    customerName: "",
    branchId: "",
    tableId: "",
    person: 0,
    items: [],
    totalAmount: 0,
    cashfreeOrderId: "",
    cashfreeToken: "",
    paymentMethod: "ONLINE",
    status: "PENDING",
    orderType: "DINE_IN",
    paymentStatus: "INITIATED",
    staffId: undefined,
};

// Define the default state for the reducer
export const defaultOrderState: OrderState = {
    order: defaultOrder,
    myOrders: { orders: [], total: 0 },
};

// Define our action types
export type OrderAction =
    | { type: "SET_ORDER"; payload: IOrderRequest }
    | { type: "UPDATE_ORDER_FIELD"; payload: { field: keyof IOrderRequest; value: string | number | boolean | undefined } }
    | { type: "CLEAR_ORDER" }
    | { type: "SAVE_CURRENT_ORDER" } // Append current order to myOrders
    | { type: "SET_MYORDERS"; payload: { orders: IOrder[]; total: number } };

export const orderReducer = (state: OrderState, action: OrderAction): OrderState => {
    switch (action.type) {
        case "SET_ORDER":
            return { ...state, order: action.payload };
        case "UPDATE_ORDER_FIELD":
            return {
                ...state,
                order: { ...state.order, [action.payload.field]: action.payload.value },
            };
        case "CLEAR_ORDER":
            return { ...state, order: defaultOrder };
        case "SET_MYORDERS":
            return { ...state, myOrders: { orders: action.payload.orders, total: action.payload.total } };
        default:
            return state;
    }
};
