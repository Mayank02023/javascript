// orderActions.ts
import { IOrder, IOrderRequest } from "../../Types";
import { OrderAction } from "./orderReducer";

export const setOrder = (order: IOrderRequest): OrderAction => ({
    type: "SET_ORDER",
    payload: order,
});

export const updateOrderField = (
    field: keyof IOrderRequest,
    value: string | number | boolean | undefined
): OrderAction => ({
    type: "UPDATE_ORDER_FIELD",
    payload: { field, value },
});


export const clearOrder = (): OrderAction => ({
    type: "CLEAR_ORDER",
});

export const saveCurrentOrder = (): OrderAction => ({
    type: "SAVE_CURRENT_ORDER",
});

export const setMyOrders = (payload: { orders: IOrder[]; total: number }): OrderAction => ({
    type: "SET_MYORDERS",
    payload: payload,
});
