// orderContext.tsx
import React, { createContext, useContext, useReducer, ReactNode } from "react";
import { orderReducer, defaultOrderState, OrderState, OrderAction } from "./orderReducer";

interface OrderContextProps extends OrderState {
  orderDispatch: React.Dispatch<OrderAction>;
}

const OrderContext = createContext<OrderContextProps | undefined>(undefined);

export const OrderProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, orderDispatch] = useReducer(orderReducer, defaultOrderState);

  return (
    <OrderContext.Provider value={{ order: state.order, myOrders: state.myOrders, orderDispatch }}>
      {children}
    </OrderContext.Provider>
  );
};

// Custom hook to use the OrderContext
export const useOrderContext = (): OrderContextProps => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error("useOrderContext must be used within an OrderProvider");
  }
  return context;
};
