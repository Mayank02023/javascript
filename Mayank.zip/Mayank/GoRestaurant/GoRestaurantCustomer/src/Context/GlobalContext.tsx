// GlobalContext.tsx
import React, { ReactNode } from 'react';
import { CategoryProvider } from './CategoryContext';
import { MenuProvider } from './MenuContext';
import { CartProvider } from './CartContext';
import { OrderProvider } from './OrderContext';

interface GlobalContextProps {
    children: ReactNode;
}

const GlobalContext: React.FC<GlobalContextProps> = ({ children }) => {
    return (
        <CategoryProvider>
            <MenuProvider>
                <CartProvider>
                    <OrderProvider>
                        {children}
                    </OrderProvider>
                </CartProvider>
            </MenuProvider>
        </CategoryProvider>
    );
};

export default GlobalContext;
