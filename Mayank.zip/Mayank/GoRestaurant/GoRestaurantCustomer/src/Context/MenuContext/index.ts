// index.ts
export { MenuProvider, useMenuContext } from './MenuContext';
