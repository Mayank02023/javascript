import { IMenuItem } from '../../Types';

export interface MenuState {
    menuItems: IMenuItem[];
    totalItems?: number;
}
type Action =
    | { type: 'SET_DATA'; payload: MenuState }
    | { type: 'UPDATE'; payload: IMenuItem }
    | { type: 'DELETE'; payload: string };



export const menuReducer = (state: MenuState, action: Action): MenuState => {
    switch (action.type) {
        case 'SET_DATA':
            return { ...state, menuItems: action.payload.menuItems, totalItems: action.payload.totalItems };
        case 'UPDATE':
            return {
                ...state,
                menuItems: state.menuItems.map((menuItem) =>
                    menuItem._id === action.payload._id ? action.payload : menuItem
                ),
            };
        case 'DELETE':
            return {
                ...state,
                menuItems: state.menuItems.filter(
                    (menuItem) => menuItem._id !== action.payload
                ),
                totalItems: state.totalItems ? state.totalItems - 1 : 0,
            };
        default:
            return state;
    }
};
