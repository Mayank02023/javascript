import React, { createContext, useReducer, useContext, ReactNode } from 'react';
import { menuReducer, MenuState, } from './menuReducer';


interface MenuContextType {
    state: MenuState;
    dispatch: React.Dispatch<any>;
}

const initialState: MenuState = {
    menuItems: [],
    totalItems: 0,
};

const MenuContext = createContext<MenuContextType | undefined>(undefined);

export const MenuProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [state, dispatch] = useReducer(menuReducer, initialState);

    return (
        <MenuContext.Provider value={{ state, dispatch }}>
            {children}
        </MenuContext.Provider>
    );
};

export const useMenuContext = (): MenuContextType => {
    const context = useContext(MenuContext);
    if (!context) {
        throw new Error('useMenuContext must be used within a MenuProvider.');
    }
    return context;
};
