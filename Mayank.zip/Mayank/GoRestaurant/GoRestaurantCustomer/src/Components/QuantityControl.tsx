import React from "react";

interface QuantityControlProps {
    qty: number;
    onIncrease: () => void;
    onDecrease: () => void;
}

const QuantityControl: React.FC<QuantityControlProps> = ({ qty, onIncrease, onDecrease }) => {
    return (
        <div className="flex items-center gap-2 justify-between rounded-lg bg-gray-100 dark:bg-gray-800">
            {/* Decrement Button */}
            <button
                type="button"
                onClick={onDecrease}
                className="text-white bg-blue-700 focus:outline-none font-medium rounded-lg text-sm p-1.5 flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                aria-label="Decrease quantity"
            >
                <svg className="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h14" />
                </svg>
            </button>

            {/* Quantity Display */}
            <span className="min-w-7 text-base text-center font-semibold text-gray-800 dark:text-gray-200">{qty}</span>

            {/* Increment Button */}
            <button
                type="button"
                onClick={onIncrease}
                className="text-white bg-blue-700 focus:outline-none font-medium rounded-lg text-sm p-1.5 py-2 flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                aria-label="Increase quantity"
            >
                <svg className="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h14m-7 7V5" />
                </svg>
            </button>
        </div>
    );
};

export default QuantityControl;
