import React, { useEffect } from "react";
import { IPaymentMethod } from "../Types";
import { useNavigate } from "react-router-dom";

export interface IOrderPlaced {
    orderId: string;
    paymentMethod: IPaymentMethod;
    paymentId?: string;
}

interface IOrderPlacedProps {
    placedOrder: IOrderPlaced
}

const OrderPlaced: React.FC<IOrderPlacedProps> = ({ placedOrder }) => {
    const { orderId, paymentMethod, paymentId } = placedOrder;
    const navigate = useNavigate();

    useEffect(() => {
        const timer = setTimeout(() => {
            navigate("/my-orders");
        }, paymentMethod === "ONLINE" ? 10000 : 5000);
        return () => clearTimeout(timer);
    }, [navigate]);

    return (
        <div className="fixed inset-0 z-50 flex justify-center items-center bg-gray-800 bg-opacity-50">
            <div className="relative px-6 py-4 w-full max-w-md bg-white rounded-lg shadow-lg dark:bg-gray-700">
                {/* Header */}
                <div className="flex items-center justify-center py-2 border-b dark:border-gray-600">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                        🎉 Order Placed Successfully!
                    </h3>
                </div>

                {/* Order Details */}
                <div className="mt-4 text-gray-800 dark:text-gray-300">
                    <p className="text-sm">
                        Thank you for your purchase! Your order has been successfully placed.
                    </p>
                    <div className="mt-3 space-y-2">
                        <p><strong>Order ID:</strong> {orderId}</p>
                        <p><strong>Payment Method:</strong> {paymentMethod}</p>
                        {paymentId && <p><strong>Payment ID:</strong> {paymentId}</p>}
                    </div>
                    <p className="text-xs text-gray-500 mt-3">Redirecting to My Orders in 5 seconds...</p>
                </div>

                {/* Close Button */}
                <div className="mt-4 flex justify-end">
                    <button
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                        onClick={() => navigate("/my-orders")}
                    >
                        Go to My Orders
                    </button>
                </div>
            </div>
        </div>
    );
};

export default OrderPlaced;
