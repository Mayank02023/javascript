import { FoodRegular } from "@fluentui/react-icons";
import React, { FC, useState, useEffect } from "react";

interface SearchBarProps {
    handleSubmit: (searchQuery: string) => void;
}

const SearchBar: FC<SearchBarProps> = ({ handleSubmit }) => {
    const [searchQuery, setSearchQuery] = useState("");
    const [debouncedQuery, setDebouncedQuery] = useState(searchQuery);

    // Debounce the search query
    useEffect(() => {
        const timeoutId = setTimeout(() => {
            setDebouncedQuery(searchQuery);
        }, 500);
        return () => clearTimeout(timeoutId);
    }, [searchQuery]);

    useEffect(() => {
        if (debouncedQuery) {
            handleSubmit(debouncedQuery);
        }
    }, [debouncedQuery]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchQuery(e.target.value);
    };

    return (
        <form
            className="flex items-center max-w-lg mx-auto"
            style={{ width: "-webkit-fill-available" }}
            onSubmit={(e) => e.preventDefault()} // Prevent form submit
        >
            <div className="relative w-full">
                <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                    <FoodRegular fontSize={21} />
                </div>
                <input
                    type="text"
                    id="search"
                    value={searchQuery}
                    onChange={handleInputChange}
                    className="bg-gray-50 border outline-none border-gray-300 text-gray-900 text-sm rounded-lg block w-full ps-10 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Search Food..."
                    required
                />
            </div>
        </form>
    );
};

export default SearchBar;
