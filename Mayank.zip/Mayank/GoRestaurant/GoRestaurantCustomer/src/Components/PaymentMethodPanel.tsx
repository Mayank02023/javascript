// PaymentMethodPanel.tsx
import React from "react";
import { useOrderContext } from "../Context/OrderContext";
import { updateOrderField } from "../Context/OrderContext/orderActions";
import { IPaymentMethod } from "../Types";

interface PaymentMethodPanelProps {
    isOpen: boolean;
    toggle: () => void;
}

const PaymentMethodPanel: React.FC<PaymentMethodPanelProps> = ({
    isOpen,
    toggle,
}) => {
    const { order, orderDispatch } = useOrderContext();
    const handlePaymentMethod = (method: IPaymentMethod) => {
        orderDispatch(updateOrderField("paymentMethod", method))
    }
    return (
        <div className="PaymentMethod bg-white rounded-lg shadow-lg p-2 w-full mt-2">
            <div className="flex justify-between items-center w-full" onClick={toggle}>
                <span className="text-base font-medium mb-2 flex gap-2 items-center">
                    <svg
                        className="w-6 h-6 dark:text-white"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        fill="none"
                        viewBox="0 0 24 24"
                    >
                        {/* Payment method icon SVG */}
                        <path
                            d="M17 8H5m12 0a1 1 0 0 1 1 1v2.6M17 8l-4-4M5 8a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.6M5 8l4-4 4 4m6 4h-4a2 2 0 1 0 0 4h4a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1Z"
                            stroke="currentColor"
                            strokeLinecap="round"
                            strokeWidth="2"
                        />
                    </svg>
                    Payment Method
                </span>
                <span>
                    {!isOpen ? (
                        <svg
                            className="w-4 h-4 text-gray-800 dark:text-white"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            fill="none"
                            viewBox="0 0 24 24"
                        >
                            <path d="m9 5 7 7-7 7" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                        </svg>
                    ) : (
                        <svg
                            className="w-4 h-4 text-gray-800 dark:text-white"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            fill="none"
                            viewBox="0 0 24 24"
                        >
                            <path d="m19 9-7 7-7-7" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                        </svg>
                    )}
                </span>
            </div>
            {isOpen && (
                <div className="mt-2 text-gray-700 flex flex-col gap-3">
                    <PaymentMethodOption
                        label="Online"
                        value="ONLINE"
                        chosenMethod={order.paymentMethod}
                        onSelect={() => handlePaymentMethod("ONLINE")}
                        icon={
                            <svg
                                className="w-5 h-5 text-gray-800 dark:text-white"
                                aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="none"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    d="M3 10h18M6 14h2m3 0h5M3 7v10a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1Z"
                                    stroke="currentColor"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth="2"
                                />
                            </svg>
                        }
                    />
                    <PaymentMethodOption
                        label="Cash on Delivery"
                        value="CASH"
                        chosenMethod={order.paymentMethod}
                        onSelect={() => handlePaymentMethod("CASH")}
                        icon={
                            <svg
                                className="w-5 h-5 text-gray-800 dark:text-white"
                                aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="none"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    d="M8 7V6a1 1 0 0 1 1-1h11a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1h-1M3 18v-7a1 1 0 0 1 1-1h11a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1Zm8-3.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Z"
                                    stroke="currentColor"
                                    strokeLinecap="round"
                                    strokeWidth="2"
                                />
                            </svg>
                        }
                    />
                </div>
            )}
        </div>
    );
};

interface PaymentMethodOptionProps {
    label: string;
    value: string;
    chosenMethod: string;
    onSelect: () => void;
    icon: React.ReactNode;
}

const PaymentMethodOption: React.FC<PaymentMethodOptionProps> = ({
    label,
    value,
    chosenMethod,
    onSelect,
    icon,
}) => {
    return (
        <div className="flex justify-between cursor-pointer" onClick={onSelect}>
            <span className="flex gap-1 items-center">
                {icon}
                {label}:
            </span>
            <input
                type="radio"
                name="paymentMethod"
                value={value}
                checked={chosenMethod === value}
                onChange={onSelect}
                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 dark:ring-offset-gray-800 dark:bg-gray-700 dark:border-gray-600"
            />
        </div>
    );
};

export default PaymentMethodPanel;
