import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

interface IAuthLayout {
    children: React.ReactNode;
    authentication: boolean;
}
const AuthLayout: React.FC<IAuthLayout> = ({ children, authentication }) => {
    const authStatus: boolean = true;
    const [loader, setLoader] = useState<boolean>(true);
    const navigate = useNavigate();

    useEffect(() => {
        if (authStatus !== authentication) {
            navigate(authentication ? "/login" : "/");
        }
        setLoader(false);
    }, [navigate, authentication, authStatus]);

    return loader ? <h1 children="Loading..." /> : <>{children}</>;

}

export default AuthLayout;