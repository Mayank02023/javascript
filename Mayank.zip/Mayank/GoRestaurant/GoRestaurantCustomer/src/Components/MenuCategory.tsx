import React from "react";

interface MenuCategoryProps {
    categoryId: string;        // Unique identifier for the category
    imageSrc: string;  // Path to the image
    altText: string;   // Alternative text for the image
    title: string;     // Category title
    onClick?: () => void;  // Optional click handler
}

const MenuCategory: React.FC<MenuCategoryProps> = ({ categoryId, imageSrc, altText, title, onClick }) => {
    return (
        <div
            key={categoryId}
            className="h-auto w-auto text-center py-2 px-0 rounded-xl shadow-lg bg-white dark:bg-gray-800"
            onClick={onClick}>
            <img src={imageSrc} alt={altText} className="h-14 w-14 mx-auto" />
            <span className="text-sm font-semibold uppercase dark:text-white">{title}</span>
        </div>
    );
};

export default MenuCategory;
