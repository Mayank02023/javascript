// PaymentSummaryPanel.tsx
import React from "react";
import { Hr } from "../Components";

interface PaymentSummaryPanelProps {
  isOpen: boolean;
  toggle: () => void;
  orderTotal: number;
  discount: number;
  taxs: number;
  totalPrice: number;
}

const PaymentSummaryPanel: React.FC<PaymentSummaryPanelProps> = ({
  isOpen,
  toggle,
  orderTotal,
  discount,
  taxs,
  totalPrice,
}) => {
  return (
    <div className="PaymentSummary bg-white rounded-lg shadow-lg p-2 w-full mt-2">
      <div className="flex justify-between items-center w-full" onClick={toggle}>
        <h2 className="text-base font-semibold mb-2">Payment Summary</h2>
        <span>
          {!isOpen ? (
            <svg
              className="w-4 h-4 text-gray-800 dark:text-white"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              fill="none"
              viewBox="0 0 24 24"
            >
              {/* Down arrow SVG */}
              <path d="m9 5 7 7-7 7" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          ) : (
            <svg
              className="w-4 h-4 text-gray-800 dark:text-white"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              fill="none"
              viewBox="0 0 24 24"
            >
              {/* Up arrow SVG */}
              <path d="m19 9-7 7-7-7" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          )}
        </span>
      </div>
      {isOpen && (
        <div className="mt-2 text-gray-700 flex flex-col gap-1">
          <div className="flex justify-between">
            <span>Total Price:</span>
            <span>₹{orderTotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>All Texs:</span>
            <span>₹{taxs.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>Discount:</span>
            <span>- ₹{discount.toFixed(2)}</span>
          </div>
        </div>
      )}
      <Hr />
      <div className="flex justify-between">
        <span className="text-gray-700 font-medium">Total Amount:</span>
        <span className="font-semibold">₹{totalPrice.toFixed(2)}</span>
      </div>
    </div>
  );
};

export default PaymentSummaryPanel;
