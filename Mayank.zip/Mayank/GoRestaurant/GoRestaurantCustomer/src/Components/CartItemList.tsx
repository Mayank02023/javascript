// CartItemList.tsx
import React from "react";
import { ICart } from "../Types";
import { QuantityControl } from "../Components";

interface CartItemListProps {
    cartItems: ICart[];
    removeItem: (item: ICart) => void;
    updateQuantity: (id: string, action: "INCREASE" | "DECREASE") => void;
}

const CartItemList: React.FC<CartItemListProps> = ({ cartItems, removeItem, updateQuantity }) => {
    return (
        <div
            className="CartItem bg-white rounded-lg shadow-lg p-2 w-full overflow-y-auto"
            style={{ maxHeight: "calc(100vh - 350px)" }}
        >
            {cartItems.map((item: ICart) => {
                const { _id, name, price, description } = item.menuItem;
                return (
                    <div
                        key={_id}
                        className="flex justify-between gap-3 items-center border-b pb-2 mb-2 relative"
                    >
                        <img
                            src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Cheeseburger.jpg/640px-Cheeseburger.jpg"
                            alt={name}
                            className="h-20 w-20 mx-auto rounded-md shadow-lg"
                        />
                        <div className="flex-1">
                            <p className="text-lg font-medium">{name}</p>
                            <p className="text-sm text-gray-500">{description}</p>
                        </div>
                        <div className="flex flex-col items-end justify-between gap-2 w-[108px]">
                            <p className="text-lg font-medium">₹{price}</p>
                            <QuantityControl
                                qty={item.quantity}
                                onIncrease={() => updateQuantity(item._id, "INCREASE")}
                                onDecrease={() => updateQuantity(item._id, "DECREASE")}
                            />
                        </div>
                        <span
                            className="absolute top-[-13px] left-[-13px] dark:bg-gray-600 rounded-full p-1.5 cursor-pointer"
                            onClick={() => removeItem(item)}
                        >
                            <svg
                                className="w-5 h-5 text-gray-600 dark:text-white"
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="none"
                                viewBox="0 0 24 24"
                            >
                                {/* SVG Path */}
                                <path d="M6 18 17.94 6M18 18 6.06 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                            </svg>
                        </span>
                    </div>
                );
            })}
        </div>
    );
};

export default CartItemList;
