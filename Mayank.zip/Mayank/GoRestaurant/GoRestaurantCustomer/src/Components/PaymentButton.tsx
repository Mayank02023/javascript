// PaymentButton.tsx
import React, { useState } from "react";
import AdditionlOrderInfo from "./AdditionlOrderInfo";
import { useOrderContext } from "../Context/OrderContext";

interface PaymentButtonProps {
    orderTotal: number;
    handlePlaceOrder: () => void;
}


const PaymentButton: React.FC<PaymentButtonProps> = ({ orderTotal, handlePlaceOrder }) => {
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const { order } = useOrderContext();

    return (
        <>
            <div className="PaymentButton fixed bottom-0 bg-white rounded-ss-lg rounded-se-lg shadow-lg p-2 w-full max-w-xl mt-2">
                <div className="flex justify-between items-center w-full">
                    <div className="flex justify-between flex-col">
                        <span className="text-gray-700">Total Amount:</span>
                        <span className="font-semibold">₹{orderTotal.toFixed(2)}</span>
                    </div>
                    <button
                        type="button"
                        disabled={!order.paymentMethod}
                        className="text-white bg-[#337bff] hover:bg-blue-800 disabled:bg-gray-300 disabled:text-black focus:outline-none font-medium rounded-full text-sm px-5 py-2.5"
                        onClick={() => setIsOpen(true)}
                    >
                        proceed
                    </button>
                </div>
            </div>
            {isOpen && <AdditionlOrderInfo
                isOpen={isOpen}
                closeModal={() => setIsOpen(false)}
                handlePlaceOrder={() => {
                    handlePlaceOrder();
                    setIsOpen(false)
                }}
            />
            }
        </>
    );
};

export default PaymentButton;
