import React from "react";

const Hr:React.FC<{className?: any}> = ({className}) => {
    return (
        <hr className={`border-t border-gray-300 my-2 ${className && className}`} />
    )
};

export default Hr;