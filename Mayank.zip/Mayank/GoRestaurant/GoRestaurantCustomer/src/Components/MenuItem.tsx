import React from "react";
import QuantityControl from "./QuantityControl";
import { useCartContext } from "../Context/CartContext";
import { deleteCart, setCart, updateCart } from "../Context/CartContext/cartAction";
import { ICart, IMenuItem } from "../Types";
import { v4 as uuidv4 } from "uuid";

interface MenuItemProps {
    menuItem: IMenuItem;
    onClick?: () => void;
}

const MenuItem: React.FC<MenuItemProps> = ({ menuItem }) => {
    const { _id: id, name, price } = menuItem;
    const { cartState, dispatch } = useCartContext();

    // Find cart item from global cartState
    const cartItem = cartState.cartItems.find(cart => cart.menuItem._id === id);

    const addItemToCart = () => {
        const cart: ICart = {
            _id: uuidv4(),
            menuItem,
            quantity: 1
        };
        dispatch(setCart(cart));
    };

    const removeItemFromCart = () => {
        if (cartItem) {
            dispatch(deleteCart(cartItem._id));
        }
    };

    const updateQuantity = (action: "INCREASE" | "DECREASE") => {
        if (!cartItem) return;

        const newQuantity = action === "INCREASE" ? cartItem.quantity + 1 : cartItem.quantity - 1;

        if (newQuantity <= 0) {
            removeItemFromCart();
        } else {
            dispatch(updateCart({ ...cartItem, quantity: newQuantity }));
        }
    };

    return (
        <div className="relative h-auto w-auto text-center py-2 px-0 rounded-xl shadow-lg bg-white dark:bg-gray-800">
            <img
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Cheeseburger.jpg/640px-Cheeseburger.jpg"
                alt={name}
                className="h-32 w-32 mx-auto rounded-full shadow-lg"
            />
            <span className="block text-base font-semibold capitalize dark:text-white pt-3">{name}</span>
            <div className="price-tag flex items-center gap-2 justify-between rounded-lg p-2 mt-2">
                <span className="block text-lg font-semibold uppercase dark:text-white">₹{Math.ceil(price)}0</span>

                {cartItem ? (
                    <QuantityControl
                        qty={cartItem.quantity}
                        onIncrease={() => updateQuantity("INCREASE")}
                        onDecrease={() => updateQuantity("DECREASE")}
                    />
                ) : (
                    <button
                        type="button"
                        onClick={addItemToCart}
                        className="font-serif flex items-center justify-center px-3 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:bg-blue-700 dark:hover:bg-blue-800 dark:focus:ring-blue-900"
                        aria-label="Add to cart"
                    >
                        Add to cart
                    </button>
                )}
            </div>

            {cartItem && (
                <span
                    className="absolute top-0 right-0 dark:bg-gray-600 rounded-full p-1.5 cursor-pointer"
                    onClick={removeItemFromCart}
                >
                    <svg className="w-5 h-5 text-gray-600 dark:text-white" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18 17.94 6M18 18 6.06 6" />
                    </svg>
                </span>
            )}
        </div>
    );
};

export default MenuItem;
