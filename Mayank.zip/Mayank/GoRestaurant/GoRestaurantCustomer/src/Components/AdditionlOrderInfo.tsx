import { useEffect, useState } from "react";
import { useOrderContext } from "../Context/OrderContext";
import { updateOrderField } from "../Context/OrderContext/orderActions";
import tableController from "../DataProvider/Controllers/tableController";
import { IOrderRequest, ITable } from "../Types";

interface IAdditionlOrderInfoProps {
    isOpen: boolean;
    closeModal(): void;
    handlePlaceOrder(): void;
}

const AdditionlOrderInfo: React.FC<IAdditionlOrderInfoProps> = ({ isOpen, closeModal, handlePlaceOrder }) => {
    const { order, orderDispatch } = useOrderContext();
    const [table, setTable] = useState<ITable | null>(null);
    const [loading, setLoading] = useState(true);
    const [errorMessage, setErrorMessage] = useState<{ customerName: string; person: string }>({
        customerName: "",
        person: "",
    });

    useEffect(() => {
        if (!order.tableId) return;

        const loadTable = async () => {
            setLoading(true);
            const response = await tableController.getTable(order.tableId);
            if (response.success && response.data) {
                setTable(response.data);
                if (response.data.occupiedSeats === response.data.capacity) {
                    setErrorMessage(prev => ({ ...prev, person: "This table is fully occupied, please select another table." }));
                }
            }
            setLoading(false);
        };

        loadTable();
    }, []);

    useEffect(() => {
        setErrorMessage(prev => ({
            ...prev,
            customerName: order.customerName ? "" : "customer name is required.",
            person: order.person <= 0 ? "Occupied seats must be greater than zero." : "",
        }));
    }, [order.customerName, order.person]);

    const handleChange = <K extends keyof IOrderRequest>(field: K, value: string | number | boolean | undefined) => {
        orderDispatch(updateOrderField(field, value));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        handlePlaceOrder();
    };

    return isOpen ? (
        <div className="fixed inset-0 z-50 flex justify-center items-center bg-gray-800 bg-opacity-50">
            <div className="relative px-4 py-2 w-full max-w-md bg-white rounded-lg shadow dark:bg-gray-700">
                <div className="flex items-center justify-between py-2 border-b dark:border-gray-600">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Additional Info</h3>
                    <button onClick={closeModal} className="text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg w-8 h-8">
                        &times;
                    </button>
                </div>

                {loading ? (
                    <div className="animate-pulse space-y-4 p-4">
                        {[...Array(3)].map((_, i) => (
                            <div key={i} className="h-4 bg-gray-300 rounded w-3/4"></div>
                        ))}
                    </div>
                ) : (
                    <form className="py-2" onSubmit={handleSubmit}>
                        <div className="grid gap-4 mb-4 grid-cols-2">
                            <div className="col-span-2">
                                <label className="block text-sm font-medium">Customer Name</label>
                                <input
                                    type="text"
                                    value={order.customerName}
                                    onChange={(e) => handleChange("customerName", e.target.value)}
                                    className={`w-full p-2 border rounded-lg ${errorMessage.customerName ? "border-red-500" : ""}`}
                                    placeholder="Enter customer name"
                                    required
                                />
                                {errorMessage.customerName && <p className="text-red-500 text-sm">{errorMessage.customerName}</p>}
                            </div>

                            <div className="col-span-2 sm:col-span-1">
                                <label className="block text-sm font-medium">Occupied Seats</label>
                                <select
                                    value={order.person}
                                    onChange={(e) => handleChange("person", Number(e.target.value))}
                                    className={`w-full p-2 border rounded-lg ${errorMessage.person ? "border-red-500" : ""}`}
                                >
                                    {[...Array((table?.capacity || 1) - (table?.occupiedSeats || 0) + 1)].map((_, index) => (
                                        <option key={index} value={index}>{index}</option>
                                    ))}
                                </select>
                                {errorMessage.person && <p className="text-red-500 text-sm">{errorMessage.person}</p>}
                            </div>

                            <div className="col-span-2 sm:col-span-1">
                                <label className="block text-sm font-medium">Order Type</label>
                                <select
                                    value={order.orderType}
                                    onChange={(e) => handleChange("orderType", e.target.value as "DINE_IN" | "TAKEAWAY")}
                                    className="w-full p-2 border rounded-lg"
                                >
                                    <option value="DINE_IN">DINE IN</option>
                                    <option value="TAKEAWAY">TAKE AWAY</option>
                                </select>
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={errorMessage.customerName !== "" || errorMessage.person !== "" || !order.orderType}
                            className="w-full bg-blue-700 hover:bg-blue-800 disabled:bg-gray-300 text-white p-2.5 rounded-lg"
                        >
                            Place Order
                        </button>
                    </form>
                )}
            </div>
        </div>
    ) : null;
};

export default AdditionlOrderInfo;
