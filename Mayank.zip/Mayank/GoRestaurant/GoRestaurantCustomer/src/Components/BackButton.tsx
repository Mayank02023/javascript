// BackButton.tsx
import React from "react";

interface BackButtonProps {
  navigate: (to: number) => void;
}

const BackButton: React.FC<BackButtonProps> = ({ navigate }) => (
  <button
    type="button"
    onClick={() => navigate(-1)}
    className="BackButton text-blue-600 font-medium text-sm text-center inline-flex items-center"
  >
    <svg
      className="w-6 h-6 dark:text-white"
      aria-hidden="true"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      fill="none"
      viewBox="0 0 24 24"
    >
      {/* SVG Path */}
      <path d="M5 12h14M5 12l4-4m-4 4 4 4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
    </svg>
    Back
  </button>
);

export default BackButton;
