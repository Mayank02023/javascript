import { FluentProvider, Spinner, webLightTheme } from '@fluentui/react-components';
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { Navbar } from './Components';
import { useState } from 'react';
import { QRScanner, Menu, OrderSummary, PlacedOrders } from './Pages';
import ChatMessageBox from './Pages/ChatMessageBox';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Navbar />, // Navbar wraps all routes
    children: [
      {
        path: '',
        element: <QRScanner />,
      },
      {
        path: ':branchId/:tableId/menu', // Remove leading `/`
        element: <Menu />,
      },
      {
        path: ':branchId/:tableId/order-summery',
        element: <OrderSummary />
      },
      {
        path: '/my-orders',
        element: <PlacedOrders />
      },
      {
        path: 'chat', // Remove trailing `/`
        element: <ChatMessageBox />
      },
      {
        path: '*', // Catch-all for 404
        element: <QRScanner />,
      },
    ]
  }
]);

export default function App() {
  const [loading] = useState(false);

  return (
    <FluentProvider theme={webLightTheme}>
      {!loading ? <RouterProvider router={router} /> : <Spinner />}
    </FluentProvider>
  );
}
