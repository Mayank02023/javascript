import { ITableHeader } from "../Components/Table/Interface";

export const workerHeader: ITableHeader[] = [
    {
        key: "displayName",
        title: "Name",
        isSearch: true
    },
    {
        key: "phoneNumber",
        title: "Phone No."
    },
    {
        key: "shiftId",
        title: "Shift"
    },
    {
        key: "roleId",
        title: "Role"
    },
    {
        key: "isLoggedIn",
        title: "Is LoggedIn"
    },
    {
        key: "action",
        title: "Action",
        isFilter: false,
        isSort: false
    },
];

export const roleOrShiftHeader: ITableHeader[] = [
    {
        key: "id",
        title: "Data Id",
    },
    {
        key: "displayName",
        title: "Name",
        isSearch: true
    },
    {
        key: "status",
        title: "Status",
        options: [
            {
                value: true,
                text: "Available"
            },
            {
                value: false,
                text: "Unavailable"
            },

        ]
    },
    {
        key: "action",
        title: "Action",
        isFilter: false,
        isSort: false
    },
];

export const productHeader: ITableHeader[] = [
    {
        key: "displayName",
        title: "Title",
        isSearch: true
    },
    {
        key: "category",
        title: "Category",
        isSearch: true
    },
    {
        key: "description",
        title: "Description"
    },
    {
        key: "price",
        title: "Price"
    },
    {
        key: "mrp",
        title: "MRP"
    },
    {
        key: "status",
        title: "Status",
        options: [
            {
                value: true,
                text: "Available"
            },
            {
                value: false,
                text: "Unavailable"
            },

        ]
    },
    {
        key: "action",
        title: "Action",
        isFilter: false,
        isSort: false
    }
];

export const orderHeader: ITableHeader[] = [
    {
        key: "customerName",
        title: "Order by",
        isSearch: true,
        isFilter: false,
        isSort: false,
        className: "!w-[15%] px-2"
    },
    {
        key: "items",
        title: "Products",
        isFilter: false,
        isSort: false,
    },
    {
        key: "createdAt",
        title: "Order At",
        dataType: "date",
        className: "!w-[15%] px-2"
    },
    {
        key: "totalAmount",
        title: "Amount",
        className: "!w-[10%] px-2"
    },
    {
        key: "tableNumber",
        title: "Table No.",
        isSearch: true,
        className: "!w-[10%] px-2"
    },
    {
        key: "status",
        title: "Status",
        className: "!w-[10%] px-2"
    },
    {
        key: "action",
        title: "Action",
        isFilter: false,
        isSort: false,
        className: "!w-[5%] px-2"
    }

]
