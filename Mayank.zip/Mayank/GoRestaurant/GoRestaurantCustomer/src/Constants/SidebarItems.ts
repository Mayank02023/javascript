import { ClipboardTaskListLtrFilled, DocumentBulletListFilled, FoodFilled, GridFilled, HomeMoreFilled, PeopleCommunityFilled } from '@fluentui/react-icons';
interface Link {
    label: string;
    link: string;
}

interface IMenuItem {
    label: string;
    icon: React.FC;
    initiallyOpened?: boolean;
    path: string;
    links?: Link[];
}

export const sidebarItems: IMenuItem[] =
    [
        {
            icon: GridFilled,
            label: "Dashboard",
            path: "/"
        },
        {
            icon: FoodFilled,
            label: "Foods",
            path: "/foodlist",
            links: [
                {
                    label: "Foods",
                    link: "/foods",
                },
                {
                    label: "Food Category",
                    link: "/food-category",
                }
            ]
        },
        {
            icon: FoodFilled,
            label: "Orders",
            path: "/orders",
            links: [
                {
                    label: "Orders",
                    link: "/orders",
                },
                {
                    label: "Order Status",
                    link: "/order-status",
                }
            ]
        },
        {
            icon: DocumentBulletListFilled,
            label: "Billing",
            path: "/billing"
        },
        {
            icon: PeopleCommunityFilled,
            label: "Workers",
            path: "/workers",
            links: [
                {
                    label: "Worker",
                    link: "/workers",
                },
                {
                    label: "Roles",
                    link: "/roles",
                },
                {
                    label: "Shifts",
                    link: "/shifts",
                }
            ]

        },
        {
            icon: HomeMoreFilled,
            label: "Inventory",
            path: "/inventory"
        },
        {
            icon: ClipboardTaskListLtrFilled,
            label: "Reports",
            path: "/reports"
        },

    ];