import React, { useEffect } from "react";
import { useOrderContext } from "../../Context/OrderContext";
import { IInitiatePaymentResponse, IOrder, IOrderRequest } from "../../Types";
import { BackButton, Hr } from "../../Components";
import orderController from "../../DataProvider/Controllers/orderController";
import { setMyOrders } from "../../Context/OrderContext/orderActions";
import { getOrdersFromLocalStorage } from "../../Util";
import { useNavigate } from "react-router-dom";
import paymentController from "../../DataProvider/Controllers/paymentController";

const PlacedOrders: React.FC = () => {
  const navigate = useNavigate();
  const { myOrders, orderDispatch } = useOrderContext();

  useEffect(() => {
    const loadOrders = async () => {
      const orderIds = getOrdersFromLocalStorage();
      const response = await orderController.getOrdersList({
        page: 1,
        limit: 30,
        ids: orderIds
      });

      if (response.success && response.data) {
        orderDispatch(setMyOrders({ ...response.data }))
      }
    };
    loadOrders();
  }, []);



  const handlePayment = async (order: IOrder) => {
    try {
      if (order.paymentMethod === "CASH") {
        const { success: paymentSuccess, data: paymentData } =
          await paymentController.initiatePayment({ amount: order.totalAmount });

        if (!paymentSuccess || !paymentData) {
          return console.error("Payment initiation failed.");
        }

        await handlePaymentVerify(paymentData, order._id);


      }
    } catch (error) {
      console.error("Error placing order:", error);
    }
  };

  const handlePaymentVerify = async (data: IInitiatePaymentResponse, orderId: string) => {
    if (!(window as any).Razorpay) {
      return console.error("Razorpay SDK not loaded.");
    }

    const updatePayload: Partial<IOrderRequest> = {};

    const options = {
      key: "rzp_test_CBpOvykOrhDr9H",
      amount: data.amount,
      currency: data.currency,
      name: "GoRestaurant",
      description: "Test Mode",
      order_id: data.id,
      handler: async (response: any) => {
        try {
          const { success: verifySuccess, data: verifyData } =
            await paymentController.verifyPayment({ ...response, orderId });

          if (!verifySuccess || !verifyData) {
            updatePayload.paymentStatus = "FAILED";
            return console.error("Payment verification failed.");
          }

          const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = response;
          updatePayload.paymentStatus = "SUCCESS";
          updatePayload.paymentDetails = {
            paymentId: razorpay_payment_id,
            orderId: razorpay_order_id,
            signature: razorpay_signature
          };
        } catch (error) {
          updatePayload.paymentStatus = "FAILED";
          console.error("Payment verification error:", error);

        } finally {
          updatePayload.paymentMethod = "ONLINE";
          const { success, data } = await orderController.updateOrder(orderId, updatePayload);
          if (success && data) {
            const orders = myOrders.orders.map((order: IOrder) =>
              order._id === orderId ? { ...order, ...data } : order
            );

            orderDispatch(setMyOrders({ ...myOrders, orders }));
          }

        }
      },
      theme: { color: "#5f63b8" },
    };

    new (window as any).Razorpay(options).open();
  };
  return (
    <div className="p-2 bg-gray-100 min-h-screen">
      <BackButton navigate={navigate} />
      <h2 className="PageHeading text-xl font-semibold mb-2">My Orders</h2>
      {myOrders.orders.map((order: IOrder) => (
        <div key={order._id} className="bg-white p-3 rounded-lg shadow-md mb-2">
          <div className="flex justify-between items-center pb-2">
            <span className="text-base text-gray-600">#{order._id}</span>
            <span className="text-base text-gray-600">
              Status: <span className="font-semibold capitalize">{order.status}</span>
            </span>
          </div>
          <Hr className="!mb-0" />
          <div>
            {order.items.map((item) => (
              <div key={item._id} className="flex items-center justify-between py-2 border-b">
                <img src={`https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Cheeseburger.jpg/640px-Cheeseburger.jpg`} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                <div className="flex-1 ml-3">
                  <h4 className="font-medium">{item.name}</h4>
                  <p className="text-sm text-gray-600">₹{item.price}</p>
                </div>
                <p className="text-gray-500">Qty: {item.quantity}</p>
              </div>
            ))}
          </div>

          <div className="mt-2 flex justify-between items-center">
            <span className="text-base text-gray-600 capitalize">
              Total: <span className="font-semibold">₹{order.totalAmount}</span>
            </span>
            <button
              className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm disabled:bg-gray-300 disabled:text-black hover:bg-blue-600 transition"
              onClick={() => handlePayment(order)}
              disabled={order.paymentMethod !== "CASH"}
            >
              {order.paymentMethod === "CASH" && order.status !== "COMPLETED" ? "Pay Now" : "Paid"}

            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default PlacedOrders;
