import React, { useEffect, useMemo, useState } from "react";
import { useCartContext } from "../../Context/CartContext";
import { useOrderContext } from "../../Context/OrderContext";
import { setOrder } from "../../Context/OrderContext/orderActions";
import { useNavigate, useParams } from "react-router-dom";
import { Container, BackButton, CartItemList, PaymentSummaryPanel, PaymentMethodPanel, PaymentButton } from "../../Components";
import orderController from "../../DataProvider/Controllers/orderController";
import { ICart, IInitiatePaymentResponse, IOrderRequest } from "../../Types";
import { deleteCart, updateCart } from "../../Context/CartContext/cartAction";
import { getOrdersFromLocalStorage } from "../../Util"; import paymentController from "../../DataProvider/Controllers/paymentController";
import OrderPlaced, { IOrderPlaced } from "../../Components/OrderPlaced";

const OrderSummary: React.FC = () => {
    const navigate = useNavigate();
    const { branchId, tableId } = useParams<{ branchId: string; tableId: string }>();
    const { cartState, dispatch } = useCartContext();
    const { order, orderDispatch } = useOrderContext();
    const [isOpen, setIsOpen] = useState({ paymentSummary: false, paymentMethod: true });
    const [placedOrder, setPlacedOrder] = useState<IOrderPlaced | null>(null)

    // Memoize computed values so they update consistently
    const { items, orderTotal, discount, taxs, totalPrice } = useMemo(() => {
        const items = cartState.cartItems.map((cart) => ({
            menuItemId: cart.menuItem._id,
            price: cart.menuItem.price,
            quantity: cart.quantity,
        }));

        const orderTotal = cartState.cartItems.reduce(
            (acc, item: ICart) => acc + item.menuItem.price * item.quantity,
            0
        );
        const discount = (orderTotal * 10) / 100;
        const taxs = ((orderTotal - discount) * 18) / 100;
        const totalPrice = orderTotal - discount + taxs;

        return { items, orderTotal, discount, taxs, totalPrice };
    }, [cartState]); // Added `cartState` dependency


    // Update current order state whenever branchId, items, or totals change
    useEffect(() => {
        if (!branchId || !tableId) return;
        const newOrder: IOrderRequest = {
            ...order,
            branchId,
            tableId,
            items,
            totalAmount: totalPrice,
            cashfreeOrderId: "CF123456",
            cashfreeToken: "token_abcdef",
            customerName: order.customerName || "",
            paymentMethod: order.paymentMethod || "CASH",
            status: order.status || "PENDING",
            orderType: order.orderType || "DINE_IN",
            paymentStatus: order.paymentStatus || "INITIATED",
            staffId: order.staffId,
        };

        orderDispatch(setOrder(newOrder));
    }, [branchId, items, totalPrice, orderDispatch, tableId]);


    // Load cart items from localStorage
    useEffect(() => {
        if (!branchId) return;
        const storedCart = localStorage.getItem("Cart");
        if (storedCart) {
            const parsedCart: ICart[] = JSON.parse(storedCart);
            const thisBranchCart = parsedCart.filter(
                (cart) => cart.menuItem.branchId === branchId
            );
            dispatch({ type: "SET_DATA", payload: thisBranchCart });
        }
    }, [branchId, dispatch]);

    const removeItemFromCart = (cartItem: ICart) => {
        if (cartItem) {
            dispatch(deleteCart(cartItem._id));
        }
    };

    const updateQuantity = (id: string, action: "INCREASE" | "DECREASE") => {
        const cartItem = cartState.cartItems.find((cart) => cart._id === id);
        if (!cartItem) return;
        const newQuantity =
            action === "INCREASE" ? cartItem.quantity + 1 : cartItem.quantity - 1;
        if (newQuantity <= 0) {
            removeItemFromCart(cartItem);
        } else {
            dispatch(updateCart({ ...cartItem, quantity: newQuantity }));
        }
    };

    // Render empty state if cart is empty
    if (cartState.cartItems.length === 0) {
        return (
            <Container style={{ height: "calc(100vh - 72px)" }}>
                <BackButton navigate={navigate} />
                <h2 className="PageHeading text-xl font-semibold mb-2">Order summary</h2>
                <div className="flex flex-col items-center justify-center" style={{ height: "calc(100vh - 206px)" }}>
                    <h2 className="text-xl font-semibold mb-4">Your cart is empty</h2>
                    <p className="text-gray-600 mb-6">
                        Looks like you haven&apos;t added any food to your cart yet.
                    </p>
                    <button
                        type="button"
                        onClick={() => navigate(`/${branchId}/${tableId}/menu`)}
                        className="bg-blue-600 text-white px-5 py-2 rounded-full hover:bg-blue-700"
                    >
                        Order Food
                    </button>
                </div>
            </Container>
        );
    }

    const updateOrdersInLocalStorage = (newOrderId: string) => {
        try {
            const existingOrders = getOrdersFromLocalStorage(); // Get existing orders
            const updatedOrders = [...existingOrders, newOrderId];

            localStorage.setItem("Orders", JSON.stringify(updatedOrders));
        } catch (error) {
            console.error("Error updating orders in localStorage:", error);
        }
    };

    const deleteCartInLocalStorage = () => {
        localStorage.removeItem("Cart");
        dispatch({ type: "SET_DATA", payload: [] });
    };


    const handlePlaceOrder = async () => {
        if (!branchId) return console.error("Branch ID is missing");

        const newOrder = { ...order, branchId, items, totalAmount: Math.ceil(totalPrice) };

        try {
            // Place Order
            const { success: orderSuccess, data: orderData, message: orderMessage } =
                await orderController.createOrder(branchId, newOrder);

            if (!orderSuccess || !orderData) {
                return console.error("Order Placement Failed:", orderMessage);
            }


            if (newOrder.paymentMethod === "CASH") {
                setPlacedOrder(() => ({ orderId: orderData._id, paymentMethod: orderData.paymentMethod }));
                deleteCartInLocalStorage();
                updateOrdersInLocalStorage(orderData._id);
                return;
            }
            // Initiate Payment
            const { success: paymentSuccess, data: paymentData } =
                await paymentController.initiatePayment({ amount: newOrder.totalAmount });

            if (!paymentSuccess || !paymentData) {
                return console.error("Payment initiation failed.");
            }

            await handlePaymentVerify(paymentData, orderData._id);
            deleteCartInLocalStorage();
            updateOrdersInLocalStorage(orderData._id);
        } catch (error) {
            console.error("Error placing order:", error);
        }
    };

    const handlePaymentVerify = async (data: IInitiatePaymentResponse, orderId: string) => {
        if (!(window as any).Razorpay) {
            return console.error("Razorpay SDK not loaded.");
        }

        const updatePayload: Partial<IOrderRequest> = {};

        const options = {
            key: "rzp_test_CBpOvykOrhDr9H",
            amount: data.amount,
            currency: data.currency,
            name: "GoRestaurant",
            description: "Test Mode",
            order_id: data.id,
            handler: async (response: any) => {
                console.log("Payment Response:", response);

                try {
                    const { success: verifySuccess, data: verifyData } =
                        await paymentController.verifyPayment({ ...response, orderId });

                    if (!verifySuccess || !verifyData) {
                        updatePayload.paymentStatus = "FAILED";
                        return console.error("Payment verification failed.");
                    }

                    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = response;
                    updatePayload.paymentStatus = "SUCCESS";
                    updatePayload.paymentDetails = {
                        paymentId: razorpay_payment_id,
                        orderId: razorpay_order_id,
                        signature: razorpay_signature
                    };
                    setPlacedOrder(() => ({ orderId, paymentMethod: "ONLINE", paymentId: razorpay_payment_id }));
                } catch (error) {
                    updatePayload.paymentStatus = "FAILED";
                    console.error("Payment verification error:", error);

                } finally {
                    await orderController.updateOrder(orderId, updatePayload);

                }
            },
            theme: { color: "#5f63b8" },
        };

        new (window as any).Razorpay(options).open();
    };


    return (
        <div className="relative max-w-xl mx-auto" style={{ height: "calc(100vh - 72px)" }}>
            {placedOrder ? (<OrderPlaced placedOrder={placedOrder} />
            ) : (
                <>
                    <Container className="h-full">
                        <BackButton navigate={navigate} />
                        <h2 className="PageHeading text-xl font-semibold mb-2">Order summary</h2>
                        <div className="flex flex-col justify-between" style={{ height: "calc(100vh - 208px)" }}>
                            <CartItemList
                                cartItems={cartState.cartItems}
                                removeItem={removeItemFromCart}
                                updateQuantity={updateQuantity}
                            />
                            <div>
                                <PaymentSummaryPanel
                                    isOpen={isOpen.paymentSummary}
                                    toggle={() =>
                                        setIsOpen((prev) => ({ ...prev, paymentSummary: !prev.paymentSummary }))
                                    }
                                    orderTotal={orderTotal}
                                    discount={discount}
                                    taxs={taxs}
                                    totalPrice={totalPrice}
                                />
                                <PaymentMethodPanel
                                    isOpen={isOpen.paymentMethod}
                                    toggle={() =>
                                        setIsOpen((prev) => ({ ...prev, paymentMethod: !prev.paymentMethod }))
                                    }
                                />
                            </div>
                        </div>
                    </Container>
                    <PaymentButton orderTotal={orderTotal} handlePlaceOrder={handlePlaceOrder} />

                </>
            )}
        </div>
    );
};

export default OrderSummary;
