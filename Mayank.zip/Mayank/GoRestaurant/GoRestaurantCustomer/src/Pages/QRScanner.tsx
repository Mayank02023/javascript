import { Scanner } from '@yudiel/react-qr-scanner';

const QRScanner = () => {
    return <Scanner onScan={(result) => console.log(result)} />;
};

export default QRScanner;