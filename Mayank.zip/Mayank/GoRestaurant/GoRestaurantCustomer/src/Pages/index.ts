import Menu from "./Menu";
import PlacedOrders from "./Orders";
import OrderSummary from "./OrderSummery";
import QRScanner from "./QRScanner";

export {
    Menu,
    OrderSummary,
    PlacedOrders,
    QRScanner
};