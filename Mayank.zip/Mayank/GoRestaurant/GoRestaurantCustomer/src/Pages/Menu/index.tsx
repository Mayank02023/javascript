import React, { useCallback, useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { CartButton, Container, MenuItem, SortAnFilter } from "../../Components";
import { useMenuContext } from "../../Context/MenuContext";
import menuController from "../../DataProvider/Controllers/menuController";
import { IFilter } from "../../Components/SortAnFilter";
import { useCartContext } from "../../Context/CartContext";
import { ICart } from "../../Types";
import { MenuState } from "../../Context/MenuContext/menuReducer";
import tableController from "../../DataProvider/Controllers/tableController";

const PAGE_SIZE = 20;

const Menu: React.FC = () => {
    const { branchId, tableId } = useParams<{ branchId: string; tableId: string }>();

    // Modal state
    const [showDialog, setShowDialog] = useState(false);
    const [progress, setProgress] = useState(100);

    useEffect(() => {
        if (!tableId) return;
    
        const loadTable = async () => {
            setLoading(true);
            const response = await tableController.getTable(tableId);
            
            if (response.success && response.data && response.data.occupiedSeats === response.data.capacity) {
                setShowDialog(true);
                
                let timeLeft = 5;
                const timer = setInterval(() => {
                    timeLeft -= 1;
                    setProgress((timeLeft / 5) * 100);
                    
                    if (timeLeft === 0) {
                        clearInterval(timer);
    
                        // Attempt to close the tab
                        window.opener = null;
                        window.open("about:blank", "_self");
                        window.close();
                    }
                }, 1000);
            }
    
            setLoading(false);
        };
    
        loadTable();
    }, [tableId]);
    
    const [cartLoading, setCartLoading] = useState(true);
    const [menu, setMenu] = useState<MenuState>({ menuItems: [], totalItems: 0 });

    const { state: menuState, dispatch } = useMenuContext();
    const { cartState, dispatch: cartDispatch } = useCartContext();

    const [filter, setFilter] = useState<IFilter>({ price: 0, categories: [], searchQuery: "" });
    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(false);
    const [hasMore, setHasMore] = useState(true);

    const observer = useRef<IntersectionObserver | null>(null);
    const lastElementRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        dispatch({ type: "SET_DATA", payload: menu });
    }, [dispatch, menu]);


    useEffect(() => {
        if (!tableId) return;
        const loadTable = async () => {
            setLoading(true);
            const response = await tableController.getTable(tableId);
            if (response.success && response.data && response.data.occupiedSeats === response.data.capacity) {
                // a dialog model should be come and show the current table is fully occupied so please chnage the table 
                // in the dialog the progess bar should be show and it will expire in 5 second and exit to the browser

            }
            setLoading(false);
        }
        loadTable();
    }, [tableId]);
    // Debounced Fetch Function
    const fetchMenuData = useCallback((pageNumber: number, reset = false) => {
        if (!branchId || loading || (pageNumber > 1 && !hasMore)) return;

        setLoading(true);
        const timer = setTimeout(async () => {
            try {
                const response = await menuController.getMenuList(branchId, {
                    page: pageNumber,
                    limit: PAGE_SIZE,
                    search: filter.searchQuery || undefined,
                    categoryIds: filter.categories.length > 0 ? filter.categories : undefined,
                });

                if (!response.success) {
                    console.error("Error fetching menu items:", response.message);
                    return;
                }

                const newData = Array.isArray(response.data?.menuItems) ? response.data?.menuItems : [];
                setMenu((prevMenu) => ({
                    menuItems: reset ? newData : [...prevMenu.menuItems, ...newData],
                    totalItems: response.data?.total || 0
                }));

                setHasMore(newData.length === PAGE_SIZE);
            } catch (error) {
                console.error("Error fetching menu items:", error);
            } finally {
                setLoading(false);
            }
        }, 300); // 🔹 Added debounce (300ms)

        return () => clearTimeout(timer);
    }, [branchId, filter]);

    // Fetch when `page` changes
    useEffect(() => {
        if (page > 1) fetchMenuData(page);
    }, [page]);

    // Fetch when `filter` changes
    useEffect(() => {
        setPage(1); // Reset page number
        fetchMenuData(1, true);
    }, [filter]);

    // ✅ Infinite Scrolling with Proper Cleanup
    useEffect(() => {
        if (!lastElementRef.current || loading || !hasMore) return;

        const observerCallback = (entries: IntersectionObserverEntry[]) => {
            if (entries[0].isIntersecting) setPage((prev) => prev + 1);
        };

        if (observer.current) observer.current.disconnect(); // ✅ Cleanup existing observer before creating a new one
        observer.current = new IntersectionObserver(observerCallback, { threshold: 1.0 });

        if (lastElementRef.current) observer.current.observe(lastElementRef.current);

        return () => observer.current?.disconnect();
    }, [loading, hasMore]);

    // ✅ Restore Cart Data from Local Storage
    useEffect(() => {
        if (!branchId) return;
        const storedCart = localStorage.getItem("Cart");

        if (storedCart) {
            const parsedCart: ICart[] = JSON.parse(storedCart);
            const thisBranchCart = parsedCart.filter(cart => cart.menuItem.branchId === branchId);
            cartDispatch({ type: 'SET_DATA', payload: thisBranchCart });
        }

        setCartLoading(false);
    }, [branchId, cartDispatch]);

    // ✅ Memoized Cart Button
    const renderCartButton = useCallback(() => {
        if (cartLoading || cartState.cartItems.length === 0) return null;
        return (
            <div className="HandleCart fixed bottom-2 right-2">
                <CartButton cartQantity={cartState.cartItems.length} branchId={branchId} tableId={tableId} />
            </div>
        );
    }, [cartState.cartItems.length, branchId, cartLoading]);

    return (
        <Container className="relative">
            <SortAnFilter
                branchId={branchId}
                totalItems={menuState.totalItems || 0}
                filter={filter}
                setFilter={setFilter} // 🔹 Fixed unnecessary function wrapping
            />
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-1 py-4">
                {menuState.menuItems.map((menuItem) => (
                    <MenuItem
                        key={menuItem._id} // ✅ Always use a unique `key`
                        menuItem={menuItem}
                        onClick={() => console.log(`menuItem: ${menuItem.name}`)}
                    />
                ))}
            </div>

            {renderCartButton()}
            {showDialog && (
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                    <div className="bg-white p-5 rounded-lg text-center w-80">
                        <h2 className="text-red-600 text-lg font-semibold">Table Fully Occupied</h2>
                        <p className="text-sm">Please change the table. This window will close in {Math.round(progress / 20)} seconds.</p>
                        <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                            <div className="bg-red-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                        </div>
                        <button onClick={() => window.close()} className="mt-4 px-4 py-2 bg-red-600 text-white rounded">Exit Now</button>
                    </div>
                </div>
            )}
            <div ref={lastElementRef} style={{ height: "20px" }} />
        </Container>
    );
};

export default Menu;

