import React, { useState, FormEvent, useEffect, useRef } from 'react';
import chatController from '../DataProvider/Controllers/chatController';

interface Message {
    query: string;
    response: string | null;
}

const ChatMessageBox: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState<string>('');
    const messagesEndRef = useRef<HTMLDivElement>(null); // Reference to scroll to bottom

    // Handle form submit
    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        const trimmedInput = input.trim();
        if (!trimmedInput) return;

        // Add user's message immediately
        setMessages((prevMessages) => [
            ...prevMessages,
            { query: trimmedInput, response: null },
        ]);

        setInput('');

        // Call the API and update the latest message with response
        const response = await chatController.chat(trimmedInput);
        if (!response.success || !response.data) {
            console.log(response.message);
        }
        // Update the message with the response
        setMessages((prevMessages) =>
            prevMessages.map((msg, index) =>
                index === prevMessages.length - 1 ? { ...msg, response: response.data } : msg
            )
        );
    };

    // Scroll to the bottom whenever messages change
    useEffect(() => {
        if (messagesEndRef.current) {
            messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [messages]);

    return (
        <div
            className="flex flex-col h-full max-w-md mx-auto bg-white shadow-lg rounded-lg overflow-hidden"
            style={{ height: 'calc(100vh - 75px)' }}
        >
            {/* Messages display area */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-gray-50">
                <span className="block text-center text-xl border-b-2 border-spacing-2">Chat Room</span>
                <div className="flex flex-col space-y-4 justify-end" style={{ height: 'calc(100vh - 200px)' }}>
                    {messages.map((message, index) => (
                        <div key={index} className="flex flex-col w-full space-y-2">
                            {/* User's message */}
                            <div className="flex justify-end w-full">
                                <div className="bg-blue-500 text-white px-4 py-2 rounded-lg shadow-md max-w-xs break-words">
                                    {message.query}
                                </div>
                            </div>
                            {/* Bot's response */}
                            {message.response && (
                                <div className="flex justify-start w-full">
                                    <div className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg shadow-md max-w-xs break-words">
                                        {message.response}
                                    </div>
                                </div>
                            )}
                        </div>
                    ))}
                    <div ref={messagesEndRef} /> {/* Scroll reference */}
                </div>
            </div>

            {/* Message input area */}
            <form onSubmit={handleSubmit} className="flex border-t border-gray-200">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Type your message..."
                    className="flex-1 px-4 py-2 outline-none focus:ring-2 focus:ring-blue-300"
                />
                <button
                    type="submit"
                    className="px-4 py-2 bg-blue-500 text-white hover:bg-blue-600 transition-colors duration-200"
                >
                    Send
                </button>
            </form>
        </div>
    );
};

export default ChatMessageBox;
