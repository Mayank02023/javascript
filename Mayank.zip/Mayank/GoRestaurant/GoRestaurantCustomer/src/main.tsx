import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import GlobalContext from './Context/GlobalContext'; // Import the GlobalContext component

ReactDOM.createRoot(document.getElementById('root')!).render(
    <GlobalContext>
        <App />
    </GlobalContext>
)
