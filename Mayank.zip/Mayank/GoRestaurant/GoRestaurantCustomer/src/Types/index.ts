export interface IApiResponse<T> {
    statusCode: number;
    data: T | null;
    message: string;
    success: boolean;
}

export interface ICategory {
    _id: string;
    name: string;
    description: string;
    createdAt: string;
    updatedAt: string;
}

export interface ITable {
    _id: string;
    capacity: number;
    branchId: string;
    status: 'occupied' | 'partially occupied' | 'available';
    occupiedSeats: number;
    createdAt?: Date;
    updatedAt?: Date;
}

export interface IMenuItem {
    _id: string; // ObjectId as string
    branchId: string;
    name: string;
    description?: string;
    price: number;
    avatar?: string;
    categoryId: string;
    ingredients: string[];
    availability: boolean;
    isDeleted: boolean;
    createdAt: string;
    updatedAt: string;
}

export interface ICart {
    _id: string;
    menuItem: IMenuItem;
    quantity: number;
}


interface IOrderItem {
    _id: string;
    name: string;
    quantity: number;
    price: number;
    avatar?: string;
    instructions?: string;
}

export interface IPaymentDetails {
    paymentId: string;
    orderId: string;
    signature: string;
}

export type IOrderStatus = "PENDING" | "CONFIRMED" | "PREPARING" | "READY" | "COMPLETED" | "CANCELLED";

export type IOrderType = "DINE_IN" | "TAKEAWAY";

export type IPaymentStatus = "INITIATED" | "SUCCESS" | "FAILED";

export type IPaymentMethod = "CASH" | "ONLINE";

export interface IOrder {
    _id: string;
    customerName: string;
    branchId: string;

    items: IOrderItem[];
    totalAmount: number;
    staff?: {
        name: string;
        _id: string;
    };
    paymentDetails?: IPaymentDetails;
    paymentMethod: IPaymentMethod;
    status?: IOrderStatus;
    orderType: IOrderType;
    paymentStatus?: IPaymentStatus;
    isDelete: boolean;
    createdAt: Date;
    updatedAt: Date;
}

export interface IOrderRequest {
    customerName: string;
    branchId: string;
    tableId: string;
    person: number;
    items: {
        menuItemId: string;
        price: number;
        quantity: number;
        instructions?: string;
    }[];
    totalAmount: number;
    cashfreeOrderId: string;
    cashfreeToken: string;
    paymentDetails?: IPaymentDetails;
    paymentMethod: IPaymentMethod;
    status?: IOrderStatus;
    orderType: IOrderType;
    paymentStatus?: IPaymentStatus;
    staffId?: string;
}

export interface IInitiatePaymentResponse {
    amount: number;
    amount_due: number;
    amount_paid: number;
    attempts: number;
    created_at: number;
    currency: string;
    entity: string;
    id: string;
    notes: string[];
    offer_id: string | null;
    receipt: string | null;
    status: string;
}

export interface IRazorpayResponse {
    razorpay_order_id: string;
    razorpay_payment_id: string;
    razorpay_signature: string;
    orderId: string;
}

