import { AxiosResponse } from "axios";
import { IApiResponse } from "../../Types";
import useService from "../Services/useService";
import axiosInstance from "../Services/axiosInstance"; // Use centralized Axios instance


/**
 * OrderController class provides API operations for managing orders.
 * It uses the `useService` hook to perform CRUD operations on the "restaurant/order" collection.
 */
class OrderController {
    private orderCollectionRef; // Reference to the service for order-related API operations
    constructor() {
        // Initialize the service reference for the "restaurant/order" collection
        this.orderCollectionRef = useService("order");
    }


    /**
     * Add a new order to the collection.
     * @param {IOrderRequest} orderData - The data of the order to be added
     * @returns {Promise<IApiResponse>} - The result of the add operation
     */
    async addOrder(orderData: any, documentID: string): Promise<any> {
        try {
            const response: AxiosResponse<Promise<IApiResponse>> = await axiosInstance.post(`/order/${documentID}`, orderData);
            return response.data;
        } catch (error) {
            console.error("API service :: addOrder :: Error adding order:", error);
            throw error; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Update an existing order in the collection.
     * @param {IOrderRequest} orderData - The updated data of the order
     * @returns {Promise<IApiResponse>} - The result of the update operation
     */
    async updateOrder(orderData: any): Promise<IApiResponse> {
        try {
            return await this.orderCollectionRef.updateDocument(orderData);
        } catch (err) {
            console.error("API service :: updateOrder :: Error updating order:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Delete an order from the collection by its ID.
     * @param {string} orderID - The ID of the order to be deleted
     * @returns {Promise<IApiResponse>} - The result of the delete operation
     */
    async deleteOrder(orderID: string): Promise<IApiResponse> {
        try {
            return await this.orderCollectionRef.deleteDocument(orderID);
        } catch (err) {
            console.error("API service :: deleteOrder :: Error deleting order:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve all orders from the collection.
     * @returns {Promise<IApiResponse>} - The list of orders, or an error response if it fails
     */
    async getOrders(documentID: string): Promise<IApiResponse> {
        try {
            return await this.orderCollectionRef.getDocuments(documentID);
        } catch (err) {
            console.error("API service :: getOrders :: Error retrieving orders:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve all orders from the collection.
     * @returns {Promise<IApiResponse>} - The list of orders, or an error response if it fails
     */
    async getOrdersForLastTwoDays(documentID: string): Promise<IApiResponse> {
        try {
            return await this.orderCollectionRef.getDocuments(`two-days/${documentID}`);
        } catch (err) {
            console.error("API service :: getOrdersForLastTwoDays :: Error retrieving orders:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve a single order by its ID.
     * @param {string} orderID - The ID of the order to retrieve
     * @returns {Promise<IApiResponse>} - The order data, or an error response if it fails
     */
    async getOrder(orderID: string): Promise<IApiResponse> {
        try {
            const orderResponse: IApiResponse = await this.orderCollectionRef.getDocument(orderID);
            return orderResponse;
        } catch (err) {
            console.error("API service :: getOrder :: Error retrieving order:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }
}

// Create an instance of the OrderController and export it for use in other parts of the application
const orderController = new OrderController();
export default orderController;
