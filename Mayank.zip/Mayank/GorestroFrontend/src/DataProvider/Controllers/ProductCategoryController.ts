import { IApiResponse, IProductCategoryRequest } from "../../Types";
import useService from "../Services/useService";

/**
 * ProductCategoryController class provides API operations for managing product categories.
 * It uses the `useService` hook to perform CRUD operations on the "restaurant/product-category" collection.
 */
class ProductCategoryController {
    private productCategoryCollectionRef; // Reference to the service for product category-related API operations

    constructor() {
        // Initialize the service reference for the "restaurant/product-category" collection
        this.productCategoryCollectionRef = useService("category");
    }

    /**
     * Add a new product category to the collection.
     * @param {IProductCategoryRequest} categoryData - The data of the product category to be added
     * @returns {Promise<IApiResponse>} - The result of the add operation
     */
    async addProductCategory(categoryData: IProductCategoryRequest): Promise<IApiResponse> {
        try {
            return await this.productCategoryCollectionRef.addDocument(categoryData);
        } catch (err) {
            console.error("API service :: addProductCategory :: Error adding product category:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Update an existing product category in the collection.
     * @param {IProductCategoryRequest} categoryData - The updated data of the product category
     * @returns {Promise<IApiResponse>} - The result of the update operation
     */
    async updateProductCategory(categoryData: IProductCategoryRequest): Promise<IApiResponse> {
        try {
            return await this.productCategoryCollectionRef.updateDocument(categoryData);
        } catch (err) {
            console.error("API service :: updateProductCategory :: Error updating product category:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Delete a product category from the collection by its ID.
     * @param {string} categoryID - The ID of the product category to be deleted
     * @returns {Promise<IApiResponse>} - The result of the delete operation
     */
    async deleteProductCategory(categoryID: string): Promise<IApiResponse> {
        try {
            return await this.productCategoryCollectionRef.deleteDocument(categoryID);
        } catch (err) {
            console.error("API service :: deleteProductCategory :: Error deleting product category:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve all product categories from the collection.
     * @returns {Promise<IApiResponse>} - The list of product categories, or an error response if it fails
     */
    async getProductCategories(documentID: string): Promise<IApiResponse> {
        try {
            return await this.productCategoryCollectionRef.getDocuments(documentID);
        } catch (err) {
            console.error("API service :: getProductCategories :: Error retrieving product categories:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve a single product category by its ID.
     * @param {string} categoryID - The ID of the product category to retrieve
     * @returns {Promise<IApiResponse>} - The product category data, or an error response if it fails
     */
    async getProductCategory(categoryID: string): Promise<IApiResponse> {
        try {
            return await this.productCategoryCollectionRef.getDocument(categoryID);
        } catch (err) {
            console.error("API service :: getProductCategory :: Error retrieving product category:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }
}

// Create an instance of the ProductCategoryController and export it for use in other parts of the application
const productCategoryController = new ProductCategoryController();
export default productCategoryController;
