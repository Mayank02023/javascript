import { IApiResponse, IOrderStatusRequest } from "../../Types";
import useService from "../Services/useService";

/**
 * OrderStatusController class provides API operations for managing order statuses.
 * It uses the `useService` hook to perform CRUD operations on the "restaurant/order/status" collection.
 */
class OrderStatusController {
    private statusCollectionRef; // Reference to the service for order-status-related API operations

    constructor() {
        // Initialize the service reference for the "restaurant/order/status" collection
        this.statusCollectionRef = useService("order-status");
    }

    /**
     * Add a new order status to the collection.
     * @param {IOrderStatusRequest} statusData - The data of the order status to be added
     * @returns {Promise<IApiResponse>} - The result of the add operation
     */
    async addOrderStatus(statusData: IOrderStatusRequest): Promise<IApiResponse> {
        try {
            return await this.statusCollectionRef.addDocument(statusData);
        } catch (err) {
            console.error("API service :: addOrderStatus :: Error adding order status:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Update an existing order status in the collection.
     * @param {IOrderStatusRequest} statusData - The updated data of the order status
     * @returns {Promise<IApiResponse>} - True if the update was successful, otherwise false
     */
    async updateOrderStatus(statusData: IOrderStatusRequest): Promise<IApiResponse> {
        try {
            return await this.statusCollectionRef.updateDocument(statusData);
        } catch (err) {
            console.error("API service :: updateOrderStatus :: Error updating order status:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Get all order statuses.
     * @returns {Promise<IApiResponse>} - The list of order statuses, or null if an error occurs
     */
    async getOrderStatuses(): Promise<IApiResponse> {
        try {
            return await this.statusCollectionRef.getDocuments();
        } catch (err) {
            console.error("API service :: getOrderStatuses :: Error retrieving order statuses:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve a single order status by its ID.
     * @param {string} statusID - The ID of the status to retrieve
     * @returns {Promise<IApiResponse>} - The order status data, or null if an error occurs
     */
    async getOrderStatus(statusID: string): Promise<IApiResponse> {
        try {
            return await this.statusCollectionRef.getDocument(statusID);
        } catch (err) {
            console.error("API service :: getOrderStatus :: Error retrieving order status:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Delete an order status by its ID.
     * @param {string} statusID - The ID of the status to be deleted
     * @returns {Promise<IApiResponse>} - True if the deletion was successful, otherwise false
     */
    async deleteOrderStatus(statusID: string): Promise<IApiResponse> {
        try {
            return await this.statusCollectionRef.deleteDocument(statusID);
        } catch (err) {
            console.error("API service :: deleteOrderStatus :: Error deleting order status:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }
}

// Create an instance of the OrderStatusController and export it for use in other parts of the application
const orderStatusController = new OrderStatusController();
export default orderStatusController;
