import { IApiResponse, IWorkerRequest } from "../../Types";
import useService from "../Services/useService";

/**
 * WorkerController class provides API operations for managing workers.
 * It uses the `useService` hook to perform CRUD operations on the "restaurant/worker" collection.
 */
class WorkerController {
    private workerCollectionRef; // Reference to the service for worker-related API operations

    constructor() {
        // Initialize the service reference for the "restaurant/worker" collection
        this.workerCollectionRef = useService("restaurant/worker");
    }

    /**
     * Add a new worker to the collection.
     * @param {IWorkerRequest} workerData - The data of the worker to be added
     * @returns {Promise<IApiResponse>} - The result of the add operation
     */
    async addWorker(workerData: IWorkerRequest): Promise<IApiResponse> {
        try {
            return await this.workerCollectionRef.addDocument(workerData);
        } catch (err) {
            console.error("API service :: addWorker :: Error adding worker:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Update an existing worker in the collection.
     * @param {IWorkerRequest} workerData - The updated data of the worker
     * @returns {Promise<IApiResponse>} - The result of the update operation
     */
    async updateWorker(workerData: IWorkerRequest): Promise<IApiResponse> {
        try {
            return await this.workerCollectionRef.updateDocument(workerData);
        } catch (err) {
            console.error("API service :: updateWorker :: Error updating worker:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Delete a worker from the collection by its ID.
     * @param {string} workerID - The ID of the worker to be deleted
     * @returns {Promise<IApiResponse>} - The result of the delete operation
     */
    async deleteWorker(workerID: string): Promise<IApiResponse> {
        try {
            return await this.workerCollectionRef.deleteDocument(workerID);
        } catch (err) {
            console.error("API service :: deleteWorker :: Error deleting worker:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve all workers from the collection.
     * @returns {Promise<IApiResponse>} - The list of workers, or an error response if it fails
     */
    async getWorkers(): Promise<IApiResponse> {
        try {
            return await this.workerCollectionRef.getDocuments();
        } catch (err) {
            console.error("API service :: getWorkers :: Error retrieving workers:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve a single worker by its ID.
     * @param {string} workerID - The ID of the worker to retrieve
     * @returns {Promise<IApiResponse>} - The worker data, or an error response if it fails
     */
    async getWorker(workerID: string): Promise<IApiResponse> {
        try {
            return await this.workerCollectionRef.getDocument(workerID);
        } catch (err) {
            console.error("API service :: getWorker :: Error retrieving worker:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }
}

// Create an instance of the WorkerController and export it for use in other parts of the application
const workerController = new WorkerController();
export default workerController;
