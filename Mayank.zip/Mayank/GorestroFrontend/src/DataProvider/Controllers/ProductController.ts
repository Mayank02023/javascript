import { IApiResponse } from "../../Types";
import useService from "../Services/useService";

/**
 * ProductController class provides API operations for managing products.
 * It uses the `useService` hook to perform CRUD operations on the "restaurant/product" collection.
 */
class ProductController {
    private productCollectionRef; // Reference to the service for product-related API operations

    constructor() {
        // Initialize the service reference for the "restaurant/product" collection
        this.productCollectionRef = useService("product");
    }

    /**
     * Add a new product to the collection.
     * @param {IProductRequest} productData - The data of the product to be added
     * @returns {Promise<IApiResponse>} - The result of the add operation
     */
    async addProduct(productData: any, file: File | null): Promise<IApiResponse> {
        try {
            return await this.productCollectionRef.addDocument(productData, file);
        } catch (err) {
            console.error("API service :: addProduct :: Error adding product:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Update an existing product in the collection.
     * @param {IProductRequest} productData - The updated data of the product
     * @returns {Promise<IApiResponse>} - The result of the update operation
     */
    async updateProduct(productData: any): Promise<IApiResponse> {
        try {
            return await this.productCollectionRef.updateDocument(productData);
        } catch (err) {
            console.error("API service :: updateProduct :: Error updating product:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Delete a product from the collection by its ID.
     * @param {string} productID - The ID of the product to be deleted
     * @returns {Promise<IApiResponse>} - The result of the delete operation
     */
    async deleteProduct(productID: string): Promise<IApiResponse> {
        try {
            return await this.productCollectionRef.deleteDocument(productID);
        } catch (err) {
            console.error("API service :: deleteProduct :: Error deleting product:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve all products from the collection.
     * @returns {Promise<IApiResponse>} - The list of products, or an error response if it fails
     */
    async getProducts(): Promise<IApiResponse> {
        try {
            return await this.productCollectionRef.getDocuments();
        } catch (err) {
            console.error("API service :: getProducts :: Error retrieving products:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
 * Retrieve all available products from the collection.
 * @param {string} restroId - The ID of the restro to retrieve
 * @returns {Promise<IApiResponse>} - The list of available products, or an error response if it fails
 */
    async getAvailableProducts(restroId: string): Promise<IApiResponse> {
        try {
            return await this.productCollectionRef.getAvailableDocuments(restroId);
        } catch (err) {
            console.error("API service :: getAvailableProducts :: Error retrieving available products:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve a single product by its ID.
     * @param {string} productID - The ID of the product to retrieve
     * @returns {Promise<IApiResponse>} - The product data, or an error response if it fails
     */
    async getProduct(productID: string): Promise<IApiResponse> {
        try {
            return await this.productCollectionRef.getDocument(productID);
        } catch (err) {
            console.error("API service :: getProduct :: Error retrieving product:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }
}

// Create an instance of the ProductController and export it for use in other parts of the application
const productController = new ProductController();
export default productController;
