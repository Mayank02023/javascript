import { IApiResponse, IWorkerRoleRequest } from "../../Types";
import useService from "../Services/useService";

/**
 * WorkerShiftController class provides API operations for managing worker shifts.
 * It uses the `useService` hook to perform CRUD operations on the "restaurant/worker/shifts" collection.
 */
class WorkerShiftController {
    private shiftCollectionRef; // Reference to the service for worker-shift-related API operations

    constructor() {
        // Initialize the service reference for the "restaurant/worker/shifts" collection
        this.shiftCollectionRef = useService("worker-shift");
    }

    /**
     * Add a new worker shift to the collection.
     * @param {IWorkerShiftRequest} shiftData - The data of the worker shift to be added
     * @returns {Promise<IApiResponse>} - The result of the add operation
     */
    async addWorkerShift(shiftData: IWorkerRoleRequest): Promise<IApiResponse> {
        try {
            return await this.shiftCollectionRef.addDocument(shiftData);
        } catch (err) {
            console.error("API service :: addWorkerShift :: Error adding worker shift:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Update an existing worker shift in the collection.
     * @param {IWorkerShiftRequest} shiftData - The updated data of the worker shift
     * @returns {Promise<IApiResponse>} - The result of the update operation
     */
    async updateWorkerShift(shiftData: IWorkerRoleRequest): Promise<IApiResponse> {
        try {
            return await this.shiftCollectionRef.updateDocument(shiftData);
        } catch (err) {
            console.error("API service :: updateWorkerShift :: Error updating worker shift:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Get all worker shifts.
     * @returns {Promise<IApiResponse>} - The list of worker shifts, or null if an error occurs
     */
    async getWorkerShifts(): Promise<IApiResponse> {
        try {
            return await this.shiftCollectionRef.getDocuments();
        } catch (err) {
            console.error("API service :: getWorkerShifts :: Error retrieving worker shifts:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve a single worker shift by its ID.
     * @param {string} shiftID - The ID of the shift to retrieve
     * @returns {Promise<IApiResponse>} - The worker shift data, or null if an error occurs
     */
    async getWorkerShift(shiftID: string): Promise<IApiResponse> {
        try {
            return await this.shiftCollectionRef.getDocument(shiftID);
        } catch (err) {
            console.error("API service :: getWorkerShift :: Error retrieving worker shift:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Delete a worker shift by its ID.
     * @param {string} shiftID - The ID of the shift to be deleted
     * @returns {Promise<IApiResponse>} - The result of the delete operation
     */
    async deleteWorkerShift(shiftID: string): Promise<IApiResponse> {
        try {
            return await this.shiftCollectionRef.deleteDocument(shiftID);
        } catch (err) {
            console.error("API service :: deleteWorkerShift :: Error deleting worker shift:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }
}

// Create an instance of the WorkerShiftController and export it for use in other parts of the application
const workerShiftController = new WorkerShiftController();
export default workerShiftController;
