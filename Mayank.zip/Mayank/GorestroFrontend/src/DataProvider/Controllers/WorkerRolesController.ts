import { IApiResponse, IWorkerRoleRequest } from "../../Types";
import useService from "../Services/useService";

/**
 * WorkerRoleController class provides API operations for managing worker roles.
 * It uses the `useService` hook to perform CRUD operations on the "restaurant/worker/roles" collection.
 */
class WorkerRoleController {
    private roleCollectionRef; // Reference to the service for worker-role-related API operations

    constructor() {
        // Initialize the service reference for the "restaurant/worker/roles" collection
        this.roleCollectionRef = useService("worker-role");
    }

    /**
     * Add a new worker role to the collection.
     * @param {IWorkerRoleRequest} roleData - The data of the worker role to be added
     * @returns {Promise<any>} - The result of the add operation
     */
    async addWorkerRole(roleData: IWorkerRoleRequest): Promise<IApiResponse> {
        try {
            return await this.roleCollectionRef.addDocument(roleData);
        } catch (err) {
            console.error("API service :: addWorkerRole :: Error adding worker role:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Update an existing worker role in the collection.
     * @param {IWorkerRoleRequest} roleData - The updated data of the worker role
     * @returns {Promise<boolean>} - True if the update was successful, otherwise false
     */
    async updateWorkerRole(roleData: IWorkerRoleRequest): Promise<IApiResponse> {
        try {
            return await this.roleCollectionRef.updateDocument(roleData);
        } catch (err) {
            console.error("API service :: updateWorkerRole :: Error updating worker role:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Get all worker roles.
     * @returns {Promise<IWorkerRoleResponse[] | null>} - The list of worker roles, or null if an error occurs
     */
    async getWorkerRoles(): Promise<IApiResponse> {
        try {
            return await this.roleCollectionRef.getDocuments();
        } catch (err) {
            console.error("API service :: getWorkerRoles :: Error retrieving worker roles:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Retrieve a single worker role by its ID.
     * @param {string} roleID - The ID of the role to retrieve
     * @returns {Promise<IWorkerRoleResponse | null>} - The worker role data, or null if an error occurs
     */
    async getWorkerRole(roleID: string): Promise<IApiResponse>  {       
        try {
            return await this.roleCollectionRef.getDocument(roleID);
        } catch (err) {
            console.error("API service :: getWorkerRole :: Error retrieving worker role:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }

    /**
     * Delete a worker role by its ID.
     * @param {string} roleID - The ID of the role to be deleted
     * @returns {Promise<boolean>} - True if the deletion was successful, otherwise false
     */
    async deleteWorkerRole(roleID: string): Promise<IApiResponse> {
        try {
            return await this.roleCollectionRef.deleteDocument(roleID);
        } catch (err) {
            console.error("API service :: deleteWorkerRole :: Error deleting worker role:", err);
            throw err; // Rethrow the error to be handled by the caller
        }
    }
}

// Create an instance of the WorkerRoleController and export it for use in other parts of the application
const workerRoleController = new WorkerRoleController();
export default workerRoleController;
