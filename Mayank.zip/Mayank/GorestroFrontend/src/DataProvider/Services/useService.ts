
import { IApiResponse } from "../../Types";
import axiosInstance from "./axiosInstance"; // Use centralized Axios instance

interface DocumentData {
    [key: string]: any;
}

/**
 * Custom service to manage API operations for collections and documents.
 * Provides basic CRUD operations for any specified collection.
 * @param {string} collectionName - Name of the API collection (e.g., "products")
 * @returns {Object} - Object containing CRUD API operations for the specified collection
 */
function useService(collectionName: string) {
    // API URL for the collection, will be appended to baseURL in axiosInstance
    const apiUrl = `/${collectionName}`;

    return {
        /**
         * Add a new document to the specified collection.
         * @param {DocumentData} data - The document data to be added
         * @param {File | null} file - The file to be uploaded (optional)
         * @returns {Promise<IApiResponse>} - The added document data
         */
        addDocument: async (data: DocumentData, file?: File | null): Promise<IApiResponse> => {
            try {
                // Create FormData only if a file is provided
                let formData: FormData | DocumentData = data;
                if (file) {
                    formData = new FormData();
                    // Append data properties to the FormData object
                    for (const key in data) {
                        if (data.hasOwnProperty(key)) {
                            formData.append(key, data[key]);
                        }
                    }
                    // Append the file to the FormData object
                    formData.append('avatar', file); // Change 'avatar' to the key expected by your API if necessary
                }

                // Send the POST request

                const response = await axiosInstance.post<IApiResponse>(apiUrl, formData, {
                    headers: {
                        'Content-Type': file ? 'multipart/form-data' : 'application/json', // Set content type accordingly
                    },
                });

                return response.data;
            } catch (error) {
                console.error(`Error adding document to ${collectionName}:`, error);
                throw error;
            }
        },

        /**
         * Update an existing document in the collection.
         * @param {string} documentID - The ID of the document to update
         * @param {DocumentData} data - The updated document data
         * @param {File | null} file - The file to be uploaded (optional)
         * @returns {Promise<IApiResponse>} - Returns the updated document data
         */
        updateDocument: async (data: DocumentData, file?: File | null): Promise<IApiResponse> => {
            try {
                // Create FormData only if a file is provided
                let formData: FormData | DocumentData = data;
                if (file) {
                    formData = new FormData();
                    // Append data properties to the FormData object
                    for (const key in data) {
                        if (data.hasOwnProperty(key)) {
                            formData.append(key, data[key]);
                        }
                    }
                    // Append the file to the FormData object
                    formData.append('avatar', file); // Change 'avatar' to the key expected by your API if necessary
                }

                // Send the PATCH request
                const response = await axiosInstance.patch<IApiResponse>(`${apiUrl}`, formData, {
                    headers: {
                        'Content-Type': file ? 'multipart/form-data' : 'application/json', // Set content type accordingly
                    },
                });

                return response.data;
            } catch (error) {
                console.error(`Error updating document in ${collectionName}:`, error);
                throw error;
            }
        },


        /**
         * Delete a document from the collection.
         * @param {string} documentID - The ID of the document to delete
         * @returns {Promise<DocumentData>} - Returns response after document delete
         */
        deleteDocument: async (documentID: string): Promise<IApiResponse> => {
            try {
                const response = await axiosInstance.delete<IApiResponse>(`${apiUrl}/${documentID}`);
                return response.data;
            } catch (error) {
                console.error(`Error deleting document from ${collectionName}:`, error);
                throw error;
            }
        },

        /**
         * Retrieve all documents from the collection.
         * @param {string} documentID - The ID of the document to find list
         * @returns {Promise<IApiResponse>} - The array of documents, or null if an error occurs
         */
        getDocuments: async (documentID?: string): Promise<IApiResponse> => {
            try {
                const url = documentID ? `${apiUrl}/list/${documentID}` : `${apiUrl}/list`;
                const response = await axiosInstance.get<IApiResponse>(url);
                return response.data;
            } catch (error) {
                console.error(`Error getting documents from ${collectionName}:`, error);
                throw error;
            }
        },

        /**
         * Retrieve all available documents from the collection.
         * @param {string} documentID - The ID of the document to find available list
         * @returns {Promise<IApiResponse>} - The array of documents, or null if an error occurs
         */
        getAvailableDocuments: async (documentID?: string): Promise<IApiResponse> => {
            try {
                const url = `${apiUrl}/available-list/${documentID}`;
                const response = await axiosInstance.get<IApiResponse>(url);
                return response.data;
            } catch (error) {
                console.error(`Error getting all available documents from ${collectionName}:`, error);
                throw error;
            }
        },

        /**
         * Retrieve a single document by ID from the collection.
         * @param {string} documentID - The ID of the document to retrieve
         * @returns {Promise<IApiResponse>} - The document data, or null if an error occurs
         */
        getDocument: async (documentID: string): Promise<IApiResponse> => {
            try {
                const response = await axiosInstance.get<IApiResponse>(`${apiUrl}/${documentID}`);
                return response.data;
            } catch (error) {
                console.error(`Error getting document from ${collectionName}:`, error);
                throw error;
            }
        }
    };
}

export default useService;
