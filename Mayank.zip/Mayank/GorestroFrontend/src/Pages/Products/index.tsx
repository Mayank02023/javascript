import React, { useEffect, useState } from "react";
import Styles from "./Products.module.scss";
import { Button, ConfirmDialog, Container, Flex, Table } from "../../Components";
import { IApiResponse, IProductResponse, IRestaurantResponse } from "../../Types";
import { useDispatch, useSelector } from "react-redux";
import productController from "../../DataProvider/Controllers/ProductController";
import { deleteProduct, setProducts, updateProduct } from "../../Store/Slices/productSlice";
import { JustifyContent } from "../../Components/Flex/Flex";
import { ISort, ITableHeader } from "../../Components/Table/Interface";
import { getProductTableRows } from "../../Utils/table";
import { productHeader } from "../../Constants/TableHeader";
import { ProductForm } from "../../Sections";

// Content for the delete confirmation dialog
const deleteProductContent = {
    header: "Delete Products",
    description: "Are you sure you want to delete this product? This action cannot be undone and may affect any workers assigned to this role.",
    btnText: "Delete",
};

interface IProductsProps { }
const Products: React.FC<IProductsProps> = () => {
    const user: IRestaurantResponse | null = useSelector((state: any) => state.auth.userData);
    const products: IProductResponse[] = useSelector((state: any) => state.product.products);
    const [tableHeader, setTableHeader] = useState<ITableHeader[]>([]);
    const [tableRows, setTableRows] = useState<any>([]);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<{ key: boolean; data: IProductResponse } | null>(null);
    const [isDelete, setIsDelete] = useState<{ key: boolean; data: IProductResponse } | null>(null);
    const dispatch = useDispatch();

    /**
     * Fetch product on component mount and set them to Redux store.
     */
    const handleLoadProducts = async () => {
        try {
            const response: IApiResponse = await productController.getProducts();
            if (response.success) dispatch(setProducts(response.data));
        } catch (error) {
            console.error("Error loading worker roles", error);
        }
    };

    /**
     * Load worker roles when user data is available.
     */
    useEffect(() => {
        if (user) {
            handleLoadProducts();
        }
    }, [user]);

    /**
     * Update table headers and rows whenever products are updated.
     */
    useEffect(() => {
        if (products.length > 0) {
            const formattedRows = getProductTableRows(products, handleEdit, handleUpdateStatus, handleDeleteModel);
            setTableHeader(productHeader);
            setTableRows(formattedRows);
        }
    }, [products, dispatch]);


    /**
     * Handle edit action for Product.
     * @param id - Product ID to be edited
     */
    const handleEdit = (id: string) => {
        const product = products.find((product) => product._id === id);
        if (product) {
            setIsEdit({ key: true, data: product });
        } else {
            alert("Product not found!");
        }
    };

   /**
 * Handle update status for Product.
 * @param id - Product ID to be update status
 */
const handleUpdateStatus = async (id: string) => {
    // Find the product by its id
    const product = products.find((product) => product._id === id);
    
    if (product) {
        // Create a copy of the product and update the status immutably
        const updatedProduct = {
            ...product,
            status: !product.status // Toggle status
        };

        // Call the update product API
        const response: any = await productController.updateProduct(updatedProduct);
        
        if (response.success) {
            // Dispatch the updated product to the store
            dispatch(updateProduct(updatedProduct));
        } else {
            alert("Product not found!");
        }
    } else {
        alert("Product not found in the local product list!");
    }
};



        /**
     * Open the delete confirmation dialog.
     * @param id - Product ID to be deleted
     */
        const handleDeleteModel = (id: string) => {
            const product = products.find((product) => product._id === id);
            if (product) {
                setIsDelete({ key: true, data: product });
            } else {
                alert("Product not found!");
            }
        };

        /**
         * Handle delete action for product.
         * Deletes the product and updates the Redux store.
         */
        const handleDelete = async () => {
            if (isDelete) {
                try {
                    const response: IApiResponse = await productController.deleteProduct(isDelete.data._id);
                    if (response.data) {
                        dispatch(deleteProduct(isDelete.data._id));
                        setIsDelete(null);
                    }
                } catch (error) {
                    console.error("Error deleting product", error);
                }
            }
        };


        // Handle opening/closing the dialog
        const handleDialogToggle = (isOpen: boolean) => {
            setIsOpen(isOpen);
            if (!isOpen) setIsEdit(null); // Reset the edit state when closing
        };

        return (
            <Container className={Styles.TableContainer}>
                {/* Add new worker role button */}
                <Flex className="pb-2" justifyContent={JustifyContent.END}>
                    <Button
                        children="Add Product"
                        className={Styles.AddMember}
                        onClick={() => handleDialogToggle(true)}
                        shape="rounded"
                        size="medium"
                        color="#ffc107"
                        appearance="primary"
                    />
                </Flex>

                {/* Table to display worker roles */}
                <Table
                    tableHeader={tableHeader}
                    tableRows={tableRows}
                    initialSort={{ key: "name", sortBy: ISort.ASC }}
                    rowsPerPage={[10, 20, 30]}
                />

                {/* Delete confirmation dialog */}
                {isDelete && (
                    <ConfirmDialog
                        isOpen={isDelete.key}
                        content={deleteProductContent}
                        handleModelClose={() => setIsDelete(null)}
                        handleConfirm={handleDelete}
                    />
                )}

                {/* Add or Edit product dialog */}
                {isOpen && <ProductForm isOpen={isOpen} onClose={() => handleDialogToggle(false)} />}
                {isEdit && <ProductForm isOpen={isEdit.key} data={isEdit.data} onClose={() => handleDialogToggle(false)} />}
            </Container>
        )

    }

    export default Products;
