import React, { useEffect, useState } from "react";
import Styles from "./Products.module.scss";
import { Button, ConfirmDialog, Container, Flex, Table } from "../../Components";
import { JustifyContent } from "../../Components/Flex/Flex";
import { IApiResponse, IProductCategoryResponse } from "../../Types";
import { useDispatch, useSelector } from "react-redux";
import { ISort, ITableHeader } from "../../Components/Table/Interface";
import { getRoleOrShiftTable } from "../../Utils/Worker/formatTable";
import { roleOrShiftHeader } from "../../Constants/TableHeader";
import productCategoryController from "../../DataProvider/Controllers/ProductCategoryController";
import { setProductCategories, deleteProductCategory, updateProductCategory } from "../../Store/Slices/productCategorySlice";
import { CategoryForm } from "../../Sections";

// Content for the delete confirmation dialog
const deleteCategoryContent = {
    header: "Delete Category",
    description: "Are you sure you want to delete this category? This action cannot be undone.",
    btnText: "Delete",
};

interface IProductCategoriesProps { }

const ProductCategories: React.FC<IProductCategoriesProps> = () => {
    const user = useSelector((state: any) => state.auth.userData); // Get user data from Redux
    const categories: IProductCategoryResponse[] = useSelector((state: any) => state.productCategory.categories);
    const [tableHeader, setTableHeader] = useState<ITableHeader[]>([]);
    const [tableRows, setTableRows] = useState<any>([]);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<{ key: boolean; data: IProductCategoryResponse } | null>(null);
    const [isDelete, setIsDelete] = useState<{ key: boolean; data: IProductCategoryResponse } | null>(null);

    const dispatch = useDispatch();

    /**
     * Fetch product categories on component mount and set them to Redux store.
     */
    const handleLoadCategories = async () => {
        try {
            if (user?._id) {
                const productCategoriesResponse: IApiResponse = await productCategoryController.getProductCategories(user?._id)
                if (productCategoriesResponse.success) dispatch(setProductCategories(productCategoriesResponse.data));
            }
        } catch (error) {
            console.error("Error loading product categories", error);
        }
    };

    /**
     * Load categories when user data is available.
     */
    useEffect(() => {
        if (user) {
            handleLoadCategories();
        }
    }, [user]);

    /**
     * Update table headers and rows whenever categories are updated.
     */
    useEffect(() => {
        const formattedRows = getRoleOrShiftTable(categories, handleEdit, handleUpdateStatus, handleDeleteModel); // Format categories for table
        setTableHeader(roleOrShiftHeader);
        setTableRows(formattedRows);
    }, [categories]);

    /**
     * Handle edit action for categories.
     * @param id - Category ID to be edited
     */
    const handleEdit = (id: string) => {
        const category = categories.find((data) => data._id === id);
        if (category) {
            setIsEdit({ key: true, data: category });
        } else {
            alert("Category not found!");
        }
    };

    /** 
     * Handle update status for Category.
     * @param id - Category ID to be update status
     */
    const handleUpdateStatus = async (id: string) => {
        // Find the category by its id
        const category = categories.find((category) => category._id === id);

        if (category) {
            // Create a copy of the category and update the status immutably
            const updatedCategory = {
                ...category,
                status: !category.status // Toggle status
            };

            // Call the update category API
            const response: any = await productCategoryController.updateProductCategory(updatedCategory);

            if (response.success) {
                // Dispatch the updated category to the store
                dispatch(updateProductCategory(updatedCategory));
            } else {
                alert("Category not found!");
            }
        } else {
            alert("Product not found in the local category list!");
        }
    };


    /**
     * Handle delete action for categories.
     * Deletes the category and updates the Redux store.
     */
    const handleDelete = async () => {
        if (isDelete) {
            try {
                const response: IApiResponse = await productCategoryController.deleteProductCategory(isDelete.data._id);
                if (response.data) {
                    dispatch(deleteProductCategory(isDelete.data._id));
                    setIsDelete(null);
                }
            } catch (error) {
                console.error("Error deleting category", error);
            }
        }
    };

    /**
     * Open the delete confirmation dialog.
     * @param id - Category ID to be deleted
     */
    const handleDeleteModel = (id: string) => {
        const category = categories.find((data) => data._id === id);
        if (category) {
            setIsDelete({ key: true, data: category });
        } else {
            alert("Category not found!");
        }
    };

    /**
     * Toggle the form dialog (Add/Edit).
     * @param isOpen - Whether the form dialog is open or closed
     */
    const handleDialogToggle = (isOpen: boolean) => {
        setIsOpen(isOpen);
        if (!isOpen) setIsEdit(null); // Reset the edit state when closing
    };

    return (
        <Container className={Styles.TableContainer}>
            {/* Add new category button */}
            <Flex className="pb-2" justifyContent={JustifyContent.END}>
                <Button
                    children="Add Category"
                    className={Styles.AddMember}
                    onClick={() => handleDialogToggle(true)}
                    shape="rounded"
                    size="medium"
                    color="#ffc107"
                    appearance="primary"
                />
            </Flex>

            {/* Table to display product categories */}
            <Table
                tableHeader={tableHeader}
                tableRows={tableRows}
                initialSort={{ key: "displayName", sortBy: ISort.ASC }} // Sort by displayName or any other key
                rowsPerPage={[10, 20, 30]}
            />

            {/* Delete confirmation dialog */}
            {isDelete && (
                <ConfirmDialog
                    isOpen={isDelete.key}
                    content={deleteCategoryContent}
                    handleModelClose={() => setIsDelete(null)}
                    handleConfirm={handleDelete}
                />
            )}

            {/* Add or Edit category dialog */}
            {isOpen && <CategoryForm isOpen={isOpen} onClose={() => handleDialogToggle(false)} />}
            {isEdit && <CategoryForm isOpen={isEdit.key} data={isEdit.data} onClose={() => handleDialogToggle(false)} />}
        </Container>
    );
};

export default ProductCategories;
