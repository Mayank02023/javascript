import cssStyles from "./Dashboard.module.scss";
import { Container } from "../../Components";
import { OrdersStatus } from "../../Sections";
import Flex, { AlignItems } from "../../Components/Flex/Flex";

const Dashboard = () => {
    return (
        <Container className={cssStyles.DashboardContainer}>
            <Flex className="gap-1 md:gap-2 lg:gap-3 xl:gap-4 bg-[#eff3f4]" alignItems={AlignItems.START}>
                <div className="w-full ">
                    <OrdersStatus />
                </div>
            </Flex>
        </Container>
    )
}

export default Dashboard;