import Login from "./Auth/Login";
import SignUp from "./Auth/SignUp";
import Dashboard from "./Dashboard";
import Order from "./Order";
import OrderStatuses from "./Order/OrderStatuses";
import Products from "./Products";
import ProductCategories from "./Products/Categories";
import Worker from "./Worker";
import WorkerRoles from "./Worker/Roles";
import WorkerShifts from "./Worker/Shifts";
import Profile from "./Profile";

export {
    Login,
    SignUp,
    Dashboard,
    Worker,
    WorkerRoles,
    WorkerShifts,
    Products,
    ProductCategories,
    Order,
    OrderStatuses,
    Profile
}