import React, { useEffect, useState } from 'react';
import jsPDF from 'jspdf';
import logo from './logo.png'; // Adjust this path based on your project structure

// Define types for the order and items
interface OrderItem {
    name: string;
    quantity: number;
    price: number;
}

interface Order {
    customerName: string;
    tableNumber: number;
    items: OrderItem[];
    totalAmount: number;
}

const PdfPreview: React.FC = () => {
    const [pdfUrl, setPdfUrl] = useState<string | null>(null);

    const staticOrder: Order = {
        customerName: 'Prince Kurmi',
        tableNumber: 10,
        items: [
            { name: 'Grilled Chicken Sandwich', quantity: 1, price: 150 },
            { name: 'Caesar Salad', quantity: 2, price: 100 },
            { name: 'Mango Smoothie', quantity: 1, price: 80 },
        ],
        totalAmount: 430,
    };

    const generatePDFReceipt = async () => {
        const doc = new jsPDF({
            orientation: 'portrait',
            unit: 'pt',
            format: [288, 432],
            hotfixes: ['pxScaling'], // ensures that scaling works properly
        });

        // Add logo to PDF
        const img = new Image();
        img.src = logo; // Load the logo image

        img.onload = () => {
            // Draw the logo in the PDF
            doc.addImage(img, 'PNG', 10, 10, 50, 50); // Adjust position and size as needed

            // Add receipt header
            doc.setFontSize(14);
            doc.setFont("helvetica", "bold");
            doc.text('My Restaurant', 70, 20);
            doc.setFontSize(10);
            doc.setFont("helvetica", "normal");
            doc.text(`Table No: ${staticOrder.tableNumber}`, 190, 60);
            doc.setFont("helvetica", "bold");
            doc.text(`Customer: `, 158, 40);
            doc.text(staticOrder.customerName, 210, 40);

            doc.line(10, 110, 278, 110); // Line below header

            // Add table header
            doc.setFont("helvetica", "bold");
            doc.text('Name', 10, 125);
            doc.text('Quantity', 180, 125);
            doc.text('Price', 240, 125);
            doc.line(10, 135, 278, 135); // Line below header

            // Add items in table format
            doc.setFont("helvetica", "normal");
            staticOrder.items.forEach((item, index) => {
                const yPos = 145 + index * 20;
                doc.text(item.name, 10, yPos);
                doc.text(item.quantity.toString(), 180, yPos);
                doc.text(`${(item.price * item.quantity).toFixed(2)}`, 240, yPos);
            });

            doc.line(10, 145 + staticOrder.items.length * 20, 278, 145 + staticOrder.items.length * 20); // Line below items
            doc.setFont("helvetica", "bold");
            doc.text(`Total:`, 10, 145 + staticOrder.items.length * 20 + 15);
            doc.text(staticOrder.totalAmount.toFixed(2), 240, 145 + staticOrder.items.length * 20 + 15);

            doc.line(10, 145 + staticOrder.items.length * 20 + 25, 278, 145 + staticOrder.items.length * 20 + 25); // Line below total
            doc.setFont("helvetica", "normal");
            doc.text('Thank you for your order!', 144, 145 + staticOrder.items.length * 20 + 40, { align: 'center' });

            // Save PDF to a Blob
            const pdfBlob = doc.output('blob');
            const url = URL.createObjectURL(pdfBlob);
            setPdfUrl(url);
        };
    };

    useEffect(() => {
        generatePDFReceipt();
    }, []);

    return (
        <div>
            {pdfUrl ? (
                <iframe
                    title="PDF Preview"
                    src={pdfUrl}
                    width="100%"
                    height="600px"
                    style={{ border: 'none' }}
                />
            ) : (
                <p>Loading PDF...</p>
            )}
        </div>
    );
};

export default PdfPreview;
