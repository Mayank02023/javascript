import React, { useEffect, useState } from "react";
import Styles from "./Order.module.scss";
import { Button, ConfirmDialog, Container, Flex, Table } from "../../Components";
import { JustifyContent } from "../../Components/Flex/Flex";
import { IApiResponse, IOrderStatusResponse } from "../../Types";
import { useDispatch, useSelector } from "react-redux";
import { ISort, ITableHeader } from "../../Components/Table/Interface";
import orderStatusController from "../../DataProvider/Controllers/OrderStatusController";
import { deleteOrderStatus, setOrderStatuses, updateOrderStatus } from "../../Store/Slices/orderStatusSlice";
import { roleOrShiftHeader } from "../../Constants/TableHeader";
import { getOrderStatusTable } from "../../Utils/table";

// Content for the delete confirmation dialog
const deleteStatusContent = {
    header: "Delete Order Status",
    description: "Are you sure you want to delete this order orderStatus? This action cannot be undone and may affect existing orders.",
    btnText: "Delete",
};

interface IOrderStatusProps { }

const OrderStatuses: React.FC<IOrderStatusProps> = () => {
    const user = useSelector((state: any) => state.auth.userData);
    const orderStatuses: IOrderStatusResponse[] = useSelector((state: any) => state.orderStatuses.orderStatuses);
    const [tableHeader, setTableHeader] = useState<ITableHeader[]>([]);
    const [tableRows, setTableRows] = useState<any>([]);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<{ key: boolean; data: IOrderStatusResponse } | null>(null);
    const [isDelete, setIsDelete] = useState<{ key: boolean; data: IOrderStatusResponse } | null>(null);

    const dispatch = useDispatch();

    /**
     * Fetch order orderStatuses on component mount and set them to Redux store.
     */
    const handleLoadStatuses = async () => {
        try {
            debugger;
            const response: IApiResponse = await orderStatusController.getOrderStatuses();
            if (response.success) dispatch(setOrderStatuses(response.data));
        } catch (error) {
            console.error("Error loading order orderStatuses", error);
        }
    };

    /**
     * Load order orderStatuses when user data is available.
     */
    useEffect(() => {
        if (user) {
            handleLoadStatuses();
        }
    }, [user]);

    /**
     * Update table headers and rows whenever order orderStatuses are updated.
     */
    useEffect(() => {
        const formattedRows = getOrderStatusTable(
            orderStatuses,
            handleEdit,
            handleUpdateStatus,
            handleDeleteModel
        );
        setTableHeader(roleOrShiftHeader);
        setTableRows(formattedRows);
    }, [orderStatuses]);

    /**
     * Handle edit action for order orderStatuses.
     */
    const handleEdit = (id: string) => {
        const orderStatus = orderStatuses.find((data) => data._id === id);
        if (orderStatus) {
            setIsEdit({ key: true, data: orderStatus });
        } else {
            alert("Order orderStatus not found!");
        }
    };

    /** 
     * Handle update orderStatus for an order orderStatus.
     */
    const handleUpdateStatus = async (id: string) => {
        const orderStatus = orderStatuses.find((orderStatus) => orderStatus._id === id);
        if (orderStatus) {
            const updatedStatus: IOrderStatusResponse = {
                ...orderStatus,
                status: !orderStatus.status, // Toggle active orderStatus
            };

            const response: IApiResponse = await orderStatusController.updateOrderStatus(updatedStatus);
            if (response.success) {
                dispatch(updateOrderStatus(updatedStatus));
            } else {
                alert("Failed to update order orderStatus!");
            }
        } else {
            alert("Order orderStatus not found in the list!");
        }
    };

    /**
     * Handle delete action for order orderStatuses.
     */
    const handleDelete = async () => {
        if (isDelete) {
            try {
                const response: IApiResponse = await orderStatusController.deleteOrderStatus(isDelete.data._id);
                if (response.success) {
                    dispatch(deleteOrderStatus(isDelete.data._id));
                    setIsDelete(null);
                }
            } catch (error) {
                console.error("Error deleting order orderStatus", error);
            }
        }
    };

    /**
     * Open the delete confirmation dialog.
     */
    const handleDeleteModel = (id: string) => {
        const orderStatus = orderStatuses.find((data) => data._id === id);
        if (orderStatus) {
            setIsDelete({ key: true, data: orderStatus });
        } else {
            alert("Order orderStatus not found!");
        }
    };

    /**
     * Toggle the form dialog (Add/Edit).
     */
    const handleDialogToggle = (isOpen: boolean) => {
        setIsOpen(isOpen);
        if (!isOpen) setIsEdit(null);
    };

    return (
        <Container className={Styles.TableContainer}>
            <Flex className="pb-2" justifyContent={JustifyContent.END}>
                <Button
                    children="Add Status"
                    className={Styles.AddMember}
                    onClick={() => handleDialogToggle(true)}
                    shape="rounded"
                    size="medium"
                    color="#ffc107"
                    appearance="primary"
                />
            </Flex>

            <Table
                tableHeader={tableHeader}
                tableRows={tableRows}
                initialSort={{ key: "name", sortBy: ISort.ASC }}
                rowsPerPage={[10, 20, 30]}
            />

            {isDelete && (
                <ConfirmDialog
                    isOpen={isDelete.key}
                    content={deleteStatusContent}
                    handleModelClose={() => setIsDelete(null)}
                    handleConfirm={handleDelete}
                />
            )}

            {/* {isOpen && <StatusForm isOpen={isOpen} onClose={() => handleDialogToggle(false)} />}
            {isEdit && (
                <StatusForm
                    isOpen={isEdit.key}
                    data={isEdit.data}
                    onClose={() => handleDialogToggle(false)}
                />
            )} */}
        </Container>
    );
};

export default OrderStatuses;
