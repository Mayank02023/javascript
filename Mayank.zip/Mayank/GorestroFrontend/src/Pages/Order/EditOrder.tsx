// src/Pages/EditOrder/EditOrder.tsx

import React, { useEffect, useState } from "react";
import cssStyles from "./Order.module.scss";
import { CategoryCard, Container, ProductCard } from "../../Components";
import { useDispatch, useSelector } from "react-redux";
import {
    IApiResponse,
    IAuthResponse,
    IOrderResponse,
    IProductCategoryResponse,
    IProductResponse,
} from "../../Types";
import productController from "../../DataProvider/Controllers/ProductController";
import productCategoryController from "../../DataProvider/Controllers/ProductCategoryController";
import { setAvailableProducts } from "../../Store/Slices/productSlice";
import { setProductCategories } from "../../Store/Slices/productCategorySlice";
import Flex, { AlignItems } from "../../Components/Flex/Flex";
import { PaymentSummary } from "../../Sections";
import { useParams } from "react-router-dom";
import orderController from "../../DataProvider/Controllers/OrdersController";
import { updateCurrentOrder, resetCurrentOrder } from "../../Store/Slices/orderSlice";
import { IOrderItemResponse } from "../../Types/order";
import { initialCurrentOrderState } from "../../Utils/Orders";

interface IEditOrderProps { }

const EditOrder: React.FC<IEditOrderProps> = () => {
    const dispatch = useDispatch();
    const { id } = useParams();
    const user: IAuthResponse = useSelector((state: any) => state.auth);


    const categories: IProductCategoryResponse[] = useSelector(
        (state: any) => state.productCategory.categories
    );
    const products: IProductResponse[] = useSelector(
        (state: any) => state.product.availableProducts
    );

    const [order, setOrder] = useState<IOrderResponse>(useSelector((state: any) => state.orders.currentOrder));

    // State to track the selected category
    const [selectedCategory, setSelectedCategory] = useState<{ id: string; displayName: string } | null>(null);

    // Fetch categories and products data
    useEffect(() => {
        const loadData = async () => {
            try {
                if (user?.userData?._id && (!categories || categories.length === 0)) {
                    const productCategoriesResponse: IApiResponse = await productCategoryController.getProductCategories(
                        user?.userData?._id
                    );
                    if (productCategoriesResponse.success)
                        dispatch(setProductCategories(productCategoriesResponse.data));
                }

                if (user.userData?._id && (!products || products.length === 0)) {
                    const productResponse: IApiResponse = await productController.getAvailableProducts(user.userData?._id);
                    if (productResponse.success) {
                        dispatch(setAvailableProducts(productResponse.data));
                    }
                }
            } catch (error) {
                console.error("Error loading data", error);
            }
        };

        loadData();
    }, [categories, products, id, dispatch, user?.userData?._id]);

    // Fetch order data if in "edit" mode or reset if in "add" mode
    useEffect(() => {
        const loadOrderData = async () => {
            if (id && order._id !== id) {
                try {
                    const orderResponse: IApiResponse = await orderController.getOrder(id);
                    if (orderResponse.success) {
                        dispatch(updateCurrentOrder(orderResponse.data));
                        setOrder(orderResponse.data); // Set order state for editing
                    } else {
                        console.error("Failed to retrieve order:", orderResponse.message);
                    }
                } catch (error) {
                    console.error("Unexpected error fetching order:", error);
                }
            } else {
                dispatch(resetCurrentOrder());
                setOrder(initialCurrentOrderState); // Reset order state for adding a new order
            }
        };

        loadOrderData();
    }, [id, dispatch]);

    // Synchronize local order state with Redux store when currentOrder changes
    useEffect(() => {
        if (id && order._id) {
            setOrder(order);
        }
    }, [dispatch, id]);

    // Filter products based on the selected category
    const filteredProducts = selectedCategory
        ? products.filter((product) => product.category.id === selectedCategory.id)
        : products;

    // Handle quantity change
    const handleQuantityChange = (quantity: number, productId: string) => {
        setOrder(prevOrder => {
            const productExists = prevOrder.items.some(item => item.productId === productId);
            let updatedItems = prevOrder.items
                .map(item => {
                    if (item.productId === productId && quantity > 0) {
                        return { ...item, quantity };
                    }
                    return item;
                })
                .filter(item => item.productId !== productId || quantity > 0);

            if (!productExists && quantity > 0) {
                const product = products.find(product => product._id === productId);
                if (product) {
                    const newItem: IOrderItemResponse = {
                        productId: product._id,
                        avatar: product.avatar,
                        quantity,
                        price: product.price,
                        displayName: product.displayName,
                    };
                    updatedItems.push(newItem);
                }
            }

            return { ...prevOrder, items: updatedItems };
        });
    };

    return (
        <Container className={cssStyles.DashboardContainer}>
            <Flex className="gap-1 md:gap-2 lg:gap-3 xl:gap-4 bg-[#eff3f4]" alignItems={AlignItems.START}>
                <div className="w-[75%]">
                    <div className="grid grid-cols-5 gap-4 w-full">
                        <CategoryCard
                            key={`All`}
                            isActive={!selectedCategory}
                            data={{
                                id: "all",
                                headerTitle: "All",
                                items: products.length,
                            }}
                            onClick={() => setSelectedCategory(null)}
                        />
                        {categories.length > 0 ? (
                            categories.map((category) => (
                                <CategoryCard
                                    key={category._id}
                                    isActive={selectedCategory?.id === category._id}
                                    data={{
                                        id: category._id,
                                        headerTitle: category.displayName,
                                        items: products.filter((product) => product.category.id === category._id).length,
                                    }}
                                    onClick={() => setSelectedCategory({
                                        id: category._id,
                                        displayName: category.displayName,
                                    })}
                                />
                            ))
                        ) : (
                            <p>No categories available.</p>
                        )}
                    </div>
                    <h1 className="text-3xl font-semibold text-black py-4">
                        {`${selectedCategory?.displayName || "All"} Menu`}
                    </h1>

                    <div className="grid grid-cols-4 gap-4 w-full">
                        {filteredProducts.length > 0 ? (
                            filteredProducts.map((product) => {
                                const item: IOrderItemResponse | undefined = order?.items?.find(
                                    (item) => item.productId === product._id
                                );
                                const isSelected = !!item;
                                const quantity = item ? item.quantity : 0;

                                return (
                                    <ProductCard
                                        key={product._id}
                                        product={product}
                                        quantity={quantity}
                                        handleQuantity={handleQuantityChange}
                                        isSelected={isSelected}
                                    />
                                );
                            })
                        ) : (
                            <p>No products available for this category.</p>
                        )}
                    </div>
                </div>
                <div className="w-[25%]">
                    {order && order.items ? (
                        <PaymentSummary
                            handleQuantity={handleQuantityChange}
                            order={order}
                        />
                    ) : (
                        <p>No order items available.</p>
                    )}
                </div>
            </Flex>
        </Container>
    );
};

export default EditOrder;
