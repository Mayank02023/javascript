import React, { useEffect, useMemo, useState, useCallback } from "react";
import cssStyles from "./Order.module.scss";
import { ConfirmDialog, Container, Table } from "../../Components";
import { IOrderResponse } from "../../Types/order";
import { useDispatch, useSelector } from "react-redux";
import { IApiResponse, IAuthResponse } from "../../Types";
import orderController from "../../DataProvider/Controllers/OrdersController";
import { deleteOrder, setOrders, updateCurrentOrder, updateOrder } from "../../Store/Slices/orderSlice";
import { getOrderTableRows } from "../../Utils/table";
import { ISort } from "../../Components/Table/Interface";
import { orderHeader } from "../../Constants/TableHeader";
import { useNavigate } from "react-router-dom";

const deleteOrderContent = {
    header: "Delete Order",
    description: "Are you sure you want to delete this order? This action cannot be undone and may affect any workers assigned to this role.",
    btnText: "Delete",
};

const Order: React.FC = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const user: IAuthResponse = useSelector((state: any) => state.auth);
    const orders: IOrderResponse[] = useSelector((state: any) => state.orders.orders);    
    const [isDelete, setIsDelete] = useState<{ key: boolean; data: IOrderResponse } | null>(null);

    useEffect(() => {
        const loadOrders = async () => {
            try {
                if (user.userData?._id && orders.length === 0) {
                    orderController.getOrders(user.userData._id).then((response: IApiResponse) => {
                        if (response.success) dispatch(setOrders(response.data));
                    });
                }
            } catch (error) {
                console.error("Error loading orders", error);
            }
        };
        loadOrders();
    }, []);

    const findOrderById = useCallback(
        (id: string) => orders.find((order) => order._id === id),
        [orders]
    );

    const handleEdit = useCallback(
        (id: string) => {
            const order = findOrderById(id);
            if (order) {
                dispatch(updateCurrentOrder(order));
                navigate(`/edit-order/${id}`);
            } else {
                alert("Order not found!");
            }
        },
        [findOrderById, dispatch, navigate]
    );

    const handleUpdateStatus = useCallback(
        async (id: string, status: { id: string; displayName: string }) => {
            const order = findOrderById(id);
            if (order) {
                const updatedOrder = { ...order, status };
                const response: any = await orderController.updateOrder({ _id: order._id, statusId: status.id });

                if (response.success) {
                    dispatch(updateOrder(updatedOrder));
                } else {
                    alert("Failed to update the order status.");
                }
            } else {
                alert("Order not found!");
            }
        },
        [findOrderById, dispatch]
    );

    const handleDeleteModel = useCallback(
        (id: string) => {
            const order = findOrderById(id);
            if (order) {
                setIsDelete({ key: true, data: order });
            } else {
                alert("Order not found!");
            }
        },
        [findOrderById]
    );

    const handleDelete = useCallback(async () => {
        if (isDelete) {
            try {
                const response: IApiResponse = await orderController.deleteOrder(isDelete.data._id);
                if (response.success) {
                    dispatch(deleteOrder(isDelete.data._id));
                    setIsDelete(null);
                } else {
                    console.error("Failed to delete the order");
                }
            } catch (error) {
                console.error("Error deleting order", error);
            }
        }
    }, [isDelete, dispatch]);

    const tableRows = useMemo(
        () => getOrderTableRows(orders, handleEdit, handleUpdateStatus, handleDeleteModel),
        [orders, handleEdit, handleUpdateStatus, handleDeleteModel]
    );

    return (
        <Container className={cssStyles.DashboardContainer}>
            {orders.length > 0 ? (
                <Table
                    className={cssStyles.OrderTable}
                    tableHeader={orderHeader}
                    tableRows={tableRows}
                    initialSort={{ key: "customerName", sortBy: ISort.ASC }}
                    rowsPerPage={[10, 20, 30]}
                />
            ) : (
                <p>No orders available.</p>
            )}

            {isDelete && (
                <ConfirmDialog
                    isOpen={isDelete.key}
                    content={deleteOrderContent}
                    handleModelClose={() => setIsDelete(null)}
                    handleConfirm={handleDelete}
                />
            )}
        </Container>
    );
};

export default Order;
