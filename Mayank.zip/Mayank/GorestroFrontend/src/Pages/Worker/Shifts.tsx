import React, { useEffect, useState } from "react";
import Styles from "./Worker.module.scss";
import { Button, ConfirmDialog, Container, Flex, Table } from "../../Components";
import { JustifyContent } from "../../Components/Flex/Flex";
import { IApiResponse, IRestaurantResponse, IWorkerRoleResponse } from "../../Types";
import { useDispatch, useSelector } from "react-redux";
import { ISort, ITableHeader } from "../../Components/Table/Interface";
import { getRoleOrShiftTable } from "../../Utils/Worker/formatTable";
import { roleOrShiftHeader } from "../../Constants/TableHeader";
import { ShiftForm } from "../../Sections"; // Shift form
import workerShiftController from "../../DataProvider/Controllers/WorkerShiftsController";
import { setWorkerShift, deleteWorkerShift, updateWorkerShift } from "../../Store/Slices/workerShiftSlice";

// Content for the delete confirmation dialog
const deleteShiftContent = {
    header: "Delete Shift",
    description: "Are you sure you want to delete this shift? This action cannot be undone and may affect any workers assigned to this shift.",
    btnText: "Delete",
};

interface IWorkerShiftsProps { }

const WorkerShifts: React.FC<IWorkerShiftsProps> = () => {
    const user: IRestaurantResponse | null = useSelector((state: any) => state.auth.userData);
    const shifts: IWorkerRoleResponse[] = useSelector((state: any) => state.workerShift.workerShifts);
    const [tableHeader, setTableHeader] = useState<ITableHeader[]>([]);
    const [tableRows, setTableRows] = useState<any>([]);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<{ key: boolean; data: IWorkerRoleResponse } | null>(null);
    const [isDelete, setIsDelete] = useState<{ key: boolean; data: IWorkerRoleResponse } | null>(null);

    const dispatch = useDispatch();

    /**
     * Fetch shifts on component mount and set them to Redux store.
     */
    const handleLoadShifts = async () => {
        try {
            const response: IApiResponse = await workerShiftController.getWorkerShifts();
            if (response.success) dispatch(setWorkerShift(response.data));
        } catch (error) {
            console.error("Error loading shifts", error);
        }
    };

    /**
     * Load shifts when user data is available.
     */
    useEffect(() => {
        if (user) {
            handleLoadShifts();
        }
    }, [user]);

    /**
     * Update table headers and rows whenever shifts are updated.
     */
    useEffect(() => {
        const formattedRows = getRoleOrShiftTable(shifts, handleEdit, handleUpdateStatus, handleDeleteModel); // Handling shifts now
        setTableHeader(roleOrShiftHeader);
        setTableRows(formattedRows);
    }, [shifts]);

    /**
     * Handle edit action for shifts.
     * @param id - Shift ID to be edited
     */
    const handleEdit = (id: string) => {
        const shift = shifts.find((data) => data._id === id);
        if (shift) {
            setIsEdit({ key: true, data: shift });
        } else {
            alert("Shift not found!");
        }
    };

    /** 
     * Handle update status for Shift.
     * @param id - Shift ID to be update status
     */
    const handleUpdateStatus = async (id: string) => {
        // Find the shift by its id
        const shift = shifts.find((shift) => shift._id === id);

        if (shift) {
            // Create a copy of the shift and update the status immutably
            const updatedShift = {
                ...shift,
                status: !shift.status // Toggle status
            };

            // Call the update shift API
            const response: any = await workerShiftController.updateWorkerShift(updatedShift);

            if (response.success) {
                // Dispatch the updated shift to the store
                dispatch(updateWorkerShift(updatedShift));
            } else {
                alert("Shift not found!");
            }
        } else {
            alert("Product not found in the local shift list!");
        }
    };

    /**
     * Handle delete action for shifts.
     * Deletes the shift and updates the Redux store.
     */
    const handleDelete = async () => {
        if (isDelete) {
            try {
                const response: IApiResponse = await workerShiftController.deleteWorkerShift(isDelete.data._id);
                if (response.data) {
                    dispatch(deleteWorkerShift(isDelete.data._id));
                    setIsDelete(null);
                }
            } catch (error) {
                console.error("Error deleting shift", error);
            }
        }
    };

    /**
     * Open the delete confirmation dialog.
     * @param id - Shift ID to be deleted
     */
    const handleDeleteModel = (id: string) => {
        const shift = shifts.find((data) => data._id === id);
        if (shift) {
            setIsDelete({ key: true, data: shift });
        } else {
            alert("Shift not found!");
        }
    };

    /**
     * Toggle the form dialog (Add/Edit).
     * @param isOpen - Whether the form dialog is open or closed
     */
    const handleDialogToggle = (isOpen: boolean) => {
        setIsOpen(isOpen);
        if (!isOpen) setIsEdit(null); // Reset the edit state when closing
    };

    return (
        <Container className={Styles.TableContainer}>
            {/* Add new shift button */}
            <Flex className="pb-2" justifyContent={JustifyContent.END}>
                <Button
                    children="Add Shift"
                    className={Styles.AddMember}
                    onClick={() => handleDialogToggle(true)}
                    shape="rounded"
                    size="medium"
                    color="#ffc107"
                    appearance="primary"
                />
            </Flex>

            {/* Table to display shifts */}
            <Table
                tableHeader={tableHeader}
                tableRows={tableRows}
                initialSort={{ key: "name", sortBy: ISort.ASC }}
                rowsPerPage={[10, 20, 30]}
            />

            {/* Delete confirmation dialog */}
            {isDelete && (
                <ConfirmDialog
                    isOpen={isDelete.key}
                    content={deleteShiftContent}
                    handleModelClose={() => setIsDelete(null)}
                    handleConfirm={handleDelete}
                />
            )}

            {/* Add or Edit shift dialog */}
            {isOpen && <ShiftForm isOpen={isOpen} onClose={() => handleDialogToggle(false)} />}
            {isEdit && <ShiftForm isOpen={isEdit.key} data={isEdit.data} onClose={() => handleDialogToggle(false)} />}
        </Container>
    );
};

export default WorkerShifts;
