import { Button, Container, Flex, Table } from "../../Components";
import Styles from "../Dashboard/Dashboard.module.scss";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { WorkerForm } from "../../Sections";
import { getFormattedWorkerTable } from "../../Utils/Worker/formatTable";
import { workerHeader } from "../../Constants/TableHeader";
import { IApiResponse, IRestaurantResponse, IWorkerResponse, IWorkerRoleResponse } from "../../Types";
import workerController from "../../DataProvider/Controllers/WorkerController";
import { setWorker } from "../../Store/Slices/workerSlice";
import { ISort, ITableHeader } from "../../Components/Table/Interface";
import { JustifyContent } from "../../Components/Flex/Flex";

interface IWorkerProps { }

const Worker: React.FC<IWorkerProps> = () => {
    const user: IRestaurantResponse | null = useSelector((state: any) => state.auth.userData);
    const workers: IWorkerResponse[] = useSelector((state: any) => state.worker.workers);
    const [tableHeader, setTableHeader] = useState<ITableHeader[]>([]);
    const [tableRows, setTableRows] = useState<any>([]);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<{ key: boolean; data: IWorkerResponse } | null>(null);

    const dispatch = useDispatch();

    // Load workers on component mount
    const handleLoadWorkers = async () => {
        try {
            const response: IApiResponse = await workerController.getWorkers();
            if (response.success) dispatch(setWorker(response.data));
        } catch (error) {
            console.error("Error loading workers", error);
        }
    };


    // Load workers when user is present
    useEffect(() => {
        if (user) {
            handleLoadWorkers();
        }
    }, [user]);

    // Update table rows and headers when workers change
    useEffect(() => {
        const formattedRows = getFormattedWorkerTable(workers, handleEdit, handleDelete);
        setTableHeader(workerHeader);
        setTableRows(formattedRows);
    }, [workers]);

    // Handle edit button click
    const handleEdit = (id: string) => {
        const worker = workers.find((data: any) => data._id === id);
        if (worker) {
            setIsEdit({ key: true, data: worker });
        } else {
            alert("Worker not found!");
        }
    };

    // Handle delete button click (add delete logic)
    const handleDelete = (id: string) => {
        // Add delete logic here
        console.log("Delete worker with id:", id);
    };

    // Handle opening/closing the dialog
    const handleDialogToggle = (isOpen: boolean) => {
        setIsOpen(isOpen);
        if (!isOpen) setIsEdit(null); // Reset the edit state when closing
    };

    return (
        <Container className={Styles.TeamsTable}>
            <Flex className="pb-2" justifyContent={JustifyContent.END}>
                <Button
                    children="Add Member"
                    className={Styles.AddMember}
                    onClick={() => handleDialogToggle(true)}
                    shape="rounded"
                    size="medium"
                    color="#ffc107"
                    appearance="primary"
                />
            </Flex>

            <Table
                tableHeader={tableHeader}
                tableRows={tableRows}
                initialSort={{ key: "name", sortBy: ISort.ASC }}
                rowsPerPage={[10, 20, 30]}
            />

            {/* Add Worker dialog */}
            {isOpen && <WorkerForm isOpen={isOpen} onClose={() => handleDialogToggle(false)} />}
            {isEdit && <WorkerForm isOpen={isEdit.key} data={isEdit.data} onClose={() => handleDialogToggle(false)} />}
        </Container>
    );
};

export default Worker;
