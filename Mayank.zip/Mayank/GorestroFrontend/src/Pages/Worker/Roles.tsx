import React, { useEffect, useState } from "react";
import Styles from "./Worker.module.scss";
import { Button, ConfirmDialog, Container, Flex, Table } from "../../Components";
import { JustifyContent } from "../../Components/Flex/Flex";
import { IApiResponse, IRestaurantResponse, IWorkerRoleResponse } from "../../Types";
import { useDispatch, useSelector } from "react-redux";
import { ISort, ITableHeader } from "../../Components/Table/Interface";
import workerRoleController from "../../DataProvider/Controllers/WorkerRolesController";
import { deleteWorkerRole, setWorkerRole, updateWorkerRole } from "../../Store/Slices/workerRoleSlice";
import { getRoleOrShiftTable } from "../../Utils/Worker/formatTable";
import { roleOrShiftHeader } from "../../Constants/TableHeader";
import { RoleForm } from "../../Sections";

// Content for the delete confirmation dialog
const deleteRoleContent = {
    header: "Delete Worker Role",
    description: "Are you sure you want to delete this worker role? This action cannot be undone and may affect any workers assigned to this role.",
    btnText: "Delete",
};

interface IWorkerRolesProps { }

const WorkerRoles: React.FC<IWorkerRolesProps> = () => {
    const user: IRestaurantResponse | null = useSelector((state: any) => state.auth.userData);
    const roles: IWorkerRoleResponse[] = useSelector((state: any) => state.workerRole.workerRoles);
    const [tableHeader, setTableHeader] = useState<ITableHeader[]>([]);
    const [tableRows, setTableRows] = useState<any>([]);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<{ key: boolean; data: IWorkerRoleResponse } | null>(null);
    const [isDelete, setIsDelete] = useState<{ key: boolean; data: IWorkerRoleResponse } | null>(null);

    const dispatch = useDispatch();

    /**
     * Fetch worker roles on component mount and set them to Redux store.
     */
    const handleLoadRoles = async () => {
        try {
            const workerRoleResponse: IApiResponse = await workerRoleController.getWorkerRoles();
            if (workerRoleResponse.success) dispatch(setWorkerRole(workerRoleResponse.data));
        } catch (error) {
            console.error("Error loading worker roles", error);
        }
    };

    /**
     * Load worker roles when user data is available.
     */
    useEffect(() => {
        if (user) {
            handleLoadRoles();
        }
    }, [user]);

    /**
     * Update table headers and rows whenever worker roles are updated.
     */
    useEffect(() => {
        const formattedRows = getRoleOrShiftTable(roles, handleEdit, handleUpdateStatus, handleDeleteModel);
        setTableHeader(roleOrShiftHeader);
        setTableRows(formattedRows);
    }, [roles]);

    /**
     * Handle edit action for worker roles.
     * @param id - Worker role ID to be edited
     */
    const handleEdit = (id: string) => {
        const role = roles.find((data) => data._id === id);
        if (role) {
            setIsEdit({ key: true, data: role });
        } else {
            alert("Worker role not found!");
        }
    };

    /** 
         * Handle update status for Role.
         * @param id - Role ID to be update status
         */
    const handleUpdateStatus = async (id: string) => {
        // Find the role by its id
        const role = roles.find((role) => role._id === id);

        if (role) {
            // Create a copy of the role and update the status immutably
            const updatedRole = {
                ...role,
                status: !role.status // Toggle status
            };

            // Call the update role API
            const response: any = await workerRoleController.updateWorkerRole(updatedRole);

            if (response.success) {
                // Dispatch the updated role to the store
                dispatch(updateWorkerRole(updatedRole));
            } else {
                alert("Role not found!");
            }
        } else {
            alert("Role not found in the local role list!");
        }
    };


    /**
     * Handle delete action for worker roles.
     * Deletes the worker role and updates the Redux store.
     */
    const handleDelete = async () => {
        if (isDelete) {
            try {
                const response: IApiResponse = await workerRoleController.deleteWorkerRole(isDelete.data._id);
                if (response.data) {
                    dispatch(deleteWorkerRole(isDelete.data._id));
                    setIsDelete(null);
                }
            } catch (error) {
                console.error("Error deleting worker role", error);
            }
        }
    };

    /**
     * Open the delete confirmation dialog.
     * @param id - Worker role ID to be deleted
     */
    const handleDeleteModel = (id: string) => {
        const role = roles.find((data) => data._id === id);
        if (role) {
            setIsDelete({ key: true, data: role });
        } else {
            alert("Worker role not found!");
        }
    };

    /**
     * Toggle the form dialog (Add/Edit).
     * @param isOpen - Whether the form dialog is open or closed
     */
    const handleDialogToggle = (isOpen: boolean) => {
        setIsOpen(isOpen);
        if (!isOpen) setIsEdit(null); // Reset the edit state when closing
    };

    return (
        <Container className={Styles.TableContainer}>
            {/* Add new worker role button */}
            <Flex className="pb-2" justifyContent={JustifyContent.END}>
                <Button
                    children="Add Role"
                    className={Styles.AddMember}
                    onClick={() => handleDialogToggle(true)}
                    shape="rounded"
                    size="medium"
                    color="#ffc107"
                    appearance="primary"
                />
            </Flex>

            {/* Table to display worker roles */}
            <Table
                tableHeader={tableHeader}
                tableRows={tableRows}
                initialSort={{ key: "name", sortBy: ISort.ASC }}
                rowsPerPage={[10, 20, 30]}
            />

            {/* Delete confirmation dialog */}
            {isDelete && (
                <ConfirmDialog
                    isOpen={isDelete.key}
                    content={deleteRoleContent}
                    handleModelClose={() => setIsDelete(null)}
                    handleConfirm={handleDelete}
                />
            )}

            {/* Add or Edit worker role dialog */}
            {isOpen && <RoleForm isOpen={isOpen} onClose={() => handleDialogToggle(false)} />}
            {isEdit && <RoleForm isOpen={isEdit.key} data={isEdit.data} onClose={() => handleDialogToggle(false)} />}
        </Container>
    );
};

export default WorkerRoles;
