import React from "react";
import Styles from "./Profile.module.scss";
import { Container } from "../../Components";
import { RestroAccount, RestroAddress, RestroDetails, RestroPersonalDetails } from "../../Sections";

interface IProfileProps { }

const Profile: React.FC<IProfileProps> = (props) => {
    return (
        <Container className={Styles.ProfileContainer}>
            <RestroDetails />
            <div className="flex justify-between items-stretch w-full mt-3 gap-3 h-auto">
                {/* Left column: RestroPersonalDetails */}
                <div className="flex flex-col w-1/2 h-[inherit]">
                    <RestroPersonalDetails />
                </div>

                {/* Right column: RestroAddress and RestroAccount */}
                <div className="flex flex-col w-1/2 gap-3  h-[inherit]">
                    <RestroAddress />
                    <RestroAccount />
                </div>

            </div>
        </Container>
    );
};

export default Profile;
