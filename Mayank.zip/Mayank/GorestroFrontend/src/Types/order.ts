export interface IOrderStatusCard {
    id?: string;
    username?: string;
    tableNo?: number;
    items?: number;
    amount?: string;
    status?: string;
    acceptedBy: string;
}
export interface IOrderItemRequest {
    productId: string;
    price: number;
    quantity: number;
}

export interface IOrderRequest {
    id?: string;
    statusId: string;
    items: IOrderItemRequest[];
    customerName: string;
    customerNumber: string;
    tableNumber: number;
    totalAmount: number;
}

export interface IOrderItemRequestError {
    productId: string;
    price: string;
    quantity: string;
}

export interface IOrderRequestError {
    _id?: string;
    statusId: string;
    items: IOrderItemRequestError[];
    customerName: string;
    customerNumber: string;
    tableNumber: string;
    totalAmount: string;
}
export interface IOrderItemResponse {
    productId: string;
    price: number;
    quantity: number;
    displayName: string;
    avatar: string;
}

export interface IOrderResponse {
    _id: string;
    restroId: string;
    status: {
        id: string;
        displayName: string;
    };
    acceptedBy: {
        id?: string;
        displayName?: string;
    }
    customerName: string;
    customerNumber: string;
    tableNumber: number;
    totalAmount: number;
    items: IOrderItemResponse[];
    createdAt: string;
    updatedAt: string;
}

export interface IOrderStatusResponse {
    _id: string;
    restroId: string;
    displayName: string;
    status: boolean;
    createdAt: string;
    updatedAt: string;
}

export interface IOrderStatusRequest {
    _id: string;
    displayName: string;
}


export interface IOrderStatusCardForDashboard {
    id: string;
    onClick: () => void; // Function to be executed onClick
    progress: {
        isUp: boolean; // Indicates whether today’s count is greater than yesterday’s
        value: number; // Yesterday’s order count
    };
    headerTitle: string; // Title displayed on the card (status display name)
    contentTitle: number; // Today’s order count as a string
}
