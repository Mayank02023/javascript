import { IRestaurantResponse } from "./restaurant";
export interface ILoginState {
    username: string;
    password: string;
}

export interface IAuthResponse {
    status: boolean;
    userData: IRestaurantResponse | null;
    accessToken: string | null;
    refreshToken: string | null;
}