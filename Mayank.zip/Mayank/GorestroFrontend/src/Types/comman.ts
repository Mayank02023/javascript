export interface IIconsProps {
    size?: 'sm' | 'md' | 'lg';
    className?: any;
    onClick?: () => void;
}
export interface IFoodCard {
    id: string;
    title: string;
    avatar?: string;
    additionalText?: string;
    items: string | number;
    price: string | number;
}