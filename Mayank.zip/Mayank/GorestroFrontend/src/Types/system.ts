export enum Theme {
    Light = "light",
    Dark = "dark"
}

export interface ISystem {
    id: string | null;
    name: string | null;
    theme: Theme;
    lang: string | null;
    location: string | null;
    timeZone: string | null;
}