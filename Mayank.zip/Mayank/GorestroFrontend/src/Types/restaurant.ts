// Interface for Restaurant Request
export interface IRestaurantRequest {
    displayName: string;
    username: string;
    password: string;
    avatar: string;
    managerName: string;
    phoneNumber: string;
    address: string;
    city: string;
    state: string;
    country: string;
    pincode: string;
}

// Interface for Restaurant Response
export interface IRestaurantResponse {
    _id: string;
    displayName: string;
    username: string;
    avatar: string;
    managerName: string;
    phoneNumber: string;
    address: string;
    city: string;
    state: string;
    country: string;
    pincode: string;
    status: boolean;
    createdAt: string;
    updatedAt: string;
}