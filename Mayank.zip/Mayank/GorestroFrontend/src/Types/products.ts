
export interface IProductRequest {
    categoryId: string;
    avatar: File | null; // it will be image 
    displayName: string;
    description: string;
    price: number;
    mrp: number;
}
export interface IProductRequestError {
    categoryId: string;
    avatar: string; // it will be image 
    displayName: string;
    description: string;
    price: string;
    mrp: string;
}

export interface IProductResponse {
    _id: string;
    restroId: string;
    category: {
        id: string;
        displayName: string;
    };
    displayName: string;
    description: string;
    mrp: number;
    price: number;
    avatar: string;
    status: boolean;
    createdAt: string;
    updatedAt: string;
}

export interface IProductCategoryRequest {
    _id: string;
    displayName: string;
}

export interface IProductCategoryResponse {
    _id: string;
    restroId: string;
    displayName: string;
    status: boolean;
    createdAt: string;
    updatedAt: string;
}