import { AvatarGroup, AvatarGroupItem, AvatarGroupPopover, partitionAvatarGroupItems } from "@fluentui/react-components";
import { IOrderItemResponse } from "../../Types/order";

interface IFoodCardAvtarProps {
    OrderItem: IOrderItemResponse[];
}
const FoodCardAvtar: React.FC<IFoodCardAvtarProps> = ({ OrderItem }) => {
    const { inlineItems, overflowItems } = partitionAvatarGroupItems({
        items: OrderItem,
        layout: "stack"
    });
    return (
        <AvatarGroup layout="stack" size={32} key={24}>
            {inlineItems.map((item: IOrderItemResponse) => (
                <AvatarGroupItem
                    image={{
                        src: item.avatar,
                    }}
                    name={item.displayName} key={item.productId} />
            ))}
            {overflowItems && (
                <AvatarGroupPopover tooltip={{ content: "View more items", relationship: "label" }}>
                    {overflowItems.map((item: IOrderItemResponse) => (
                        <AvatarGroupItem name={item.displayName} key={item.productId} />
                    ))}
                </AvatarGroupPopover>
            )}
        </AvatarGroup>
    );

}

export default FoodCardAvtar