import React, { useEffect, useState } from "react";
import Styles from "./OrderCard.module.scss";
import { Button, Card, CardHeader, CounterBadge, Field, Menu, MenuItem, MenuList, MenuPopover, MenuTrigger, mergeClasses, ProgressBar } from "@fluentui/react-components";
import { ChevronRightRegular, ErrorCircleRegular, MoreHorizontal20Regular } from "@fluentui/react-icons";
import { IOrderItemResponse, IOrderResponse, IOrderStatusResponse } from "../../Types/order";
import FoodCardAvtar from "./FoodAvatar";
import { useDispatch, useSelector } from "react-redux";
import { IApiResponse, IAuthResponse } from "../../Types";
import orderStatusController from "../../DataProvider/Controllers/OrderStatusController";
import { setOrderStatuses } from "../../Store/Slices/orderStatusSlice";
import orderController from "../../DataProvider/Controllers/OrdersController";
import { updateOrder } from "../../Store/Slices/orderSlice";
import { handleOrderStatusBar, handlePayButtomDisable } from "../../Utils/Orders";
import ConfirmDialog from "../ConfirmDialog";

interface IOrderCardProps {
    className?: any;
    onEdit: () => void;
    onDelete: () => void;
    order: IOrderResponse;
}

const confirmPaymentContent = {
    header: "Confirm Cash Payment",
    description: "Are you sure you want to confirm that this order's payment has been made in cash? This action cannot be undone.",
    btnText: "Confirm",
};


const OrderCard: React.FC<IOrderCardProps> = ({
    className = "",
    onDelete,
    onEdit,
    order
}) => {
    const user: IAuthResponse = useSelector((state: any) => state.auth);
    const orderStatuses: IOrderStatusResponse[] = useSelector((state: any) => state.orderStatuses.orderStatuses);
    const { _id, status, customerName, tableNumber, totalAmount, items, acceptedBy } = order;
    const [isCashPayment, setIsCashPayment] = useState<{ key: boolean; data: IOrderResponse } | null>(null);


    const dispatch = useDispatch();

    useEffect(() => {
        const loadOrders = async () => {
            try {
                if (user.userData?._id && orderStatuses.length === 0) {
                    orderStatusController.getOrderStatuses().then((response: IApiResponse) => {
                        if (response.success) dispatch(setOrderStatuses(response.data));
                    });
                }
            } catch (error) {
                console.error("Error loading orders", error);
            }
        };
        loadOrders();
    }, [user.userData?._id, orderStatuses.length, dispatch]);

    const handleUpdateStatus = (status: IOrderStatusResponse) => {
        try {
            if (status._id) {
                const updatedOrder: IOrderResponse = {
                    ...order, status: {
                        id: status._id,
                        displayName: status.displayName
                    }
                };
                orderController.updateOrder({ id: _id, statusId: status._id }).then((response: IApiResponse) => {
                    if (response.success) dispatch(updateOrder(updatedOrder));
                });
            }
        } catch (error) {
            console.error("Error updating order status", error);
        }
    };


    // Capitalize first letter of the status
    const capitalizeFirstLetter = (str: string) => {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    };

    const { progress, statusBar } = handleOrderStatusBar(status.displayName);

    const downloadReceipt = () => {
        // Fetch the PDF file
        fetch('http://localhost:3001/download-receipt', {
            method: 'GET',
        })
            .then(response => response.blob())
            .then(blob => {
                // Create a link element and trigger download
                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                link.download = 'receipt.pdf';
                link.click();
            })
            .catch(err => console.error('Error downloading receipt:', err));
    };

    /**
    * Open the get bill confirmation dialog.
    */
    const handleConfirmModel = () => {
        if (order) {
            setIsCashPayment({ key: true, data: order });
        } else {
            alert("Order not found!");
        }
    };

    const handleBill = () => {
        downloadReceipt();
        setIsCashPayment(null)
    }

    return (
        <div className={mergeClasses(Styles.Container, className)} key={_id}>
            <Card className={Styles.card} orientation="horizontal">
                <CardHeader
                    header={
                        <div className="flex items-center gap-2">
                            <span className="text-base font-semibold">{customerName}
                                <span className="text-sm font-normal">{` (10:30 PM)`}</span>
                            </span>
                            <CounterBadge shape="rounded">{tableNumber}</CounterBadge>
                        </div>}
                    action={
                        <Menu>
                            <MenuTrigger disableButtonEnhancement>
                                <Button
                                    appearance="transparent"
                                    icon={<MoreHorizontal20Regular />}
                                    aria-label="More options"
                                />
                            </MenuTrigger>
                            <MenuPopover>
                                <MenuList>
                                    <Menu positioning="below-end">
                                        <MenuTrigger disableButtonEnhancement>
                                            <MenuItem>{capitalizeFirstLetter(status.displayName)}</MenuItem>
                                        </MenuTrigger>
                                        <MenuPopover>
                                            <MenuList>
                                                {orderStatuses && orderStatuses.map((status) => (
                                                    <MenuItem key={status._id} onClick={() => handleUpdateStatus(status)}>
                                                        {capitalizeFirstLetter(status.displayName)}
                                                    </MenuItem>
                                                ))}
                                            </MenuList>
                                        </MenuPopover>
                                    </Menu>
                                    <MenuItem onClick={() => onEdit()}>Edit Order</MenuItem>
                                    <MenuItem onClick={() => onDelete()}>Delete Order</MenuItem>
                                </MenuList>
                            </MenuPopover>
                        </Menu>
                    }
                />
                <p className="m-0 text-xs opacity-70 min-h-[70px]">
                    {customerName} has placed an order from
                    <span className="text-sm font-semibold text-black opacity-100">{` Table ${tableNumber}. `}</span>
                    The requested items are:{' '}
                    {items.map((foodItem: IOrderItemResponse, index: number) => (
                        <span key={index}>
                            {index === items.length - 1 && <span>and </span>}
                            <span className="text-sm font-semibold text-black opacity-100">{`${foodItem.quantity} ${foodItem.displayName}`}</span>
                            {index === items.length - 1 ? '.' : ', '}
                        </span>
                    ))}
                </p>
                <Field
                    className={mergeClasses(Styles.progressBar, Styles[statusBar])}
                    validationMessage={capitalizeFirstLetter(status.displayName)}
                    validationMessageIcon={<ErrorCircleRegular fontSize={16} />}
                >
                    {acceptedBy.id && (
                        <span className="text-base font-semibold absolute">{`Accept: ${acceptedBy.displayName}`}</span>
                    )}
                    <ProgressBar value={progress} />
                </Field>
                <footer className={mergeClasses(Styles.flex, Styles.cardFooter)}>
                    <FoodCardAvtar OrderItem={items} />
                    <Button
                        className={mergeClasses(
                            handlePayButtomDisable(status.displayName) && Styles.PayButtonDisable
                        )}
                        onClick={() => handleConfirmModel()}
                        disabled={handlePayButtomDisable(status.displayName)}
                        icon={<ChevronRightRegular />}
                        iconPosition="after"
                        appearance="primary"
                    >
                        ₹{totalAmount}.00
                    </Button>
                </footer>
            </Card>
            {isCashPayment && <ConfirmDialog
                isOpen={isCashPayment.key}
                content={confirmPaymentContent}
                handleModelClose={() => setIsCashPayment(null)}
                handleConfirm={handleBill}
            />}
        </div>
    );
};

export default OrderCard;
