import React from 'react';

const DownloadReceiptButton = () => {
    const downloadReceipt = () => {
        // Fetch the PDF file
        fetch('http://localhost:3001/download-receipt', {
            method: 'GET',
        })
            .then(response => response.blob())
            .then(blob => {
                // Create a link element and trigger download
                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                link.download = 'receipt.pdf';
                link.click();
            })
            .catch(err => console.error('Error downloading receipt:', err));
    };

    return (
        <button onClick={downloadReceipt}>Download Receipt</button>
    );
};

export default DownloadReceiptButton;
