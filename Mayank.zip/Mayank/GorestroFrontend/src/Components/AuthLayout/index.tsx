import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

interface IAuthLayout {
    children: React.ReactNode;
    authentication: boolean;
}
const AuthLayout: React.FC<IAuthLayout> = ({ children, authentication }) => {
    const authStatus: boolean = useSelector((state: any) => state.auth.status);
    const [loader, setLoader] = useState<boolean>(true);
    const navigate = useNavigate();

    useEffect(() => {
        if (authStatus !== authentication) {
            navigate(authentication ? "/login" : "/");
        }
        setLoader(false);
    }, [navigate, authentication, authStatus]);

    return loader ? <h1 children="Loading..." /> : <>{children}</>;

}

export default AuthLayout;