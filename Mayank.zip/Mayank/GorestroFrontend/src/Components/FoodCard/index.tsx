import { FC } from "react";
import Styles from "./FoodCard.module.scss";
import Flex, { AlignItems, FlexDirection } from "../Flex/Flex";
import { Button, mergeClasses, Persona } from "@fluentui/react-components";
import { IFoodCard } from "../../Types/comman";
import { AddRegular, DismissRegular, DividerShortRegular } from "@fluentui/react-icons";

interface IFoodCardProps extends IFoodCard {
    className?: any;
    onClick?: () => void;
    handleQuantity: (quantity: number, productId: string) => void;

}

const FoodCard: FC<IFoodCardProps> = ({ className = '', onClick, id, title, items, avatar = "", price, handleQuantity }) => {
    return (
        <Flex className={`${Styles.ItemBox} ${className}`} onClick={() => onClick && onClick()} alignItems={AlignItems.START}>
            <Persona size="huge" name={title} textAlignment="center" secondaryText={`₹${price}.00`}
                avatar={{
                    image: {
                        src: avatar,
                    },
                }}
            />
            <Flex className={mergeClasses(Styles.ItemsAndAmount, "!h-fit gap-3")} direction={FlexDirection.COLUMN} alignItems={AlignItems.END}>
                <span className={Styles.Amount}>₹{Number(price) * Number(items)}.00</span>
                <div className="flex justify-center items-center !rounded-[50px] bg-[#eff3f4]">
                    <Button className="!min-w-7 !min-h-7 !p-[2px] !rounded-[50%]" onClick={() => handleQuantity(Number(items) - 1, id)} disabled={Number(items) <= 1}><DividerShortRegular className="rotate-90" fontSize={14} fill="#fff" /></Button>
                    <span className="text-sm font-normal text-[#757575] text-center w-7">{items}</span>
                    <Button className="!min-w-7 !min-h-7 !p-[2px] !rounded-[50%]" appearance="primary" onClick={() => handleQuantity(Number(items) + 1, id)}><AddRegular fontSize={14} fill="#fff" /></Button>
                </div>
            </Flex>
            <div className={Styles.DismissBtn} onClick={() => handleQuantity(0, id)}>
                <DismissRegular color="#fff" />
            </div>
        </Flex>
    );
}
export default FoodCard;