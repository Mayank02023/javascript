import { FC } from "react";
import {
    Dialog,
    DialogSurface,
    DialogTitle,
    DialogBody,
    DialogActions,
    DialogContent,
    Button,
} from "@fluentui/react-components";

interface IConfirmDialogProps {
    isOpen: boolean;
    content: {
        header: string;
        description: string;
        btnText: string;
    }
    handleModelClose: () => void;
    handleConfirm: () => void;
}

const ConfirmDialog: FC<IConfirmDialogProps> = ({ isOpen, content, handleModelClose, handleConfirm }) => {
    return (
        <Dialog open={isOpen}>
            <DialogSurface>
                <DialogBody>
                    <DialogTitle>{content.header}</DialogTitle>
                    <DialogContent>{content.description}</DialogContent>
                    <DialogActions>
                        <Button appearance="secondary" onClick={() => handleModelClose()}>
                            Cancel
                        </Button>
                        <Button appearance="primary" onClick={() => handleConfirm()}>
                            {content.btnText}
                        </Button>
                    </DialogActions>
                </DialogBody>
            </DialogSurface>
        </Dialog>
    );
};

export default ConfirmDialog;
