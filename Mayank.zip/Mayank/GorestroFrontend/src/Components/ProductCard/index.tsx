import { FC } from "react";
import cssStyles from "./ProductCard.module.scss";
import Flex from "../Flex/Flex";
import { Button, Input, mergeClasses, Persona } from "@fluentui/react-components";
import { IProductResponse } from "../../Types";
import { AddRegular, DividerShortRegular } from "@fluentui/react-icons";

interface IProductCardProps {
    className?: any;
    product: IProductResponse;
    onClick?: () => void;
    handleQuantity: (quantity: number, productId: string) => void;
    quantity: number;
    isSelected: boolean;
}

const ProductCard: FC<IProductCardProps> = ({ className = '', onClick, product, quantity, handleQuantity, isSelected }) => {
    return (
        <div className={`${cssStyles.Card} ${isSelected && cssStyles.Active} ${className}`} onClick={() => onClick && onClick()}>
            <Persona size="huge"
                className={cssStyles.Persona}
                name={product.displayName}
                textAlignment="center"
                secondaryText={product.description}
                avatar={{
                    image: {
                        src: product.avatar
                    }
                }}
            />
            <Flex className="px-2 pt-2">
                <span className={cssStyles.Price}>₹{product.price}.00</span>
                <div className={cssStyles.QuantityArea}>
                    <Button className={mergeClasses(cssStyles.Button, cssStyles.Minus)} onClick={() => handleQuantity(quantity - 1, product._id)}><DividerShortRegular className="rotate-90" fontSize={20} fill="#fff" /></Button>
                    <span className={cssStyles.Quantity}>{quantity}</span>
                    <Button className={mergeClasses(cssStyles.Button, cssStyles.Plus)} onClick={() => handleQuantity(quantity + 1, product._id)} appearance="primary"><AddRegular fontSize={20} fill="#fff" /></Button>
                </div>
            </Flex>
        </div>
    );
}
export default ProductCard;