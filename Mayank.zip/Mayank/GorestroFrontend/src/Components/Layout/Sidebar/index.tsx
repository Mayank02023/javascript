import Styles from "./Sidebar.module.scss";
import { ArrowExitFilled } from "@fluentui/react-icons";
import { sidebarItems } from "../../../Constants/SidebarItems";
import GroupLinks from "../../GroupLinks";
import Flex, { JustifyContent } from "../../Flex/Flex";
import { Logo } from "./Logo";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { IAuthResponse } from "../../../Types";
import Logout from "../../Logout/Logout";
const Sidebar = () => {
    const auth: IAuthResponse = useSelector((state: any) => state.auth);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const navigate = useNavigate();
    const handleAuthModel = () => {
        if (auth.status) {
            setIsOpen((prevState) => !prevState);
        } else {
            navigate("/login");
        }
    }
    return (
        <>
            <nav className={Styles.navbar}>
                <div className={Styles.header}>
                    <Flex justifyContent={JustifyContent.BETWEEN}>
                        <Logo style={{ width: '120px' }} />
                    </Flex>
                </div>

                <div className={Styles.links}>
                    {sidebarItems.map((el, index) => (
                        <GroupLinks key={index} linkItem={el} />
                    ))}
                </div>

                <div className={Styles.footer}>
                    <GroupLinks
                        onClick={handleAuthModel}
                        linkItem={{
                            label: 'Logout',
                            icon: ArrowExitFilled,
                        }}
                    />
                </div>
            </nav>
            <Logout isOpen={isOpen} handleLogoutModel={handleAuthModel} />
        </>
    );

};
export default Sidebar;