import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Styles from "./Layout.module.scss";
import { Menu, MenuList, MenuPopover, MenuTrigger, MenuItem as MenuItemComponent } from "@fluentui/react-components";
import { ChevronRightFilled } from "@fluentui/react-icons";

interface IMenuItem {
    icon?: JSX.Element;
    title?: string;
    path?: string;
    children?: IMenuItem[];
}

interface IMenuItemProps {
    menuItem: IMenuItem;
}

const MenuItem: React.FC<IMenuItemProps> = ({ menuItem }) => {
    const { icon, title, path = '/', children = undefined } = menuItem;
    const navigate = useNavigate();
    const location = useLocation();

    // Function to render child menus if available
    const renderChildMenu = (menuItem: IMenuItem) => {
        return (
            <Menu>
                <MenuTrigger disableButtonEnhancement>
                    <MenuItemComponent className={`${Styles.MenuItemChild} ${location.pathname === menuItem.path ? Styles.Active : ''}`}>
                        <span className="heading">
                            {menuItem.icon} {menuItem.title}
                        </span>
                        <ChevronRightFilled />
                    </MenuItemComponent>
                </MenuTrigger>
                <MenuPopover className="!left-[6.5%]">
                    <MenuList>
                        {menuItem.children?.map((child) => (
                            child.children ? (
                                renderChildMenu(child)
                            ) : (
                                <MenuItemComponent className={`${Styles.MenuInnerItem} ${location.pathname === menuItem.path ? Styles.Active : ''}`} key={child.path} onClick={() => navigate(child.path || '/')}>
                                    {child.icon} {child.title}
                                </MenuItemComponent>
                            )
                        ))}
                    </MenuList>
                </MenuPopover>
            </Menu>
        );
    };

    // Render the top-level or child menu item
    return children ? (
        renderChildMenu(menuItem)
    ) : (
        <MenuItemComponent
            className={`${Styles.MenuItem} ${location.pathname === path ? Styles.Active : ''}`}
            onClick={() => navigate(path)}
        >
            {icon} <span>{title}</span>
        </MenuItemComponent>
    );
};

export default MenuItem;
