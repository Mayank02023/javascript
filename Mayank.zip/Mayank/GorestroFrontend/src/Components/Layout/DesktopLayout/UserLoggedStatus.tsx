import { FC, useState } from "react";
import Styles from "./DesktopLayout.module.scss";
import { useSelector } from "react-redux";
import { Menu, MenuItem, MenuList, MenuPopover, MenuTrigger, Persona } from "@fluentui/react-components";
import { ChevronDownRegular, MoreHorizontalRegular, AlertOnFilled, SettingsFilled } from "@fluentui/react-icons";
import { Flex } from "../..";
import Logout from "../../Logout/Logout";
import { IAuthResponse } from "../../../Types/auth";
import { useNavigate } from "react-router-dom";

interface IUserLoggedStatusProps { }

const UserLoggedStatus: FC<IUserLoggedStatusProps> = () => {
    const auth: IAuthResponse = useSelector((state: any) => state.auth);
    const [isArrowDown, setIsArrowDown] = useState<boolean>(false);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const navigate = useNavigate();

    const handleToggleMenu = () => {
        setIsArrowDown((prevState) => !prevState);
    };

    const handleAuthModel = () => {
        if (auth.status) {
            setIsOpen((prevState) => !prevState);
        } else {
            navigate("/login");
        }
    };

    const handleProfileClick = () => {
        navigate("/profile");
    };

    const handleSettingsClick = () => {
        navigate("/settings");
    };

    const handleLogoutClick = () => {
        // Handle logout logic here
        console.log("Logout");
    };

    return (
        <div className={Styles.LoggedStatusContainer}>
            <Flex className="gap-3">
                <AlertOnFilled fontSize={24} />
                <Flex className="gap-1" onClick={handleToggleMenu}>
                    <Persona
                        name={auth.userData?.displayName}
                        secondaryText="Online"
                        presence={{ status: "available" }}
                        textAlignment="center"
                    />
                    <Menu open={isArrowDown}>
                        <MenuTrigger>
                            {isArrowDown ? <ChevronDownRegular /> : <MoreHorizontalRegular />}
                        </MenuTrigger>
                        <MenuPopover>
                            {auth.status && (
                                <MenuList>
                                    <MenuItem onClick={handleProfileClick}
                                        className={Styles.ManuItem}>
                                        <SettingsFilled fontSize={20} />
                                        <span>Profile</span>
                                    </MenuItem>
                                    <MenuItem onClick={handleSettingsClick}
                                        className={Styles.ManuItem}>
                                        <SettingsFilled fontSize={20} />
                                        <span>Settings</span>
                                    </MenuItem>
                                    <MenuItem onClick={handleLogoutClick}
                                        className={Styles.ManuItem}>
                                        <SettingsFilled fontSize={20} />
                                        <span>Logout</span>
                                    </MenuItem>
                                </MenuList>
                            )}
                        </MenuPopover>
                    </Menu>
                </Flex>
            </Flex>
            <Logout isOpen={isOpen} handleLogoutModel={handleAuthModel} />
        </div>
    );
};

export default UserLoggedStatus;
