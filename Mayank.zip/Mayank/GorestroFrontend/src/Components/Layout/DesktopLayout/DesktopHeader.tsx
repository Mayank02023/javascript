import cssStyles from "./DesktopLayout.module.scss";
import Flex, { FlexDirection, AlignItems, JustifyContent, FlexWrap } from "../../Flex/Flex";
import { useEffect, useState } from "react";
import UserLoggedStatus from "./UserLoggedStatus";
import { useLocation } from "react-router-dom";
import { getHeaderTitle } from "../../../Utils/basic";

const DesktopHeader = () => {
    const [hasShadow, setHasShadow] = useState(false);
    const location = useLocation();
    useEffect(() => {
        function handleScroll() {
            if (window.scrollY > 20) {
                setHasShadow(true);
            } else {
                setHasShadow(false);
            }
        }
        window.addEventListener('scroll', handleScroll);
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);
    return (
        <Flex className={`${cssStyles.Container} ${hasShadow && cssStyles.Scrolled}`} direction={FlexDirection.ROW} alignItems={AlignItems.CENTER} justifyContent={JustifyContent.BETWEEN} flexWrap={FlexWrap.WRAP}>
            <Flex direction={FlexDirection.COLUMN} alignItems={AlignItems.START} justifyContent={JustifyContent.CENTER}>
                <span className={cssStyles.Header}>{getHeaderTitle(location.pathname)}</span>
            </Flex>
            <UserLoggedStatus />
        </Flex>
    );
}
export default DesktopHeader;