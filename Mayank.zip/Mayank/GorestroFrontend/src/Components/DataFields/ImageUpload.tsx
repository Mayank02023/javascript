import React, { useState } from 'react';
import { Field, Button, Image } from '@fluentui/react-components';
import { DismissRegular } from '@fluentui/react-icons';
import Styles from "./DataFields.module.scss";

interface IImageUploadProps {
    label?: string;
    error: string;
    name: string;
    onImageSelect: (file: File | null, name: string) => void; // Callback to pass the selected image to parent
    isDisabled?: boolean;
}

const ImageUpload: React.FC<IImageUploadProps> = ({
    label = "Upload Avatar",
    error,
    name,
    onImageSelect,
    isDisabled = false
}) => {
    const [selectedImage, setSelectedImage] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);

    const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setSelectedImage(file);
            setPreviewUrl(URL.createObjectURL(file));
            onImageSelect(file, name);
        }
    };

    const handleRemoveImage = () => {
        setSelectedImage(null);
        setPreviewUrl(null);
        onImageSelect(null, name); // Pass null to remove the image from parent state
    };

    return (
        <Field
            label={label}
            className={Styles.ImageUploadField}
            hint={error}
        >
            <div className={`${Styles.imagePreviewContainer} flex flex-col items-center`}>
                <label className={`cursor-pointer ${isDisabled ? 'opacity-50' : ''}`}>
                    <input
                        type="file"
                        name={name}
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageChange}
                        disabled={isDisabled}
                    />
                    <div style={{ border: "1px solid green", height: 200, width: 400 }}>
                        {previewUrl ? (
                            <Image
                                src={previewUrl}
                                alt="Preview"
                                fit="contain"
                            />
                        ) : (
                                <Image
                                    src="https://fabricweb.azureedge.net/fabric-website/placeholders/400x200.png"
                                    alt="Image placeholder"
                                    fit="contain"
                                />
                        )}
                    </div>
                </label>

                {selectedImage && (
                    <div className="mt-4">
                        <Button
                            icon={<DismissRegular />}
                            onClick={handleRemoveImage}
                            appearance="primary"
                            disabled={isDisabled}
                        >
                            Remove Image
                        </Button>
                    </div>
                )}
            </div>
        </Field>
    );
};

export default ImageUpload;
