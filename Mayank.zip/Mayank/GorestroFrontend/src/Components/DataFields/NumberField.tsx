import React from "react";
import Styles from "./DataFields.module.scss";
import { Field, Input } from "@fluentui/react-components";
import { DismissRegular, SearchRegular } from "@fluentui/react-icons";

interface INumberFieldProps {
    type?: 'text' | 'email' | 'password' | 'search' | 'tel' | 'url' | 'date' | 'datetime-local' | 'month' | 'number' | 'time' | 'week';
    label?: string;
    name: string;
    value: number;
    labelClassName?: string;
    className?: string;
    setValue: (value: number, name: string) => void;
    clearable?: boolean;
    isDisabled?: boolean;
    error?: string;
    placeholder?: string;
    labelOrientation?: "horizontal" | "vertical";
    readOnly?: boolean;
    autoComplete?: string; // Correct type for autoComplete
}

const NumberField: React.FC<INumberFieldProps> = ({
    type = 'number',
    name,
    label,
    value = 0,
    className = '',
    setValue,
    clearable = false,
    isDisabled = false,
    error,
    placeholder,
    labelOrientation = "vertical",
    readOnly = false,
    autoComplete = "off"
}) => {
    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const value = event.target.value ? Number(event.target.value) : 0;
        setValue(value, event.target.name);
    };

    const handleClear = () => {
        setValue(0, name);
    };

    const showClearButton = clearable && value > 0;
    const contentAfter = type === "search"
        ? (showClearButton ? <DismissRegular onClick={handleClear} /> : <SearchRegular onClick={handleClear} />)
        : (showClearButton ? <DismissRegular onClick={handleClear} /> : null);

    return (
        <Field
            label={label}
            orientation={labelOrientation}
            hint={error}
            className={`${Styles.InputField} ${labelOrientation === "horizontal" ? Styles.horizontalLabelInputField : ''} ${className}`}
        >
            <Input
                name={name}
                type={type}
                value={value ? String(value) : ""}
                onChange={handleChange}
                disabled={isDisabled}
                placeholder={placeholder}
                contentAfter={contentAfter}
                autoComplete={autoComplete}
                readOnly={readOnly}
            />
        </Field>
    );
};

export default NumberField;
