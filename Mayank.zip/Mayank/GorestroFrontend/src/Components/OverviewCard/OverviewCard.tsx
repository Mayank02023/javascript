import { FC } from "react";
import Styles from "./OverviewCard.module.scss";
import { ArrowTrendingRegular, ArrowTrendingDownRegular } from "@fluentui/react-icons";
import { IOrderStatusCardForDashboard } from "../../Types/order";
import { mergeClasses } from "@fluentui/react-components";

interface IOverviewCardProps {
    className?: any;
    isActive?: boolean;
    item: IOrderStatusCardForDashboard;
}

const OverviewCard: FC<IOverviewCardProps> = ({
    className = "",
    isActive = false,
    item
}) => {
    const { id, onClick, progress, headerTitle, contentTitle } = item;
    return (
        <div className={mergeClasses(Styles.Card, item.contentTitle <= 0 && Styles.Disable, isActive && Styles.ActiveCard, className)} onClick={() => item.contentTitle > 0 && onClick()}>
            <div className={Styles.Header}>
                {headerTitle}
            </div>
            <div className={Styles.Content}>
                <span className={Styles.Title}>{contentTitle}</span>
                <span
                    className={`${Styles.Description} ${progress.isUp ? `text-green-700` : `text-red-600`}`}>
                    {progress.isUp ? <ArrowTrendingRegular fontSize={14} /> : <ArrowTrendingDownRegular fontSize={14} />}
                    {` ${progress.value} %`}
                </span>
            </div>
        </div>
    );
};
export default OverviewCard;
