import React from "react";
import cssStyles from "./CategoryCard.module.scss";
interface ICategoryData {
    id: string;
    headerTitle: string;
    items: number;
}
interface ICategoryCardProps {
    className?: any;
    onClick?: () => void;
    isActive?: boolean;
    data: ICategoryData;
}

const CategoryCard: React.FC<ICategoryCardProps> = ({
    className = "",
    onClick,
    isActive = false,
    data
}) => {
    return (
        <div className={`${cssStyles.Card} ${isActive && cssStyles.ActiveCard} ${className}`} onClick={() => onClick && onClick()}>
            <span className={cssStyles.Header}>{data.headerTitle}</span>
            <span className={cssStyles.Description}>{`${data.items} Menu In stock`}</span>
        </div>
    )
}
export default CategoryCard;