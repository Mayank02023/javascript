import React from "react";
import { TabList, Tab } from "@fluentui/react-components";
import Styles from "./TabLists.module.scss";

interface ITabList {
    value: string;
    title: string;
}
interface TabListsProps {
    tabList: ITabList[];
    defaultSelectedValue: ITabList;
    setOrderStatus: (status: string) => void;
}

const TabLists: React.FC<TabListsProps> = ({ tabList, defaultSelectedValue, setOrderStatus }) => {
    return (
        <div className={Styles.TabListContainer}>
            <TabList className="pt-3 pb-2" defaultSelectedValue={defaultSelectedValue.value} onTabSelect={(_event: any, data: any) => {
                const value = data.value !== "total" ? data.value : "";
                setOrderStatus(value);
            }}>
                {tabList.map((tab: ITabList, index) => {
                    return (
                        <Tab
                            defaultChecked={tab.value === defaultSelectedValue.value}
                            key={index}
                            className={Styles.Tabs}
                            value={tab.value}
                            children={tab.title}
                        />
                    )
                })}
            </TabList>
        </div>
    );
};

export default TabLists;
