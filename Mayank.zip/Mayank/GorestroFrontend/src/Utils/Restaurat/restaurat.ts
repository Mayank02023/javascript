import { IRestaurantRequest } from "../../Types";


export const initialRestauratState: IRestaurantRequest = {
    displayName: "",
    username: "",
    password: "",
    avatar: "",
    managerName: "",
    phoneNumber: "",
    address: "",
    city: "",
    state: "",
    country: "",
    pincode: ""
};

export const resetRestauratForm = (Restaurat?: IRestaurantRequest) => {
    return Restaurat ?? initialRestauratState
};