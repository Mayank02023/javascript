import { Menu, MenuItem, MenuList, MenuPopover, MenuTrigger, Switch } from "@fluentui/react-components";
import { IWorkerResponse, IWorkerRoleResponse } from "../../Types/worker";
import { MoreVerticalFilled } from "@fluentui/react-icons";
import { ITableRow } from "../../Components/Table/Interface";
import { FC } from "react";
import { getRole, getShift } from ".";


const TableAction: FC<any> = ({ id, onEdit, onDelete }) => (
    <Menu>
        <MenuTrigger disableButtonEnhancement>
            <MoreVerticalFilled fontSize={20} />
        </MenuTrigger>
        <MenuPopover>
            <MenuList>
                <MenuItem onClick={() => onEdit(id)}>Edit</MenuItem>
                <MenuItem onClick={() => onDelete(id)}>Delete</MenuItem>
            </MenuList>
        </MenuPopover>
    </Menu>)


const getWorkerTableRow = (item: IWorkerResponse, onEdit: (id: string) => void, onDelete: (id: string) => void): ITableRow => {
    return {
        displayName: {
            key: item.displayName,
            value: item.displayName
        },
        phoneNumber: {
            key: item.phoneNumber,
            value: item.phoneNumber
        },
        shiftId: {
            key: item.shiftId,
            value: getShift(item.shiftId) || "",
        },
        roleId: {
            key: item.roleId,
            value: getRole(item.roleId) || "",
        },
        isLoggedIn: {
            key: item.isLoggedIn ? 1 : 0,
            value: item.isLoggedIn ? 'Yes' : 'Out',
        },
        action: {
            key: "",
            value: <TableAction
                id={item._id}
                onEdit={onEdit}
                onDelete={onDelete}
            />
        }
    };
};

const getRoleOrShiftTableRow = (item: IWorkerRoleResponse, onEdit: (id: string) => void, handleUpdateStatus: (id: string) => void, onDelete: (id: string) => void): ITableRow => {
    return {
        id: {
            key: item._id,
            value: item._id
        },
        displayName: {
            key: item.displayName,
            value: item.displayName
        },
        status: {
            key: item.status,
            value: <Switch
                onClick={() => {
                    handleUpdateStatus(item._id);
                }}
                checked={item.status}
            />,
            
        },
        action: {
            key: "",
            value: <TableAction
                id={item._id}
                onEdit={onEdit}
                onDelete={onDelete}
            />
        }
    };
};


export const getFormattedWorkerTable = (
    tableData: IWorkerResponse[],
    onEdit: (id: string) => void,
    onDelete: (id: string) => void
): ITableRow[] => {
    return tableData.map(item => getWorkerTableRow(item, onEdit, onDelete));
};

export const getRoleOrShiftTable = (
    tableData: IWorkerRoleResponse[],
    onEdit: (id: string) => void,
    handleUpdateStatus: (id: string) => void,
    onDelete: (id: string) => void
): ITableRow[] => {
    return tableData.map(item => getRoleOrShiftTableRow(item, onEdit, handleUpdateStatus, onDelete));
};


