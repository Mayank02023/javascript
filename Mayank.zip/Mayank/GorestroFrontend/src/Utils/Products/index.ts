import { IOption } from "../../Components/DataFields/Dropdown";
import { IProductRequest, IProductResponse } from "../../Types";
import { IProductRequestError } from "../../Types/products";
import validation from "../Validations/Validation";

export const initialProductState: IProductRequest = {
    categoryId: "",
    avatar: null,
    displayName: "",
    description: "",
    price: 0,
    mrp: 0


};
const productList: IProductRequest[] = [
    {
        categoryId: "66fa99f31b388556e61d6ccb", // Dinner
        avatar: null,
        displayName: "Butter Chicken",
        description: "Juicy chicken in a creamy tomato sauce",
        price: 280,
        mrp: 330
    },
    {
        categoryId: "66fa99f31b388556e61d6ccb", // Dinner
        avatar: null,
        displayName: "Garlic Naan",
        description: "Freshly baked naan topped with garlic and butter",
        price: 40,
        mrp: 50
    },
    {
        categoryId: "66fa99f31b388556e61d6ccb", // Dinner
        avatar: null,
        displayName: "Tandoori Chicken",
        description: "Spicy grilled chicken marinated in yogurt and spices",
        price: 350,
        mrp: 400
    },
    {
        categoryId: "66fa99f31b388556e61d6ccb", // Dinner
        avatar: null,
        displayName: "Mutton Rogan Josh",
        description: "Tender mutton cooked in a flavorful gravy",
        price: 450,
        mrp: 500
    },
    {
        categoryId: "66fa99ed1b388556e61d6cc8", // Lunch
        avatar: null,
        displayName: "Chole Bhature",
        description: "Spicy chickpeas served with fried bread",
        price: 120,
        mrp: 150
    }
];

export const initialProductErrorState: IProductRequestError = {
    categoryId: "",
    avatar: "",
    displayName: "",
    description: "",
    price: "",
    mrp: "",
};

export const resetProductForm = (product?: IProductResponse): IProductRequest => {
    return {
        categoryId: product?.category.id || initialProductState.categoryId,
        displayName: product?.displayName || initialProductState.displayName,
        description: product?.description || initialProductState.description,
        avatar: initialProductState.avatar,
        price: product?.price || initialProductState.price,
        mrp: product?.mrp || initialProductState.mrp
    };
};

export const resetProductFormError = (error?: IProductRequestError): IProductRequestError => {
    return {
        categoryId: error?.categoryId || initialProductErrorState.categoryId,
        displayName: error?.displayName || initialProductErrorState.displayName,
        description: error?.description || initialProductErrorState.description,
        avatar: error?.avatar || initialProductErrorState.description,
        price: error?.price || initialProductErrorState.price,
        mrp: error?.mrp || initialProductErrorState.mrp
    };
};

export const handleValidations = async (fields: (keyof IProductRequest)[], product: IProductRequest, error: IProductRequestError) => {
    try {
        const errors: IProductRequestError = error;
        // Perform validation for each field in parallel
        const validationResults = await Promise.all(
            fields.map(async (key) => {
                try {
                    const err = await validation.fieldValidation(product[key], key);
                    errors[key] = err;
                    return err;
                } catch (validationError) {
                    // Handle specific field validation errors
                    return 'Validation error'; // Or use a specific error message
                }
            })
        );

        // Check if all validations passed
        const hasError = validationResults.some((err) => err !== "");
        return { hasError, errors };
    } catch (error) {
        // Handle unexpected errors
        console.error('Unexpected error during validation:', error);
        return { hasError: true, errors: null }; // Or handle as needed
    }
};


export const formatProduct = (product: any, option: IOption): IProductResponse => {
    delete product.categoryId;
    delete product._v;
    const formattedProduct: IProductResponse = {
        ...product,
        category: {
            id: option.id,
            displayName: option.header
        }

    }
    return formattedProduct;

}