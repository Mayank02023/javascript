import moment from 'moment';

export const convertDateIntoTimeStamp = (dateString: string) => {
    const date = moment(dateString, "YYYY/M/D");  // Parse the date string with Moment.js

    const timestamp = date.unix();  // Get the Unix timestamp (seconds since epoch)

    return timestamp;
}

export const getHeaderTitle = (pathname: string) => {
    switch (pathname) {
        case '/':
            return 'Dashboard';
        case '/workers':
            return 'Workers';
        case '/roles':
            return 'Workers Role';
        case '/shifts':
            return 'Workers Shift';
        case '/login':
            return 'Login';
        case '/signup':
            return 'Sign Up';
        case '/foods':
            return 'Foods';
        case '/food-category':
            return 'Food Categories';
        default:
            return 'Dashboard'; // Fallback title
    }
};
