// type ValidatorFn = (value: string | number | null) => string;
class Validation {

    async fieldValidation(value: string | number | File | null, fieldName: string): Promise<string> {
        let error: string = "";
        switch (fieldName) {
            case 'password':
                const specialCharacterRegex: RegExp = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
                if (typeof value === 'string' && (value.length < 8 || value.length > 20 || !specialCharacterRegex.test(value))) {
                    error = "Password must be between 8 and 20 characters and contain at least one special character";
                }
                break;
            case 'displayName':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Name is required";
                } else if (typeof value === 'string' && (value.length < 3 || value.length > 100)) {
                    error = "Name must be between 3 and 100 characters";
                }
                break;
            case 'managerName':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Manager Name is required";
                } else if (typeof value === 'string' && (value.length < 3 || value.length > 100)) {
                    error = "Manager name must be between 3 and 100 characters";
                }
                break;
            case 'phoneNumber':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Contact No. is required";
                } else if (typeof value === 'string' && !/^\+\d+$/.test(value)) {
                    error = "Contact must start with + and country code";
                }
                break;
            case 'username':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Email is required";
                } else if (typeof value === 'string' && !/^\S+@\S+\.\S+$/.test(value)) {
                    error = "Enter a valid email";
                }
                break;
            case 'address':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Address is required";
                } else if (typeof value === 'string' && (value.length < 15 || value.length > 200)) {
                    error = "Address must be between 15 and 200 characters";
                }
                break;
            case 'country':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Country is required";
                } else if (typeof value === 'string' && (value.length < 3 || value.length > 100)) {
                    error = "Country name must be between 3 and 100 characters";
                }
                break;
            case 'state':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "State name is required";
                }
                break;
            case 'city':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "City is required";
                } else if (typeof value === 'string' && (value.length < 3 || value.length > 100)) {
                    error = "City name must be between 3 and 100 characters";
                }
                break;
            case 'pincode':
                if (typeof value === 'string' && (value.trim() === "" || !/^\d+$/.test(value))) {
                    error = "Pin code is required";
                } else if (typeof value === 'string' && value.length !== 6) {
                    error = "Pin code must have 6 characters";
                }
                break;
            case 'shiftId':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Shift is required";
                }
                break;
            case 'roleId':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Role is required";
                }
                break;
            case 'avatar':
                if (value === null || !(value instanceof File)) {
                    error = "Avatar is required";
                }
                break;
            case 'position':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Position is required";
                }
                break;
            case 'dob':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Date of birth is required";
                }
                break;
            case 'aadharCard':
                if (typeof value === 'string' && (value.trim() === "" || !/^\d{12}$/.test(value))) {
                    error = "Aadhar card must have 12 digits";
                }
                break;
            case 'panCard':
                if (typeof value === 'string' && (value.trim() === "" || !/^[A-Z]{5}\d{4}[A-Z]{1}$/.test(value))) {
                    error = "Enter a valid PAN card number";
                }
                break;
            // Product validation fields
            case 'categoryId':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Category ID is required";
                }
                break;
            case 'description':
                if (typeof value === 'string' && value.trim() === "") {
                    error = "Description is required";
                } else if (typeof value === 'string' && (value.length < 10 || value.length > 500)) {
                    error = "Description must be between 10 and 500 characters";
                }
                break;
            case 'price':
                if (typeof value === 'number' && value <= 0) {
                    error = "Price must be greater than 0";
                }
                break;
            case 'mrp':
                if (typeof value === 'number' && value <= 0) {
                    error = "MRP must be greater than 0";
                } else if (typeof value === 'number' && value < value) {
                    error = "MRP cannot be less than the price";
                }
                break;
            default:
                break;
        }
        return error;
    }
}


{/*     private validators: Record<string, ValidatorFn[]> = {
        password: [
            (value) => this.isRequired(value, "Password"),
            (value) => this.checkLength(value as string, 8, 20, "Password must be between 8 and 20 characters"),
            (value) => this.checkSpecialCharacter(value as string, "Password must contain at least one special character"),
        ],
        displayName: [
            (value) => this.isRequired(value, "Name"),
            (value) => this.checkLength(value as string, 3, 100, "Name must be between 3 and 100 characters")
        ],
        managerName: [
            (value) => this.isRequired(value, "Manager Name"),
            (value) => this.checkLength(value as string, 3, 100, "Manager name must be between 3 and 100 characters")
        ],
        phoneNumber: [
            (value) => this.isRequired(value, "Contact No."),
            (value) => this.checkRegex(value as string, /^\+\d+$/, "Contact must start with + and country code")
        ],
        username: [
            (value) => this.isRequired(value, "Email"),
            (value) => this.checkRegex(value as string, /^\S+@\S+\.\S+$/, "Enter a valid email")
        ],
        address: [
            (value) => this.isRequired(value, "Address"),
            (value) => this.checkLength(value as string, 15, 200, "Address must be between 15 and 200 characters")
        ],
        country: [
            (value) => this.isRequired(value, "Country"),
            (value) => this.checkLength(value as string, 3, 100, "Country name must be between 3 and 100 characters")
        ],
        state: [
            (value) => this.isRequired(value, "State name")
        ],
        city: [
            (value) => this.isRequired(value, "City"),
            (value) => this.checkLength(value as string, 3, 100, "City name must be between 3 and 100 characters")
        ],
        pincode: [
            (value) => this.isRequired(value, "Pin code"),
            (value) => this.checkRegex(value as string, /^\d{6}$/, "Pin code must have 6 digits")
        ],
        // Add other field validations similarly...
    };

    private isRequired(value: string | number | null, fieldName: string): string {
        return (value === null || value === '') ? `${fieldName} is required` : "";
    }

    private checkLength(value: string, min: number, max: number, errorMessage: string): string {
        return (value.length < min || value.length > max) ? errorMessage : "";
    }

    private checkSpecialCharacter(value: string, errorMessage: string): string {
        const specialCharacterRegex: RegExp = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
        return !specialCharacterRegex.test(value) ? errorMessage : "";
    }

    private checkRegex(value: string, regex: RegExp, errorMessage: string): string {
        return !regex.test(value) ? errorMessage : "";
    }

    public fieldValidation1(value: string | number | null, fieldName: string): string {
        const validators = this.validators[fieldName] || [];
        for (const validator of validators) {
            const error = validator(value);
            if (error) {
                return error;
            }
        }
        return "";
    }

    */}




const validation = new Validation();
export default validation;
