import { FC } from "react";
import { IProductResponse } from "../Types"
import { Button, CounterBadge, Menu, MenuItem, MenuList, MenuPopover, MenuTrigger, Persona, Switch, ToggleButton } from "@fluentui/react-components";
import { MoreVerticalFilled } from "@fluentui/react-icons";
import { ITableRow } from "../Components/Table/Interface";
import { IOrderItemResponse, IOrderResponse, IOrderStatusResponse } from "../Types/order";
import moment from "moment";


const TableAction: FC<any> = ({ id, onEdit, onDelete }) => (
    <Menu>
        <div className="flex justify-center">
            <MenuTrigger disableButtonEnhancement>
                <MoreVerticalFilled fontSize={20} />
            </MenuTrigger>
        </div>
        <MenuPopover>
            <MenuList>
                <MenuItem onClick={() => onEdit(id)}>Edit</MenuItem>
                <MenuItem onClick={() => onDelete(id)}>Delete</MenuItem>
            </MenuList>
        </MenuPopover>
    </Menu>)


const getProductTableRow = (
    item: IProductResponse,
    onEdit: (id: string) => void,
    handleUpdateStatus: (id: string) => void,
    onDelete: (id: string) => void
): ITableRow => {
    return {
        displayName: {
            key: item.displayName,
            value: <Persona
                textAlignment="center"
                name={item.displayName}
                avatar={{
                    image: {
                        src: item.avatar,
                    },
                }}
            />
        },
        category: {
            key: item.category.displayName,
            value: <span className="text-base text-gray-950">{item.category.displayName}</span>
        },
        description: {
            key: item.description,
            value: <span className="text-base text-gray-500">{item.description}</span>
        },
        price: {
            key: item.price,
            value: <span className="text-base text-gray-950">₹{item.price}.00</span>
        },
        mrp: {
            key: item.mrp,
            value: <span className="text-base text-gray-500 line-through">₹{item.mrp}.00</span>
        },
        status: {
            key: item.status,
            value: <Switch
                onClick={() => {
                    handleUpdateStatus(item._id);
                }}
                checked={item.status}
            />,

        },
        action: {
            key: "",
            value: <TableAction
                id={item._id}
                onEdit={onEdit}
                onDelete={onDelete}
            />
        }
    };
};

export const getProductTableRows = (
    tableData: IProductResponse[],
    onEdit: (id: string) => void,
    handleUpdateStatus: (id: string) => void,
    onDelete: (id: string) => void
): ITableRow[] => {
    return tableData.map(item => getProductTableRow(item, onEdit, handleUpdateStatus, onDelete));
};

const getOrderTableRow = (
    item: IOrderResponse,
    onEdit: (id: string) => void,
    handleUpdateStatus: (id: string, status: {
        id: string;
        displayName: string;
    }) => void,
    onDelete: (id: string) => void
): ITableRow => {
    return {
        customerName: {
            key: item.createdAt,
            value: <div className="flex flex-col items-start">
                <span className="text-base font-semibold">{item.customerName}</span>
                <span className="text-xs font-normal">{item.customerNumber}</span>
            </div>
        },
        items: {
            key: `items`,
            value: <span>
                {/* <span className="text-base font-semibold">{item.customerName}</span> has placed an order from Table <span className="text-base font-semibold">{item.tableNumber}</span>. The requested items are: */}
                {item.items.map((foodItem: IOrderItemResponse, index: number) => (
                    <span key={index}>
                        {index === item.items.length - 1 && <span className="text-base">and </span>}
                        <span className="text-base font-semibold">{` ${foodItem.quantity} ${foodItem.displayName}`}</span>
                        {index === item.items.length - 1 ? '.' : ', '}
                    </span>
                ))}
            </span>

        },
        createdAt: {
            key: item.createdAt,
            value: <span>{moment(String(item.createdAt)).format('DD-MM-YYYY hh:mm A')}</span>
        },
        totalAmount: {
            key: item.totalAmount,
            value: <span>₹{item.totalAmount}.00</span>
        },
        tableNumber: {
            key: item.tableNumber,
            value: <CounterBadge shape="rounded" className=" !text-base">{item.tableNumber}</CounterBadge>
        },
        status: {
            key: item.status.displayName,
            value:
                <div className="flex justify-center">
                    <Button appearance="outline">
                        {item.status.displayName}
                    </Button>
                </div>
        },
        action: {
            key: "",
            value: <TableAction
                id={item._id}
                onEdit={onEdit}
                onDelete={onDelete}
            />
        }
    }

}

export const getOrderTableRows = (
    tableData: IOrderResponse[] | [],
    onEdit: (id: string) => void,
    handleUpdateStatus: (id: string, status: {
        id: string;
        displayName: string;
    }) => void,
    onDelete: (id: string) => void
): ITableRow[] => {
    return tableData.map(item => {
        return getOrderTableRow(item, onEdit, handleUpdateStatus, onDelete)
    });
};


const getOrderStatusTableRow = (item: IOrderStatusResponse, onEdit: (id: string) => void, handleUpdateStatus: (id: string) => void, onDelete: (id: string) => void): ITableRow => {
    return {
        id: {
            key: item._id,
            value: item._id
        },
        displayName: {
            key: item.displayName, // Assuming you want to display customer name
            value: item.displayName
        },
        status: {
            key: item.status, // Assuming this field represents the order status
            value: <Switch
                onClick={() => {
                    handleUpdateStatus(item._id); // Update order status
                }}
                checked={item.status === true} // Assuming "completed" indicates active status
            />
        },
        action: {
            key: "",
            value: <TableAction
                id={item._id}
                onEdit={onEdit}
                onDelete={onDelete}
            />
        }
    };
};

export const getOrderStatusTable = (
    tableData: IOrderStatusResponse[], // Array of order status data
    onEdit: (id: string) => void,
    handleUpdateStatus: (id: string) => void,
    onDelete: (id: string) => void
): ITableRow[] => {
    return tableData.map(item => getOrderStatusTableRow(item, onEdit, handleUpdateStatus, onDelete));
};
