import { IOrderItemRequest, IOrderItemRequestError, IOrderRequest, IOrderRequestError, IOrderResponse } from "../../Types/order";

export const initialItems: IOrderItemRequest = {
    productId: "",
    quantity: 0,
    price: 0
}
export const initialOrderState: IOrderRequest = {
    id: "",
    statusId: "",
    items: [initialItems],
    customerName: "",
    customerNumber: "",
    tableNumber: 0,
    totalAmount: 0,
};

export const initialItemsError: IOrderItemRequestError = {
    productId: "",
    quantity: "",
    price: ""
}
export const initialOrderErrorState: IOrderRequestError = {
    _id: "",
    statusId: "",
    items: [initialItemsError],
    customerName: "",
    customerNumber: "",
    tableNumber: "",
    totalAmount: "",
}

export const initialCurrentOrderState: IOrderResponse = {
    _id: "",
    restroId: "",
    status: {
        id: "",
        displayName: ""
    },
    customerName: "",
    customerNumber: "",
    tableNumber: 0,
    totalAmount: 0,
    items: [],
    createdAt: "",
    updatedAt: ""
};
export const resetOrderForm = (order?: IOrderResponse): IOrderRequest => {
    const footItems: IOrderItemRequest[] = [];
    order?.items.map((item) => {
        footItems.push({
            productId: item.productId,
            quantity: item.quantity,
            price: item.price
        });
    })
    return {
        statusId: order?.status.id || initialOrderState.statusId,
        items: footItems || initialOrderState.items,
        customerName: order?.customerName || initialOrderState.customerName,
        customerNumber: order?.customerNumber || initialOrderState.customerNumber,
        tableNumber: order?.tableNumber || initialOrderState.tableNumber,
        totalAmount: order?.totalAmount || initialOrderState.totalAmount
    };
};

export const handleOrderStatusBar = (status: string) => {
    let progress = 0;
    let statusBar = "";
    switch (status) {
        case "Pending":
            progress = 0.1;
            statusBar = "Pending";
            break;
        case "Processing":
            progress = 0.3;
            statusBar = "Processing";
            break;
        case "Shipped":
            progress = 0.6;
            statusBar = "Shipped";
            break;
        case "Delivered":
            progress = 1;
            statusBar = "Delivered";
            break;
        case "Cancelled":
            progress = 1;
            statusBar = "Cancelled";
            break;
        case "Failed":
            progress = 1;
            statusBar = "Failed";
            break;
        case "Returned":
            progress = 0.5;
            statusBar = "Returned";
            break;
        default:
            progress = 0;
            statusBar = "Unknown";
            break;

    }
    return { progress, statusBar }
}

export const handlePayButtomDisable = (status: string): boolean => {
    const disabledStatuses = ["Cancelled", "Failed", "Returned"];
    return disabledStatuses.includes(status);
};
