
import { FluentProvider, Spinner, webLightTheme } from '@fluentui/react-components';
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { AuthLayout, Layout } from "./Components";
import { Dashboard, Login, Order, OrderStatuses, ProductCategories, Products, Profile, SignUp, Worker, WorkerRoles, WorkerShifts } from "./Pages";
import { useEffect, useState } from "react";
import { useDispatch } from 'react-redux';
import { login, logout } from './Store/Slices/authSlice';
import authController from './DataProvider/Controllers/AuthController';
import EditOrder from './Pages/Order/EditOrder';
import PdfPreview from './Pages/Order/PdfPreview';
const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        path: '/',
        element: <AuthLayout authentication={true}>
          <Dashboard />
        </AuthLayout>
      },
      {
        path: '/profile',
        element: <AuthLayout authentication={true}>
          <Profile />
        </AuthLayout>
      },
      {
        path: '/foods',
        element: <AuthLayout authentication={true}>
          <Products />
        </AuthLayout>
      },
      {
        path: '/food-category',
        element: <AuthLayout authentication={true}>
          <ProductCategories />
        </AuthLayout>
      },
      {
        path: '/workers',
        element: <AuthLayout authentication={true}>
          <Worker />
        </AuthLayout>
      },
      {
        path: '/roles',
        element: <AuthLayout authentication={true}>
          <WorkerRoles />
        </AuthLayout>
      },
      {
        path: '/shifts',
        element: <AuthLayout authentication={true}>
          <WorkerShifts />
        </AuthLayout>
      },
      {
        path: '/orders',
        element: <AuthLayout authentication={true}>
          <Order />
        </AuthLayout>
      },
      {
        path: '/order-status',
        element: <AuthLayout authentication={true}>
          <OrderStatuses />
        </AuthLayout>
      },
      {
        path: '/edit-order/:id',
        element: <AuthLayout authentication={true}>
          <EditOrder />
        </AuthLayout>
      },
      {
        path: '/new-order',
        element: <AuthLayout authentication={true}>
          <EditOrder />
        </AuthLayout>
      },

    ]
  },
  {
    path: '/login',
    element: <AuthLayout authentication={false}>
      <Login />
    </AuthLayout>
  },
  {
    path: '/signup',
    element: <AuthLayout authentication={false}>
      <SignUp />
    </AuthLayout>
  },
  {
    path: "/preview",
    element: <PdfPreview />
  }
]);
export default function App() {
  const [loading, setLoading] = useState(true);
  const dispatch = useDispatch();

  const initializeAuth = async () => {
    try {
      setLoading(true);
      const accessToken = localStorage.getItem("accessToken");
      const refreshToken = localStorage.getItem("refreshToken");
      if (accessToken && refreshToken) {
        const data = await authController.getCurrentUser();

        // Dispatch tokens and user data to Redux
        dispatch(login({
          userdata: {
            _id: data._id,
            displayName: data.displayName,
            username: data.username,
            avatar: data.avatar,
            managerName: data.managerName,
            phoneNumber: data.phoneNumber,
            address: data.address,
            city: data.city,
            state: data.state,
            country: data.country,
            pincode: data.pincode,
            status: data.status,
            createdAt: data.createdAt,
            updatedAt: data.updatedAt
          },
          accessToken,
          refreshToken
        }));
      } else {
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        dispatch(logout());
      }
    } catch (err) {
      localStorage.removeItem("accessToken");
      localStorage.removeItem("refreshToken");
      dispatch(logout());

    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    initializeAuth();
  }, [dispatch]);


  return (
    <FluentProvider theme={webLightTheme}>
      {!loading ? (<RouterProvider router={router} />) : <Spinner />}
    </FluentProvider>
  );
}