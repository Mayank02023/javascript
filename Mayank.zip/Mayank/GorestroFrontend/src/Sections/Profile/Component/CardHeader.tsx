import React from "react";
import { EditFilled } from "@fluentui/react-icons"
import Styles from "../Profile.module.scss";
interface ICardHeaderProps {
    header: string;
    onEdit: () => void;
}
const CardHeader: React.FC<ICardHeaderProps> = ({ header, onEdit }) => {
    return (
        <div className={Styles.ProfileCardHeader}>
            <span className={Styles.Heading}>{`${header}  Information`}</span>
            <EditFilled fontSize={24} cursor="pointer" onClick={() => onEdit()} color="#636363" />
        </div>
    )
}
export default CardHeader;