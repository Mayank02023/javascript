import React from 'react';

interface IDataProps { 
    title: string;
    value: string | number;
}
const Data:React.FC<IDataProps> = (props) => {   
    return (
        <div className=" flex flex-col gap-2 font-normal text-gray-800 text-[15px]">
            <span className='text-[#adadad] font-semibold'>{props.title}</span>
            <span className='text-gray-900 font-semibold'>{props.value}</span>
        </div>
    )
};
export default Data;