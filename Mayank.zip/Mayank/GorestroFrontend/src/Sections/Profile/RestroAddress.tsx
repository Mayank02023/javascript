import React from "react";
import Styles from "./Profile.module.scss";
import { mergeClasses } from "@fluentui/react-components";
import { EditFilled } from "@fluentui/react-icons";
import Data from "./Component/Data";
import CardHeader from "./Component/CardHeader";

interface IRestroAddressProps { }
const addressInformation = [
    { title: "Address", value: "1234 Culinary Street, Food City, Country" },
    { title: "Phone Number", value: "+91 987 654 3210" },
    { title: "Email", value: "contact@gourmetparadise.com" },
    { title: "Website", value: "www.gourmetparadise.com" }
];
const RestroAddress: React.FC<IRestroAddressProps> = (props) => {
    return (
        <div className={Styles.ProfileCard}>
            <CardHeader header="Address" onEdit={()=>{}} />
            <div className={Styles.ProfileCardBody}>
                <div className="grid w-full grid-cols-2 items-end gap-6">
                    {addressInformation.map((item, index) => (
                        <Data key={index} title={item.title} value={item.value} />
                    ))}
                </div>
            </div>
        </div>
    )
}

export default RestroAddress;