import React from "react";
import Styles from "./Profile.module.scss";
import Data from "./Component/Data";
import CardHeader from "./Component/CardHeader";

interface IRestroAccountProps { }
const accountInformation = [
    { title: "Bank Name", value: "Foodie Bank Ltd." },
    { title: "Account Number", value: "123456789012345" },
    { title: "IFSC Code", value: "FOOD12345" },
    { title: "GST Number", value: "29ABCDE1234F2Z5" },
    { title: "PAN Number", value: "ABCDE1234F" }
];
const RestroAccount: React.FC<IRestroAccountProps> = (props) => {
    return (
            <div className={Styles.ProfileCard}>
            <CardHeader header="Account" onEdit={()=>{}} />
            <div className={Styles.ProfileCardBody}>
                <div className="grid w-full grid-cols-2 items-end gap-6">
                    {accountInformation.map((item, index) => (
                        <Data key={index} title={item.title} value={item.value} />
                    ))}
                </div>
            </div>
        </div>
    )
}

export default RestroAccount;