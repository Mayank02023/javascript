import React from "react";
import Styles from "./Profile.module.scss";
import { mergeClasses } from "@fluentui/react-components";

interface IRestroDetailsProps { }

const RestroDetails: React.FC<IRestroDetailsProps> = (props) => {
    return (
            <div className={mergeClasses(Styles.ProfileCard, "!h-auto")}>
                <div className=" flex justify-start items-center gap-6 px-9">
                    <img src="./img/Designer.jpeg" alt="Restro Logo" className="w-32 h-32 rounded-full" />
                    <div className="flex flex-col justify-start items-start gap-1 !min-w-[350px]">
                        <span className="font-bold text-5xl">Gourmet Bistro</span>
                        <span className="font-semibold text-[#939393] text-xl">Restuarant Type</span>
                    </div>
                    <hr className="w-[1px] h-36 bg-gray-300" />
                    <span className="font-semibold text-gray-800 text-[15px]">
                        Welcome to My Restaurant, where exceptional flavors meet a cozy, inviting atmosphere. Our menu offers a diverse selection of expertly crafted dishes, from classic favorites to unique culinary creations. Every ingredient is carefully sourced to ensure the highest quality, and our chefs are dedicated to bringing out the best in each meal. Whether you're joining us for a casual meal with friends or a special celebration, you'll experience top-notch service and a warm, welcoming environment. Come dine with us and indulge in an unforgettable dining experience.
                    </span>
                </div>
            </div>
    )
}

export default RestroDetails;