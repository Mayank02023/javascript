import React from "react";
import Styles from "../Profile.module.scss";
import { DialogForm } from "../../../Components";

interface IEditAccountDetailsProps {
    isOpen: boolean;
    data?: any;
    onClose: (isOpen: boolean) => void;
}

const EditAccountDetails: React.FC<IEditAccountDetailsProps> = ({ isOpen, data, onClose }) => {
    return (
        <DialogForm
            isOpen={isOpen}
            formHeader={{
                title: "Edit Account Details",
                onClose: onClose,
            }}
            onSubmit={handleSubmit}
            hasError={hasError}
        >
            <div className={Styles.FormBody}>
                <div className="mt-3">
                    <InputField
                        type="text"
                        name="displayName"
                        label="Shift Name"
                        value={shift.displayName}
                        setValue={(value, name) => handleChange(value, name as keyof IShiftState)}
                        placeholder="Enter shift name"
                        error={error.displayName}
                    />
                </div>
            </div>
        </DialogForm>
    )
}