import React from "react";
import Styles from "./Profile.module.scss";
import Data from "./Component/Data";
import CardHeader from "./Component/CardHeader";

interface IRestroPersonalDetailsProps { }
const personalInformation = [
    { title: "Restaurant Name", value: "Gourmet Bistro" },
    { title: "Owner Name", value: "John Doe" },
    { title: "Cuisine Speciality", value: "Italian and Continental" },
    { title: "Established Year", value: "2010" },
    { title: "Awards", value: "Best Fine Dining 2022" },
    { title: "Operational Hours", value: "10:00 AM - 11:00 PM" },
    { title: "Branches", value: 3 },
    { title: "Employees", value: 25 },
    { title: "Tables", value: 15 },
    { title: "Rating", value: 4.5 },
    { title: "Reviews", value: 120 }

]
const RestroPersonalDetails: React.FC<IRestroPersonalDetailsProps> = (props) => {
    return (
        <div className={Styles.ProfileCard}>
            <CardHeader header="Personal" onEdit={()=>{}} />
            <div className={Styles.ProfileCardBody}>
                <div className="grid w-full grid-cols-2 items-end gap-6">
                    {personalInformation.map((item, index) => (
                        <Data key={index} title={item.title} value={item.value} />
                    ))}
                </div>
            </div>
        </div>
    )
}

export default RestroPersonalDetails;
