import React, { useEffect, useState } from "react";
import Styles from "./Worker.module.scss";
import validation from "../../Utils/Validations/Validation";
import { InputField, DialogForm } from "../../Components";
import { IWorkerRoleRequest, IWorkerRoleResponse } from "../../Types/worker"; // Update import for shift types
import { useDispatch } from "react-redux";
import { initialRoleState, initialRoleErrorState, resetRoleForm } from "../../Utils/Worker";
import { IApiResponse } from "../../Types";
import workerShiftController from "../../DataProvider/Controllers/WorkerShiftsController";
import { createWorkerShift, updateWorkerShift } from "../../Store/Slices/workerShiftSlice";

// Error state interface matches the IWorkerShiftRequest structure
interface IShiftState extends IWorkerRoleRequest { }
interface IShiftErrorState extends IWorkerRoleRequest { }
interface IShiftFormProps {
    isOpen: boolean;
    data?: IWorkerRoleResponse;
    onClose: (isOpen: boolean) => void;
}

const ShiftForm: React.FC<IShiftFormProps> = ({ isOpen, data = undefined, onClose }) => {
    const [loading, setLoading] = useState<boolean>(true);
    const [shift, setShift] = useState<IShiftState>(initialRoleState);
    const [error, setError] = useState<IShiftErrorState>(initialRoleErrorState);
    const [hasError, setHasError] = useState<boolean>(true);

    const dispatch = useDispatch();

    // Populate form with worker shift data when editing
    useEffect(() => {
        const validateAndCheck = async () => {
            if (data) {
                const shiftData = resetRoleForm(data);
                const err = await validation.fieldValidation(data.displayName, `displayName`);
                setError((prevErrors) => ({ ...prevErrors, ["displayName"]: err }));
                setShift(() => shiftData);
                setHasError(() => !!err); // Set hasError based on validation
            }
        };
        if (data) {
            validateAndCheck();
        }
    }, [data]);

    // Reset the form to the initial state
    const handleResetForm = () => {
        setShift(resetRoleForm());
        setError(initialRoleErrorState);
    };

    // Handle input changes
    const handleChange = async (value: string, name: string) => {
        const err = await validation.fieldValidation(value, name);
        setError(prevError => ({ ...prevError, [name]: err }));
        setShift(prevShift => ({ ...prevShift, [name]: value }));
        setHasError(() => !!err); // Update hasError based on validation
    };

    // Handle form submit
    const handleSubmit = async (event: React.FormEvent) => {
        event.preventDefault();
        setLoading(() => true);
        // Validate fields before making API call
        const err = await validation.fieldValidation(shift[`displayName`], `shiftName`); // Validate shiftName
        if (err) {
            setHasError(() => true);
            return;
        }
        try {
            const shiftData: any = {
                id: shift._id,
                displayName: shift.displayName,
                // Add other shift properties if necessary
            };
            // Check if updating or creating a new shift
            const response: IApiResponse = data
                ? await workerShiftController.updateWorkerShift(shiftData)
                : await workerShiftController.addWorkerShift(shiftData);

            if (response.success) {
                const action = data ? updateWorkerShift : createWorkerShift;
                dispatch(action(response.data));
                handleResetForm();
                onClose(true);
            } else {
                console.log(response.message || 'Operation failed');
                return;
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <DialogForm
            isOpen={isOpen}
            formHeader={{
                title: data ? "Edit Shift" : "Add Shift",
                onClose: onClose,
            }}
            onSubmit={handleSubmit}
            hasError={hasError}
        >
            <div className={Styles.FormBody}>
                <div className="mt-3">
                    <InputField
                        type="text"
                        name="displayName"
                        label="Shift Name"
                        value={shift.displayName}
                        setValue={(value, name) => handleChange(value, name as keyof IShiftState)}
                        placeholder="Enter shift name"
                        error={error.displayName}
                    />
                </div>
            </div>
        </DialogForm>
    );
};

export default ShiftForm;
