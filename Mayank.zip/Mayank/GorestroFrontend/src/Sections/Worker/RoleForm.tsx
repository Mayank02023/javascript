import React, { useEffect, useState } from "react";
import Styles from "./Worker.module.scss";
import validation from "../../Utils/Validations/Validation";
import { InputField, DialogForm } from "../../Components";
import { IWorkerRoleRequest, IWorkerRoleResponse } from "../../Types/worker";
import { useDispatch } from "react-redux";
import { initialRoleErrorState, initialRoleState, initialWorkerErrorState, resetRoleForm } from "../../Utils/Worker";
import workerRoleController from "../../DataProvider/Controllers/WorkerRolesController";
import { createWorkerRole, updateWorkerRole } from "../../Store/Slices/workerRoleSlice";
import { IApiResponse } from "../../Types";

// Error state interface matches the IWorkerRoleRequest structure
interface IRoleState extends IWorkerRoleRequest { }
interface IRoleErrorState extends IWorkerRoleRequest { }
interface IRoleFormProps {
    isOpen: boolean;
    data?: IWorkerRoleResponse;
    onClose: (isOpen: boolean) => void;
}

const RoleForm: React.FC<IRoleFormProps> = ({ isOpen, data = undefined, onClose }) => {
    const [loading, setLoading] = useState<boolean>(true);
    const [role, setRole] = useState<IRoleState>(initialRoleState);
    const [error, setError] = useState<IRoleErrorState>(initialRoleErrorState);
    const [hasError, setHasError] = useState<boolean>(true);

    const dispatch = useDispatch();
    // Populate form with worker data when editing
    useEffect(() => {
        const validateAndCheck = async () => {
            if (data) {
                const roleData = resetRoleForm(data);
                const err = await validation.fieldValidation(data[`displayName`], `displayName`);
                setError((prevErrors) => ({ ...prevErrors, ["displayName"]: err }));
                setRole(() => roleData);
                if (err) {
                    setHasError(() => true);
                } else {
                    setHasError(() => false);
                }
            }
        };
        if (data) {
            validateAndCheck();
        }
    }, [data]);


    // Reset the form to the initial state
    const handleResetForm = () => {
        setRole(resetRoleForm());
        setError(initialWorkerErrorState);
    };

    // Handle input changes
    const handleChange = async (value: string, name: string) => {
        const err = await validation.fieldValidation(value, name);
        setError(prevError => ({ ...prevError, [name]: err }));
        setRole(prevUser => ({ ...prevUser, [name]: value }));
        if (err) {
            setHasError(() => true);
        } else {
            setHasError(() => false);
        }
    };

    // handle form submit
    const handleSubmit = async (event: React.FormEvent) => {
        event.preventDefault();
        setLoading(() => true);
        // Validate fields before making API call
        const err = await validation.fieldValidation(role[`displayName`], `displayName`);
        if (err) {
            setHasError(() => true);
            return;
        }
        try {
            const roleData: any = {
                id: role._id,
                displayName: role.displayName,
            };
            // Check if updating or creating new worker
            const response: IApiResponse = data
                ? await workerRoleController.updateWorkerRole(roleData)
                : await workerRoleController.addWorkerRole(roleData);

            if (response.success) {
                const action = data ? updateWorkerRole : createWorkerRole;
                dispatch(action(response.data));
                handleResetForm();
                onClose(true);
            } else {
                console.log(response.message || 'Operation failed');
                return;
            }
        } finally {
            setLoading(false);
        }
    };


    return (
        <DialogForm
            isOpen={isOpen}
            formHeader={{
                title: data ? "Edit Role" : "Add Role",
                onClose: onClose,
            }}
            onSubmit={handleSubmit}
            hasError={hasError}
        >
            <div className={Styles.FormBody}>
                <div className="mt-3">
                    <InputField
                        type="text"
                        name="displayName"
                        label="Role title"
                        value={role.displayName}
                        setValue={(value, name) => handleChange(value, name as keyof IRoleState)}
                        placeholder="Enter role"
                        error={error.displayName}
                    />
                </div>
            </div>
        </DialogForm>
    );

};

export default RoleForm;
