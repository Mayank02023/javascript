import React, { useEffect, useState } from "react";
import Styles from "./Worker.module.scss";
import validation from "../../Utils/Validations/Validation";
import { InputField, DialogForm, Dropdown } from "../../Components";
import { IWorkerRequest, IWorkerResponse, IWorkerRoleResponse } from "../../Types/worker";
import workerController from "../../DataProvider/Controllers/WorkerController";
import { useDispatch, useSelector } from "react-redux";
import { createWorker, updateWorker } from "../../Store/Slices/workerSlice";
import { formatRolesAndShifts, handleValidations, initialWorkerErrorState, initialWorkerState, resetWorkerForm } from "../../Utils/Worker";
import { roleOptions, shiftOptions } from "../../Constants/worker";
import { convertDateIntoTimeStamp } from "../../Utils/basic";
import { IApiResponse } from "../../Types";
import workerRoleController from "../../DataProvider/Controllers/WorkerRolesController";
import { setWorkerRole } from "../../Store/Slices/workerRoleSlice";
import workerShiftController from "../../DataProvider/Controllers/WorkerShiftsController";
import { IOption } from "../../Components/DataFields/Dropdown";
import { setWorkerShift } from "../../Store/Slices/workerShiftSlice";

interface IWorkerState extends IWorkerRequest { }
interface IWorkerErrorState extends IWorkerRequest { }
interface IWorkerFormProps {
    isOpen: boolean;
    data?: IWorkerResponse;
    onClose: (isOpen: boolean) => void;
}

const WorkerForm: React.FC<IWorkerFormProps> = ({ isOpen, data = undefined, onClose }) => {
    const workerRoles: IWorkerRoleResponse[] = useSelector((state: any) => state.workerRole.workerRoles);
    const workerShifts: IWorkerRoleResponse[] = useSelector((state: any) => state.workerShift.workerShifts); // Use correct slice for shifts
    const [workersRole, setWorkersRole] = useState<IOption[]>([]);
    const [workersShift, setWorkersShift] = useState<IOption[]>([]);
    const [worker, setWorker] = useState<IWorkerState>(initialWorkerState);
    const [error, setError] = useState<IWorkerErrorState>(initialWorkerErrorState);
    const [hasError, setHasError] = useState<boolean>(true);
    const [activeStep, setActiveStep] = useState<number>(1);
    const [loading, setLoading] = useState<boolean>(true);

    const dispatch = useDispatch();

    /**
     * Fetch worker roles on component mount and set them to Redux store.
     */
    const handleLoadRoles = async () => {
        try {
            const workerRolesResponse: IApiResponse = await workerRoleController.getWorkerRoles();
            if (workerRolesResponse.success) dispatch(setWorkerRole(workerRolesResponse.data));
        } catch (error) {
            console.error("Error loading worker roles", error);
        }
    };

    /**
     * Fetch worker shifts on component mount and set them to Redux store.
     */
    const handleLoadShifts = async () => {
        try {
            const workerShiftsResponse: IApiResponse = await workerShiftController.getWorkerShifts();
            if (workerShiftsResponse.success) dispatch(setWorkerShift(workerShiftsResponse.data)); // Dispatch correct action
        } catch (error) {
            console.error("Error loading worker shifts", error);
        }
    };

    useEffect(() => {
        // Load roles and shifts only if not already available in the Redux store
        const validateAndCheck = async () => {
            if (!workerRoles || workerRoles.length === 0) {
                await handleLoadRoles();
            }
            if (!workerShifts || workerShifts.length === 0) {
                await handleLoadShifts();
            }
            if (workerRoles.length > 0) {
                const roleOptions = formatRolesAndShifts(workerRoles);
                setWorkersRole(() => roleOptions); // Set role options correctly
            }
            if (workerShifts.length > 0) {
                const shiftOptions = formatRolesAndShifts(workerShifts);
                setWorkersShift(() => shiftOptions); // Set shift options correctly
            }
        };
        validateAndCheck();
    }, [workerRoles, workerShifts, dispatch]);

    // Populate form with worker data when editing
    useEffect(() => {
        const validateAndCheck = async () => {
            setLoading(true);
            const workerData = resetWorkerForm(data);
            await validateStepFields();
            setWorker(workerData);
            setLoading(false);
        };
        if (data) {
            validateAndCheck();
        } else {
            setLoading(false);
        }
    }, [data]);

    const stepsItems = ["Basic Details", "Personal Details", "Address"];
    const stepFields = [
        ["displayName", "shiftId", "roleId", "username", "password"] as (keyof IWorkerState)[],
        ["position", "phoneNumber", "dob", "aadharCard", "panCard"] as (keyof IWorkerState)[],
        ["address", "city", "state", "country", "pincode"] as (keyof IWorkerState)[]
    ];

    const handleResetForm = () => {
        setWorker(resetWorkerForm());
        setError(initialWorkerErrorState);
        setHasError(false);
        setActiveStep(1);
    };

    const handleInputChange = async (value: string, name: keyof IWorkerState) => {
        const err = await validation.fieldValidation(value, name);
        setError((prevError) => ({ ...prevError, [name]: err }));
        setHasError(() => !!err);
        setWorker((prevWorker) => ({ ...prevWorker, [name]: value }));
    };

    const validateStepFields = async (): Promise<boolean> => {
        let fields = stepFields[activeStep - 1];
        if (data) {
            fields = fields.filter((key: string) => key !== 'username' && key !== 'password');
        }
        const { hasError, errors } = await handleValidations(fields, worker, error);
        setHasError(hasError);
        setError(errors || error);
        return !hasError;
    };

    const handleStepChange = (direction: "forward" | "backward") => {
        setActiveStep((prevStep) => (direction === "forward" ? prevStep + 1 : prevStep - 1));
    };

    const handleSubmit = async (event: React.FormEvent) => {
        event.preventDefault();
        const isValid = await validateStepFields();
        if (!isValid) return;
        const workerData: any = {
            ...worker,
            dob: convertDateIntoTimeStamp(worker.dob),
        };

        // Check if updating or adding a new worker
        const response: IApiResponse = data
            ? await workerController.updateWorker(workerData)
            : await workerController.addWorker(workerData);

        if (response.success) {
            const action = data ? updateWorker : createWorker;
            dispatch(action(response.data));
            handleResetForm();
            onClose(true);
        } else {
            console.log(response.message || 'Operation failed');
            return;
        }
    };

    useEffect(() => {
        if (!data) {
            handleResetForm();
        }
    }, [isOpen]);

    const renderStepFields = () => {
        if (loading) {
            return <div>Loading...</div>;
        }

        switch (activeStep) {
            case 1:
                return (
                    <div className="mt-3">
                        <InputField
                            type="text"
                            name="displayName"
                            label="Worker name"
                            value={worker.displayName}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter worker name"
                            error={error.displayName}
                        />
                        <Dropdown
                            name="shiftId"
                            label="Shift"
                            options={workersShift}
                            value={worker.shiftId}
                            setValue={(value, name) => handleInputChange(value.id, name as keyof IWorkerState)}
                            error={error.shiftId}
                        />
                        <Dropdown
                            name="roleId"
                            label="Role"
                            options={workersRole}
                            value={worker.roleId}
                            setValue={(value, name) => handleInputChange(value.id, name as keyof IWorkerState)}
                            error={error.roleId}
                        />
                        <InputField
                            type="email"
                            name="username"
                            label="Username"
                            value={worker.username}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter username"
                            error={error.username}
                            readOnly={!!data}
                            autoComplete="off"
                        />
                        <InputField
                            type="password"
                            name="password"
                            label="Password"
                            value={data ? `********` : worker.password}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter password"
                            error={error.password}
                            readOnly={!!data}
                            autoComplete="new-password"
                        />
                    </div>
                );
            case 2:
                return (
                    <div className="mt-3">
                        <InputField
                            type="text"
                            name="position"
                            label="Position"
                            value={worker.position}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter position"
                            error={error.position}
                        />
                        <InputField
                            type="text"
                            name="phoneNumber"
                            label="Phone Number"
                            value={worker.phoneNumber}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter phone number"
                            error={error.phoneNumber}
                        />
                        <InputField
                            type="date"
                            name="dob"
                            label="Date of Birth"
                            value={worker.dob}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            error={error.dob}
                        />
                        <InputField
                            type="text"
                            name="aadharCard"
                            label="Aadhar Card"
                            value={worker.aadharCard}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter Aadhar Card number"
                            error={error.aadharCard}
                        />
                        <InputField
                            type="text"
                            name="panCard"
                            label="PAN Card"
                            value={worker.panCard}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter PAN Card number"
                            error={error.panCard}
                        />
                    </div>
                );
            case 3:
                return (
                    <div className="mt-3">
                        <InputField
                            type="text"
                            name="address"
                            label="Address"
                            value={worker.address}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter address"
                            error={error.address}
                        />
                        <InputField
                            type="text"
                            name="city"
                            label="City"
                            value={worker.city}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter city"
                            error={error.city}
                        />
                        <InputField
                            type="text"
                            name="state"
                            label="State"
                            value={worker.state}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter state"
                            error={error.state}
                        />
                        <InputField
                            type="text"
                            name="country"
                            label="Country"
                            value={worker.country}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter country"
                            error={error.country}
                        />
                        <InputField
                            type="text"
                            name="pincode"
                            label="Pincode"
                            value={worker.pincode}
                            setValue={(value, name) => handleInputChange(value, name as keyof IWorkerState)}
                            placeholder="Enter pincode"
                            error={error.pincode}
                        />
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <DialogForm
            isOpen={isOpen}
            formHeader={{
                title: data ? "Edit Worker" : "Add Worker",
                onClose: onClose,
            }}
            stepper={{
                activeStep: activeStep,
                steps: stepsItems,
                handleStepClick: handleStepChange,
            }}
            onSubmit={handleSubmit}
            hasError={hasError}
        >
            <div className={Styles.FormBody}>
                {renderStepFields()}
            </div>
        </DialogForm>
    );
};

export default WorkerForm;


