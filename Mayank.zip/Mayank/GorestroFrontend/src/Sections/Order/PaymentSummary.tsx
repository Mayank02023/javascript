import React, { useEffect, useState } from "react";
import cssStyles from "./PaymentSummary.module.scss";
import { IOrderItemResponse, IOrderResponse } from "../../Types/order";
import { FoodCard } from "../../Components";
import Flex, { AlignItems, FlexDirection } from "../../Components/Flex/Flex";
import { Button, mergeClasses } from "@fluentui/react-components";
import OrderForm from "./OrderForm";
import { useDispatch } from "react-redux";
import { updateCurrentOrder } from "../../Store/Slices/orderSlice";
interface IPaymentSummaryProps {
    handleQuantity: (quantity: number, productId: string) => void;
    className?: any;
    order: IOrderResponse;


}
const PaymentSummary: React.FC<IPaymentSummaryProps> = ({ order, handleQuantity, className = undefined }) => {
    const dispatch = useDispatch();
    const { _id, items } = order;
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [paymentSummery, setPaymentSummary] = useState({
        items: 0,
        subTotal: 0.0,
        discount: 0.0,
        tax: 0.0,
        total: 0.0
    });

    // Calculate total items, sub total, discount, tax, and total amount
    useEffect(() => {
        const totalItems = order.items.reduce((total, item) => total + Number(item.quantity), 0);
        const subTotal = order.items.reduce((total, item) => total + (Number(item.price) * Number(item.quantity)), 0);
        const discount = (subTotal * 10) / 100;
        const tax = ((subTotal - discount) * 18) / 100;
        const total = subTotal - discount + tax;
        dispatch(updateCurrentOrder({ ...order, totalAmount: total }));
        setPaymentSummary({ items: totalItems, subTotal, discount, tax, total });
    }, [order.items]);

    /**
    * Toggle the form dialog (Add/Edit).
    * @param isOpen - Whether the form dialog is open or closed
    */
    const handleDialogToggle = (isOpen: boolean) => {
        setIsOpen(isOpen);
    };

    return (
        <div className={mergeClasses(cssStyles.PaymentSummary, className)}>
            <span className={cssStyles.Username}>{order.customerName}</span>
            {_id && (
                <>
                    <Flex className={cssStyles.OrderDetails} direction={FlexDirection.COLUMN}>
                        <Flex className={cssStyles.Header}>
                            <span className={cssStyles.Id}>{`#${order._id}`}</span>
                            {order.tableNumber && <span className={cssStyles.TableNo}>{`Table-${order.tableNumber}`}</span>}
                        </Flex>

                        <Flex className={cssStyles.Footer}>
                            <Flex className="gap-1">
                                <span className={cssStyles.AcceptedBy}>Accepted by :</span>
                                <span className={cssStyles.AcceptedByName}>{order?.customerName ? order?.customerName : "Not assign"}</span>
                            </Flex>
                            <span className={`${cssStyles.Status} ${order.status.displayName === "Preparing" && `bg-[#fdb42c]`}`}>{order.status.displayName}</span>
                        </Flex>
                    </Flex>
                    <hr className="w-full mt-2 mb-1" />
                </>
            )}

            <div className={mergeClasses(cssStyles.FoodCardList,
                order._id === "" ?
                    order.items.length === 0 ?
                        cssStyles.NewOrderWithNoFoodCardList :
                        cssStyles.NewOrderWithFoodCardList :
                    order.items.length === 0 && cssStyles.NoFoodCardList
            )}>
                {order.items.length > 0 ? order.items?.map((foodCard: IOrderItemResponse) => (
                    <FoodCard
                        id={foodCard.productId}
                        title={foodCard.displayName}
                        items={foodCard.quantity}
                        avatar={foodCard.avatar}
                        price={foodCard.price}
                        handleQuantity={handleQuantity}
                    />
                )) : (
                    <span className="h-full flex justify-center items-center text-3xl font-bold">No Item Selected</span>
                )}
            </div>
            {order.items.length > 0 && (
                <>
                    <div
                        className={`${cssStyles.OrderSummery} ${className} ${status === "pending" ? `${cssStyles.IsPending}` : status === "progress" ? `${cssStyles.IsProgress}` : status === "completed" ? `${cssStyles.IsCompleted}` : ``}`}
                    >
                        <Flex className={cssStyles.SummeryDetails}>
                            <Flex className={cssStyles.Labels} direction={FlexDirection.COLUMN} alignItems={AlignItems.START}>
                                <span>Items :</span>
                                <span>Sub Total :</span>
                                <span>discount :</span>
                                <span>Tax :</span>
                            </Flex>
                            <Flex className={cssStyles.DataValues} direction={FlexDirection.COLUMN} alignItems={AlignItems.START}>
                                <span>{paymentSummery.items}</span>
                                <span>₹{paymentSummery.subTotal.toFixed(2)}</span>
                                <span>₹{paymentSummery.discount.toFixed(2)}</span>
                                <span>₹{paymentSummery.tax.toFixed(2)}</span>
                            </Flex>
                        </Flex>
                        <hr className=" w-full my-3" />
                        <Flex className={cssStyles.TotalAmount}>
                            <span className={cssStyles.Label}>Total :</span>
                            <span className={cssStyles.DataValue}>₹{paymentSummery.total.toFixed(2)}</span>
                        </Flex>
                    </div>
                    <Button
                        disabled={items.length === 0}
                        children="Process Transactions"
                        className={cssStyles.TransactionsButton}
                        onClick={() => setIsOpen(true)}
                        shape="rounded"
                        size="large"
                        color="#ffc107"
                    />
                    {isOpen && <OrderForm
                        isOpen={isOpen}
                        onClose={() => handleDialogToggle(false)}
                    />}
                </>
            )}
        </div>
    );
}

export default PaymentSummary;