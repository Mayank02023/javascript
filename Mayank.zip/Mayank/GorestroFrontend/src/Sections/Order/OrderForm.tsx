import React, { useEffect, useState, useCallback } from "react";
import cssStyles from "./PaymentSummary.module.scss";
import { DialogForm, InputField, Dropdown, NumberField } from "../../Components";
import orderController from "../../DataProvider/Controllers/OrdersController";
import {
    IApiResponse,
    IOrderRequest,
    IOrderResponse,
    IRestaurantResponse,
    IOrderItemRequest,
    IOrderStatusResponse,
} from "../../Types";
import { createOrder, resetCurrentOrder, updateCurrentOrder, updateOrder } from "../../Store/Slices/orderSlice";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Spinner } from "@fluentui/react-components";
import orderStatusController from "../../DataProvider/Controllers/OrderStatusController";
import { setOrderStatuses } from "../../Store/Slices/orderStatusSlice";
import { formatRolesAndShifts } from "../../Utils/Worker";
interface IOption {
    id: string;
    header: string
}

interface IOrderFormProps {
    isOpen: boolean;
    onClose: () => void;
}

interface IOrderFormErrorState {
    customerName: string;
    customerNumber: string;
    tableNumber: string;
    status: string;
}

const OrderForm: React.FC<IOrderFormProps> = ({ isOpen, onClose }) => {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    // Selectors with proper typing
    const user: IRestaurantResponse = useSelector((state: any) => state.auth.userData);
    const currentOrder: IOrderResponse = useSelector((state: any) => state.orders.currentOrder);
    const orderStatuses: IOrderStatusResponse[] = useSelector((state: any) => state.orderStatuses.orderStatuses);

    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<IOrderFormErrorState>({
        customerName: "",
        customerNumber: "",
        tableNumber: "",
        status: ""
    });

    // Initialize the form fields when the current order changes
    const [localOrder, setLocalOrder] = useState<IOrderResponse>(currentOrder);

    useEffect(() => {
        setLocalOrder(currentOrder);
    }, [currentOrder]);

    useEffect(() => {
        const loadOrders = async () => {
            try {
                if (user._id && orderStatuses.length === 0) {
                    orderStatusController.getOrderStatuses().then((response: IApiResponse) => {
                        if (response.success) dispatch(setOrderStatuses(response.data));
                    });
                }
            } catch (error) {
                console.error("Error loading orders", error);
            }
        };
        loadOrders();
    }, []);

    const getStatusOptions = (): IOption[] => {
        return orderStatuses.map((status: IOrderStatusResponse) => ({
            id: status._id,
            header: status.displayName,
        }));
    }

    useEffect(() => {
        setLocalOrder(currentOrder);
    }, [currentOrder]);


    const [hasError, setHasError] = useState<boolean>(true);

    const formValidation = useCallback((value: string | number | null, fieldName: string): string => {
        let error = "";
        switch (fieldName) {
            case "customerName":
                if (typeof value === "string") {
                    if (value.trim() === "") {
                        error = "Name is required";
                    } else if (value.length < 3 || value.length > 100) {
                        error = "Name must be between 3 and 100 characters";
                    }
                } else {
                    error = "Invalid name";
                }
                break;
            case "customerNumber":
                if (typeof value === "string") {
                    if (value.trim() === "") {
                        error = "Contact No. is required";
                    } else if (!/^\+\d+$/.test(value)) {
                        error = "Contact must start with + and country code";
                    }
                } else {
                    error = "Invalid contact number";
                }
                break;
            case "tableNumber":
                if (typeof value === "number") {
                    if (value <= 0) {
                        error = "Table number must be a positive number";
                    }
                } else {
                    error = "Invalid table number";
                }
                break;
            default:
                break;
        }
        return error;
    }, []);

    const handleHasError = (error: IOrderFormErrorState, currentOrder: IOrderResponse): boolean => {
        const hasErrors = Object.values(error).some((err) => err !== "");
        const hasEmptyField = [
            currentOrder.customerName,
            currentOrder.customerNumber,
            currentOrder.tableNumber,
        ].some((field) => !field);
        setHasError(() => hasErrors || hasEmptyField);
        return hasErrors || hasEmptyField;
    };

    const validateAllFields = useCallback((): boolean => {
        const fields: Array<keyof typeof error> = ["customerName", "customerNumber", "tableNumber"];
        const newErrors: typeof error = { ...error };

        fields.forEach((field) => {
            let value: string | number | null = null;
            if (field === "customerName") value = localOrder.customerName;
            if (field === "customerNumber") value = localOrder.customerNumber;
            if (field === "tableNumber") value = localOrder.tableNumber;

            newErrors[field] = formValidation(value, field);
        });
        setError(newErrors);
        return handleHasError(newErrors, localOrder);
    }, [localOrder, formValidation]);

    useEffect(() => {
        if (localOrder._id) {
            validateAllFields();
        }
    }, [localOrder, validateAllFields]);

    const handleSubmit = async (event: React.FormEvent) => {
        event.preventDefault();
        const hasError = validateAllFields();

        if (hasError) {
            return;
        }

        setLoading(true);

        try {
            const items: IOrderItemRequest[] = localOrder.items.map((item) => ({
                productId: item.productId,
                quantity: item.quantity,
                price: item.price,
            }));

            const OrderState: IOrderRequest = {
                id: localOrder._id,
                statusId: localOrder.status.id,
                items: items,
                customerName: localOrder.customerName,
                customerNumber: localOrder.customerNumber,
                tableNumber: localOrder.tableNumber,
                totalAmount: Math.floor(localOrder.totalAmount),
            };

            const response: IApiResponse =
                localOrder._id !== ""
                    ? await orderController.updateOrder(OrderState)
                    : await orderController.addOrder(OrderState, user._id);

            if (response.success && response.data) {
                const action = localOrder._id !== "" ? updateOrder : createOrder;
                dispatch(action(localOrder));
                dispatch(resetCurrentOrder());
                onClose();
                navigate(-1);
            } else {
                console.error(response.message || "Operation failed");
            }
        } catch (err) {
            console.error("An error occurred while processing the order:", err);
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (value: string | number, name: keyof IOrderResponse) => {
        const updatedOrder = { ...localOrder, [name]: value };
        setLocalOrder(updatedOrder);
        dispatch(updateCurrentOrder(updatedOrder));

        const fieldError = formValidation(value, name);
        handleHasError({ ...error, [name]: fieldError }, updatedOrder);

        setError((prevError) => ({ ...prevError, [name]: fieldError }));
    };

    const handleStatusChange = (value: IOption, name: keyof IOrderResponse) => {
        const updatedOrder = {
            ...localOrder, [name]: { id: value.id, displayName: value.header }
        };
        setLocalOrder(updatedOrder);
        dispatch(updateCurrentOrder(updatedOrder));

        const fieldError = formValidation(value.id, name);
        handleHasError({ ...error, [name]: fieldError }, updatedOrder);

        setError((prevError) => ({ ...prevError, [name]: fieldError }));
    };

    return (
        <DialogForm
            isOpen={isOpen}
            formHeader={{
                title: localOrder._id !== "" ? "Edit Order" : "Add New Order",
                onClose: onClose,
                btnText: "Process Order",
            }}
            onSubmit={handleSubmit}
            hasError={hasError}
        >
            {!loading ? (
                <div className={cssStyles.FormBody}>
                    <div className="mt-1">
                        <InputField
                            type="text"
                            name="customerName"
                            label="Customer Name"
                            value={localOrder.customerName || ""}
                            setValue={(value, name) => handleInputChange(value, name as keyof IOrderResponse)}
                            placeholder="Enter customer name"
                            error={error.customerName}
                        />
                        <Dropdown
                            name="status"
                            label="Status"
                            options={getStatusOptions()}
                            value={localOrder.status.id || ""}
                            setValue={(value, name) => handleStatusChange(value, name as keyof IOrderResponse)}
                            error={error.status}
                        />
                        <InputField
                            type="text"
                            name="customerNumber"
                            label="Customer Number"
                            value={localOrder.customerNumber || ""}
                            setValue={(value, name) => handleInputChange(value, name as keyof IOrderResponse)}
                            placeholder="Enter customer number"
                            error={error.customerNumber}
                        />
                        <NumberField
                            type="number"
                            name="tableNumber"
                            label="Table Number"
                            value={localOrder.tableNumber || 0}
                            setValue={(value, name) => handleInputChange(value, name as keyof IOrderResponse)}
                            placeholder="Enter table number"
                            error={error.tableNumber}
                        />
                    </div>
                </div>
            ) : (
                <div className=" flex justify-center items-center">
                    <Spinner />
                </div>
            )}
        </DialogForm>
    );
};

export default OrderForm;
