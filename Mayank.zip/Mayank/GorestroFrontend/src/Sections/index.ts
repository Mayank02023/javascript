import OrdersStatus from "./Dashboard/OrdersStatus";
import OrderForm from "./Order/OrderForm";
import PaymentSummary from "./Order/PaymentSummary";
import CategoryForm from "./Product/CategoryForm";
import ProductForm from "./Product/ProductForm";
import RestroAccount from "./Profile/RestroAccount";
import RestroAddress from "./Profile/RestroAddress";
import RestroDetails from "./Profile/RestroDetails";
import RestroPersonalDetails from "./Profile/RestroPersonalDetails";
import RoleForm from "./Worker/RoleForm";
import ShiftForm from "./Worker/ShiftForm";
import WorkerForm from "./Worker/WorkerForm";

export {
    OrdersStatus,
    WorkerForm,
    RoleForm,
    ShiftForm,
    ProductForm,
    CategoryForm,
    PaymentSummary,
    OrderForm,
    RestroDetails,
    RestroAccount,
    RestroAddress,
    RestroPersonalDetails,
}