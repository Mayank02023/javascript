import React, { useEffect, useState } from "react";
import Styles from "./Product.module.scss";
import validation from "../../Utils/Validations/Validation";
import { InputField, DialogForm } from "../../Components";
import { useDispatch } from "react-redux";
import { initialRoleErrorState, initialRoleState, initialWorkerErrorState, resetRoleForm } from "../../Utils/Worker";
import { createProductCategory, updateProductCategory } from "../../Store/Slices/productCategorySlice";
import { IApiResponse, IProductCategoryRequest, IProductCategoryResponse } from "../../Types";
import productCategoryController from "../../DataProvider/Controllers/ProductCategoryController";

// Error state interface matches the IProductCategoryRequest structure
interface ICategoryFormState extends IProductCategoryRequest { }
interface ICategoryFormErrorState extends IProductCategoryRequest { }
interface ICategoryFormProps {
    isOpen: boolean;
    data?: IProductCategoryResponse;
    onClose: (isOpen: boolean) => void;
}

const CategoryForm: React.FC<ICategoryFormProps> = ({ isOpen, data = undefined, onClose }) => {
    const [loading, setLoading] = useState<boolean>(true);
    const [category, setCategory] = useState<ICategoryFormState>(initialRoleState);
    const [error, setError] = useState<ICategoryFormErrorState>(initialRoleErrorState);
    const [hasError, setHasError] = useState<boolean>(true);

    const dispatch = useDispatch();
    // Populate form with Category data when editing`7
    useEffect(() => {
        const validateAndCheck = async () => {
            if (data) {
                const roleData = resetRoleForm(data);
                const err = await validation.fieldValidation(data[`displayName`], `displayName`);
                setError((prevErrors) => ({ ...prevErrors, ["displayName"]: err }));
                setCategory(() => roleData);
                if (err) {
                    setHasError(() => true);
                } else {
                    setHasError(() => false);
                }
            }
        };
        if (data) {
            validateAndCheck();
        }
    }, [data]);


    // Reset the form to the initial state
    const handleResetForm = () => {
        setCategory(resetRoleForm());
        setError(initialWorkerErrorState);
    };

    // Handle input changes
    const handleChange = async (value: string, name: string) => {
        const err = await validation.fieldValidation(value, name);
        setError(prevError => ({ ...prevError, [name]: err }));
        setCategory(prevUser => ({ ...prevUser, [name]: value }));
        if (err) {
            setHasError(() => true);
        } else {
            setHasError(() => false);
        }
    };

    // handle form submit
    const handleSubmit = async (event: React.FormEvent) => {
        event.preventDefault();
        setLoading(() => true);
        // Validate fields before making API call
        const err = await validation.fieldValidation(category.displayName, `displayName`);
        if (err) {
            setHasError(() => true);
            return;
        }
        try {
            const categoryData: any = {
                id: category._id,
                displayName: category.displayName,
            };
            // Check if updating or creating category
            const response: IApiResponse = data
                ? await productCategoryController.updateProductCategory(categoryData)
                : await productCategoryController.addProductCategory(categoryData);

            if (response.success) {
                const action = data ? updateProductCategory : createProductCategory;
                dispatch(action(response.data));
                handleResetForm();
                onClose(true);
            } else {
                console.log(response.message || 'Operation failed');
                return;
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <DialogForm
            isOpen={isOpen}
            formHeader={{
                title: data ? "Edit Category" : "Add Category",
                onClose: onClose,
            }}
            onSubmit={handleSubmit}
            hasError={hasError}
        >
            <div className={Styles.FormBody}>
                <div className="mt-3">
                    <InputField
                        type="text"
                        name="displayName"
                        label="Category Name"
                        value={category.displayName}
                        setValue={(value, name) => handleChange(value, name as keyof ICategoryFormState)}
                        placeholder="Enter Category Name"
                        error={error.displayName}
                    />
                </div>
            </div>
        </DialogForm>
    );

};

export default CategoryForm;
