import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux";
import { IApiResponse, IAuthResponse, IProductCategoryResponse, IProductRequest, IProductResponse } from "../../Types";
import { formatProduct, handleValidations, initialProductErrorState, initialProductState, resetProductForm, resetProductFormError } from "../../Utils/Products";
import Dropdown, { IOption } from "../../Components/DataFields/Dropdown";
import { DialogForm, ImageUpload, InputField, NumberField } from "../../Components";
import productCategoryController from "../../DataProvider/Controllers/ProductCategoryController";
import { setProductCategories } from "../../Store/Slices/productCategorySlice";
import { formatRolesAndShifts } from "../../Utils/Worker";
import validation from "../../Utils/Validations/Validation";
import { IProductRequestError } from "../../Types/products";
import productController from "../../DataProvider/Controllers/ProductController";
import { createProduct, updateProduct } from "../../Store/Slices/productSlice";
import Styles from "./Product.module.scss";
// Error state interface matches the IProductRequest structure
interface IProductFormState extends IProductRequest { }
interface IProductFormErrorState extends IProductRequestError { }
interface IProductFormProps {
    isOpen: boolean;
    data?: IProductResponse;
    onClose: (isOpen: boolean) => void;
}
const ProductForm: React.FC<IProductFormProps> = ({ isOpen, data = undefined, onClose }) => {
    const user: IAuthResponse = useSelector((state: any) => state.auth);
    const productCategories: IProductCategoryResponse[] = useSelector((state: any) => state.productCategory.categories);
    const [categories, setCategories] = useState<IOption[]>([]);
    const [product, setProduct] = useState<IProductFormState>(initialProductState);
    const [error, setError] = useState<IProductFormErrorState>(initialProductErrorState);
    const [hasError, setHasError] = useState<boolean>(true);
    const [loading, setLoading] = useState<boolean>(true);

    const dispatch = useDispatch();

    /**
     * Fetch product categories on component mount and set them to Redux store.
     */
    const handleLoadCategories = async () => {
        try {
            if (user?.userData?._id) {
                const productCategoriesResponse: IApiResponse = await productCategoryController.getProductCategories(user?.userData?._id)
                if (productCategoriesResponse.success) dispatch(setProductCategories(productCategoriesResponse.data));
            }
        } catch (error) {
            console.error("Error loading product categories", error);
        }
    };

    useEffect(() => {
        // Load product categories only if not already available in the Redux store
        const validateAndCheck = async () => {
            if (!productCategories || productCategories.length === 0) {
                await handleLoadCategories();
            }

            if (productCategories.length > 0) {
                const categoriesOptions = formatRolesAndShifts(productCategories);
                setCategories(() => categoriesOptions); // Set product categories options correctly
            }
        };
        validateAndCheck();
    }, [productCategories, , dispatch]);

    // Populate form with product data when editing
    useEffect(() => {
        const validateAndCheck = async () => {
            setLoading(true);
            const productData = resetProductForm(data);
            setProduct(productData);
            let fields = Array.from(Object.keys(productData)) as (keyof IProductRequest)[];
            const { hasError, errors } = await handleValidations(fields, productData, error);
            setHasError(hasError);
            errors && setError(errors);
            setLoading(false);
        };
        if (data) {
            validateAndCheck();
        } else {
            setLoading(false);
        }
    }, [data]);


    const handleResetForm = () => {
        setProduct(resetProductForm());
        setError(resetProductFormError());
        setHasError(false);
    };

    const handleInputChange = async (value: string | number, name: keyof IProductFormState) => {
        const err = await validation.fieldValidation(value, name);
        setError((prevError) => ({ ...prevError, [name]: err }));
        setHasError(() => !!err);
        setProduct((prevProduct) => ({ ...prevProduct, [name]: value }));
    };
    const handleImageSelect = (file: File | null, name: string) => {
        setProduct((prevProduct) => ({ ...prevProduct, [name]: file }));
    };

    const validateStepFields = async (): Promise<boolean> => {
        let fields = Array.from(Object.keys(product)) as (keyof IProductRequest)[];
        const { hasError, errors } = await handleValidations(fields, product, error);
        setHasError(hasError);
        errors && setError(errors);
        return !hasError;
    };

    useEffect(() => {
        let fields = Array.from(Object.keys(product)) as (keyof IProductRequest)[];
        setHasError(fields.some((key) => !product[key] || error[key]));
    }, [product]);

    const handleSubmit = async (event: React.FormEvent) => {
        event.preventDefault();
        const isValid = await validateStepFields();
        if (!isValid) return;

        const productData: any = {
            ...product,
            _id: data ? data._id : null,
        };

        delete productData.avatar; // Remove avatar field for update

        const selectedCategory = categories.find((category) => category.id === product.categoryId);
        if (!selectedCategory) {
            setError((prevError) => ({ ...prevError, categoryId: "Please select a valid category." }));
            setHasError(true);
            return;
        }
        try {
            const response: IApiResponse = data
                ? await productController.updateProduct(productData)
                : await productController.addProduct(productData, product.avatar);

            if (response.success) {
                const product: IProductResponse = formatProduct(response.data, selectedCategory);
                const action = data ? updateProduct : createProduct;
                dispatch(action(product));
                handleResetForm();
                onClose(true);
            } else {
                console.log(response.message || 'Operation failed');
                return;
            }
        } catch (error) {
            console.log('An unexpected error occurred');
            return;
        }
    };



    useEffect(() => {
        if (!data) {
            handleResetForm();
        }
    }, [isOpen]);


    const renderFields = () => {
        if (loading) {
            return <div>Loading...</div>;
        }

        return (
            <div className="mt-3">
                <InputField
                    type="text"
                    name="displayName"
                    label="Product Name"
                    value={product.displayName}
                    setValue={(value, name) => handleInputChange(value, name as keyof IProductFormState)}
                    placeholder="Enter product name"
                    error={error.displayName}
                />
                <Dropdown
                    name="categoryId"
                    label="Category"
                    options={categories}
                    value={product.categoryId}
                    setValue={(value, name) => handleInputChange(value.id, name as keyof IProductFormState)}
                    error={error.categoryId}
                />
                <InputField
                    type="text"
                    name="description"
                    label="Description"
                    value={product.description}
                    setValue={(value, name) => handleInputChange(value, name as keyof IProductFormState)}
                    placeholder="Enter product description"
                    error={error.description}
                />
                <NumberField
                    type="number"
                    name="price"
                    label="Price"
                    value={product.price}
                    setValue={(value, name) => handleInputChange(value, name as keyof IProductFormState)}
                    placeholder="Enter product price"
                    error={error.price}
                />
                <NumberField
                    type="number"
                    name="mrp"
                    label="MRP"
                    value={product.mrp}
                    setValue={(value, name) => handleInputChange(value, name as keyof IProductFormState)}
                    placeholder="Enter MRP"
                    error={error.mrp}
                />
                <ImageUpload
                    name="avatar"
                    label="Profile Picture"
                    onImageSelect={handleImageSelect}
                    error={error.avatar}
                />
            </div>
        );
    };

    return (
        <DialogForm
            isOpen={isOpen}
            formHeader={{
                title: data ? "Edit Product" : "Add Product",
                onClose: onClose,
            }}
            onSubmit={handleSubmit}
            hasError={hasError}
        >
            <div className={Styles.FormBody}>
                {renderFields()}
            </div>
        </DialogForm>
    )
}

export default ProductForm;

