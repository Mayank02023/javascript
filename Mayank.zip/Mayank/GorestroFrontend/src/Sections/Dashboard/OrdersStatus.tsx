import React, { useCallback, useEffect, useState } from "react";
import { IOrderResponse, IOrderStatusCardForDashboard, IOrderStatusResponse } from "../../Types/order";
import { Button, ConfirmDialog, Flex, OrderCard, OverviewCard } from "../../Components";
import { useNavigate } from "react-router-dom";
import { IApiResponse, IAuthResponse } from "../../Types";
import { useDispatch, useSelector } from "react-redux";
import orderController from "../../DataProvider/Controllers/OrdersController";
import { deleteOrder, setOrders, setOrdersLastTwoDays, updateCurrentOrder } from "../../Store/Slices/orderSlice";
import orderStatusController from "../../DataProvider/Controllers/OrderStatusController";
import { setOrderStatuses } from "../../Store/Slices/orderStatusSlice";



const deleteOrderContent = {
    header: "Delete Order",
    description: "Are you sure you want to delete this order? This action cannot be undone and may affect any workers assigned to this role.",
    btnText: "Delete",
};

const OrdersStatus: React.FC = () => {
    const user: IAuthResponse = useSelector((state: any) => state.auth);
    const orders: IOrderResponse[] = useSelector((state: any) => state.orders.orders);
    const lastTwoDaysOrders: {
        today: IOrderResponse[] | [];
        yesterday: IOrderResponse[] | [];
    } = useSelector((state: any) => state.orders.lastTwoDaysOrders);
    const orderStatuses: IOrderStatusResponse[] = useSelector((state: any) => state.orderStatuses.orderStatuses);
    const [orderStatus, setOrderStatus] = useState<string>("");
    const [filteredOrderStatusCards, setFilteredOrderStatusCards] = useState<IOrderResponse[]>(orders);
    const [isDelete, setIsDelete] = useState<{ key: boolean; data: IOrderResponse } | null>(null);


    const navigate = useNavigate();
    const dispatch = useDispatch();

    const getFilteredOrderStatusCards = (statusId: string) => {
        if (!statusId) {
            return lastTwoDaysOrders.today;
        }
        const orderStatusCards = lastTwoDaysOrders.today.filter(item => item.status.id === statusId);
        return orderStatusCards;
    }

    const orderStatusCards = (orderStatuses: IOrderStatusResponse[]) => {
        const statusCountMap: Record<string, { today: number; yesterday: number }> = {};

        // Initialize counts for today and yesterday
        lastTwoDaysOrders.today.forEach((order) => {
            const statusId = order.status.id;
            if (statusCountMap[statusId]) {
                statusCountMap[statusId].today++;
            } else {
                statusCountMap[statusId] = { today: 1, yesterday: 0 };
            }
        });

        lastTwoDaysOrders.yesterday.forEach((order) => {
            const statusId = order.status.id;
            if (statusCountMap[statusId]) {
                statusCountMap[statusId].yesterday++;
            } else {
                statusCountMap[statusId] = { today: 0, yesterday: 1 };
            }
        });

        // Build the tab list based on the computed counts for today and yesterday
        const tabList = orderStatuses.reduce((acc, status) => {
            const statusCounts = statusCountMap[status._id] || { today: 0, yesterday: 0 };
            const totalOrders = statusCounts.today + statusCounts.yesterday;
            if (totalOrders > 0) {
                acc.push({
                    id: status._id,
                    onClick: () => setOrderStatus(status._id),
                    progress: {
                        isUp: statusCounts.today > statusCounts.yesterday,
                        value: statusCounts.yesterday
                    },
                    headerTitle: `${status.displayName} Orders`,
                    contentTitle: statusCounts.today,
                });
            }

            return acc;
        }, [] as IOrderStatusCardForDashboard[]);

        // Add the total tab with counts for both today and yesterday
        const totalTab = {
            id: "",
            onClick: () => setOrderStatus(""),
            progress: {
                isUp: lastTwoDaysOrders.today.length > lastTwoDaysOrders.yesterday.length,
                value: lastTwoDaysOrders.yesterday.length
            },
            headerTitle: "Total Orders",
            contentTitle: lastTwoDaysOrders.today.length
        };

        return [totalTab, ...tabList];
    };


    useEffect(() => {
        const loadOrders = async () => {
            try {
                if (user.userData?._id && orders.length === 0) {
                    orderController.getOrders(user.userData._id).then((response: IApiResponse) => {
                        if (response.success) dispatch(setOrders(response.data));
                    });
                }
                if (user.userData?._id && lastTwoDaysOrders.today.length === 0) {
                    orderController.getOrdersForLastTwoDays(user.userData._id).then((response: IApiResponse) => {
                        if (response.success) dispatch(setOrdersLastTwoDays(response.data));
                    });
                }
                if (user.userData?._id && orderStatuses.length === 0) {
                    orderStatusController.getOrderStatuses().then((response: IApiResponse) => {
                        if (response.success) dispatch(setOrderStatuses(response.data));
                    });
                }
            } catch (error) {
                console.error("Error loading orders", error);
            }
        };
        loadOrders();
    }, []);

    useEffect(() => {
        const orderStatusCards = getFilteredOrderStatusCards(orderStatus);
        setFilteredOrderStatusCards(orderStatusCards);
    }, [orders, orderStatus]);

    const findOrderById = useCallback(
        (id: string) => orders.find((order) => order._id === id),
        [orders]
    );

    const handleEdit = useCallback(
        (id: string) => {
            const order = findOrderById(id);
            if (order) {
                dispatch(updateCurrentOrder(order));
                navigate(`/edit-order/${id}`);
            } else {
                alert("Order not found!");
            }
        },
        [findOrderById, dispatch, navigate]
    );

    const handleDeleteModel = useCallback(
        (id: string) => {
            const order = findOrderById(id);
            if (order) {
                setIsDelete({ key: true, data: order });
            } else {
                alert("Order not found!");
            }
        },
        [findOrderById]
    );

    const handleDelete = useCallback(async () => {
        if (isDelete) {
            try {
                const response: IApiResponse = await orderController.deleteOrder(isDelete.data._id);
                if (response.success) {
                    dispatch(deleteOrder(isDelete.data._id));
                    setIsDelete(null);
                } else {
                    console.error("Failed to delete the order");
                }
            } catch (error) {
                console.error("Error deleting order", error);
            }
        }
    }, [isDelete, dispatch]);

    return (
        <>
            <div
                className="flex gap-3"
            >
                {orderStatusCards(orderStatuses)
                    .map((item, index) => (
                        <OverviewCard
                            key={index}
                            isActive={item.id === orderStatus}
                            item={item}
                        />
                    ))}
            </div>
            <Flex className="!justify-end py-2">
                <Button
                    children="Add Order"
                    onClick={() => navigate(`/new-order`)}
                    shape="rounded"
                    size="medium"
                    color="#ffc107"
                    appearance="primary"
                />
            </Flex>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-4 gap-1 md:gap-2 lg:gap-3 xl:gap-4 w-full">
                {filteredOrderStatusCards.map((order: IOrderResponse) => (
                    <OrderCard
                        order={order}
                        onEdit={() => handleEdit(order._id)}
                        onDelete={() => handleDeleteModel(order._id)}
                    />
                ))}
            </div>
            {isDelete && (
                <ConfirmDialog
                    isOpen={isDelete.key}
                    content={deleteOrderContent}
                    handleModelClose={() => setIsDelete(null)}
                    handleConfirm={handleDelete}
                />
            )}
        </>
    )
}

export default OrdersStatus;
