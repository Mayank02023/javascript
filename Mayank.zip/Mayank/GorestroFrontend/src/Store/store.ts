import { configureStore } from "@reduxjs/toolkit";
import authSlice from "./Slices/authSlice";
import workerSlice from "./Slices/workerSlice";
import systemSlice from "./Slices/systemSlice";
import workerRoleSlice from "./Slices/workerRoleSlice";
import workerShiftSlice from "./Slices/workerShiftSlice";
import productSlice from "./Slices/productSlice";
import productCategorySlice from "./Slices/productCategorySlice";
import orderSlice from "./Slices/orderSlice";
import orderStatusSlice from "./Slices/orderStatusSlice";
const store = configureStore({
    reducer: {
        auth: authSlice,
        worker: workerSlice,
        system: systemSlice,
        workerRole: workerRoleSlice,
        workerShift: workerShiftSlice,
        product: productSlice,
        productCategory: productCategorySlice,
        orders: orderSlice,
        orderStatuses: orderStatusSlice,
    },
    devTools: true,
});

export default store;