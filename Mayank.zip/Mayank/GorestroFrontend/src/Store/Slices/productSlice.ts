import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IProductResponse } from "../../Types";

interface IProducts {
    products: IProductResponse[] | [];
    availableProducts: IProductResponse[] | [];
}

const initialState: IProducts = {
    products: [],
    availableProducts: []
};

const productSlice = createSlice({
    name: "product",
    initialState,
    reducers: {
        setProducts: (state, action: PayloadAction<IProductResponse[] | []>) => {
            state.products = action.payload;
        },
        setAvailableProducts: (state, action: PayloadAction<IProductResponse[] | []>) => {
            state.availableProducts = action.payload;
        },
        createProduct: (state, action: PayloadAction<IProductResponse>) => {
            state.products = [...state.products, action.payload];
        },
        updateProduct: (state, action: PayloadAction<IProductResponse>) => {
            const CurrentProduct = action.payload;
            const availableProductIdx = state.availableProducts.findIndex((product: IProductResponse) => product._id === CurrentProduct._id);
            if (availableProductIdx !== -1) {
                if (!CurrentProduct.status) {
                    state.availableProducts.splice(availableProductIdx, 1);
                } else {
                    state.availableProducts[availableProductIdx] = { ...CurrentProduct };
                }
            } else {
                if (!CurrentProduct.status) {
                    const list = [...state.availableProducts, CurrentProduct].sort((a, b) =>
                        a.displayName.localeCompare(b.displayName)
                    );
                    state.availableProducts = list;
                }
            }
            const productIdx = state.products.findIndex((product: IProductResponse) => product._id === CurrentProduct._id);
            if (productIdx !== -1) {
                state.products[productIdx] = { ...CurrentProduct };
            }
        },
        deleteProduct: (state, action: PayloadAction<string>) => {
            const idToDelete = action.payload;
            // Filter out the product with the given ID from both lists
            state.products = state.products.filter((product) => product._id !== idToDelete);
            state.availableProducts = state.availableProducts.filter((product) => product._id !== idToDelete);
        },

    },
});

export const { setProducts, setAvailableProducts, createProduct, updateProduct, deleteProduct } = productSlice.actions;
export default productSlice.reducer;
