import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IOrderStatusResponse } from "../../Types/order";

interface IOrdersStatus {
    orderStatuses: IOrderStatusResponse[]; // Can simplify `orderStatuses` type
    orderStatus: IOrderStatusResponse | null;
}

const initialState: IOrdersStatus = {
    orderStatuses: [],
    orderStatus: null
};

const orderStatusSlice = createSlice({
    name: "orderStatuses",
    initialState: initialState,
    reducers: {
        // Set multiple order statuses
        setOrderStatuses: (state, action: PayloadAction<IOrderStatusResponse[]>) => {
            state.orderStatuses = action.payload;
        },
        // Create a new order status
        createOrderStatus: (state, action: PayloadAction<IOrderStatusResponse>) => {
            state.orderStatuses.push(action.payload); // Push is cleaner here
        },
        // Update an existing order status
        updateOrderStatus: (state, action: PayloadAction<IOrderStatusResponse>) => {
            state.orderStatuses = state.orderStatuses.map((status) =>
                status._id === action.payload._id ? { ...status, ...action.payload } : status
            );
        },
        // Delete an order status by ID
        deleteOrderStatus: (state, action: PayloadAction<string>) => {
            state.orderStatuses = state.orderStatuses.filter(
                (status) => status._id !== action.payload
            );
        },
        // Get a single order status by ID
        getOrderStatus: (state, action: PayloadAction<string>) => {
            state.orderStatus = state.orderStatuses.find((status) => status._id === action.payload) || null;
        }
    }
});

// Exporting all actions
export const {
    setOrderStatuses,
    createOrderStatus,
    updateOrderStatus,
    deleteOrderStatus,
    getOrderStatus
} = orderStatusSlice.actions;

export default orderStatusSlice.reducer;
