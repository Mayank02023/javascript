import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IProductCategoryResponse } from "../../Types";

interface IProductCategories {
    categories: IProductCategoryResponse[] | [];
}

const initialState: IProductCategories = {
    categories: []
};

const productCategorySlice = createSlice({
    name: "productCategory",
    initialState,
    reducers: {
        setProductCategories: (state, action: PayloadAction<IProductCategoryResponse[] | []>) => {
            state.categories = action.payload;
        },
        createProductCategory: (state, action: PayloadAction<IProductCategoryResponse>) => {
            state.categories = [...state.categories, action.payload];
        },
        updateProductCategory: (state, action: PayloadAction<IProductCategoryResponse>) => {
            const categoryIdx = state.categories.findIndex((category: IProductCategoryResponse) => category._id === action.payload._id);
            if (categoryIdx !== -1) {
                state.categories[categoryIdx] = { ...action.payload };
            }
        },
        deleteProductCategory: (state, action: PayloadAction<string>) => {
            const categoryIdx = state.categories.findIndex((category: IProductCategoryResponse) => category._id === action.payload);
            if (categoryIdx !== -1) {
                state.categories.splice(categoryIdx, 1);
            }
        },
    },
});

export const { setProductCategories, createProductCategory, updateProductCategory, deleteProductCategory } = productCategorySlice.actions;
export default productCategorySlice.reducer;
