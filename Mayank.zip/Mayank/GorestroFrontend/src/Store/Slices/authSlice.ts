import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IRestaurantResponse } from "../../Types";
import { IAuthResponse } from "../../Types";

const initialState: IAuthResponse = {
    status: false,
    userData: null,
    accessToken: null,
    refreshToken: null,
};

const authSlice = createSlice({
    name: "auth",
    initialState,
    reducers: {
        login: (state, action: PayloadAction<{ userdata: IRestaurantResponse; accessToken: string; refreshToken: string }>) => {
            state.status = true;
            state.userData = action.payload.userdata;
            state.accessToken = action.payload.accessToken;
            state.refreshToken = action.payload.refreshToken;
        },
        logout: (state) => {
            state.status = false;
            state.userData = null;
            state.accessToken = null;
            state.refreshToken = null;
        },
    },
});

export const { login, logout } = authSlice.actions;
export default authSlice.reducer;
