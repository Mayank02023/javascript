import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IOrderResponse } from "../../Types/order";
import { initialCurrentOrderState } from "../../Utils/Orders";

interface IOrders {
    orders: IOrderResponse[] | [];
    lastTwoDaysOrders: {
        today: IOrderResponse[] | [];
        yesterday: IOrderResponse[] | [];
    };
    currentOrder: IOrderResponse;
}
const initialState: IOrders = {
    orders: [],
    lastTwoDaysOrders: {
        today: [],
        yesterday: [],
    },
    currentOrder: initialCurrentOrderState
}

const orderSlice = createSlice({
    name: "orders",
    initialState: initialState,
    reducers: {
        setOrders: (state, action: PayloadAction<IOrderResponse[] | []>) => {
            state.orders = action.payload;
        },
        setOrdersLastTwoDays: (state, action: PayloadAction<{
            today: IOrderResponse[] | [];
            yesterday: IOrderResponse[] | [];
        }>) => {
            state.lastTwoDaysOrders = action.payload;
        },
        createOrder: (state, action: PayloadAction<IOrderResponse>) => {
            state.orders = [...state.orders, action.payload];
            state.lastTwoDaysOrders.today = [...state.lastTwoDaysOrders.today, action.payload];
        },
        updateOrder: (state, action: PayloadAction<IOrderResponse>) => {
            const orderIdx = state.orders.findIndex((order) => order._id === action.payload._id);
            const todayOrderIdx = state.lastTwoDaysOrders.today.findIndex((order) => order._id === action.payload._id);
            if (orderIdx >= 0) {
                state.orders[orderIdx] = { ...action.payload };
            }
            if (todayOrderIdx >= 0) {
                state.lastTwoDaysOrders.today[todayOrderIdx] = { ...action.payload };
            }
        },
        deleteOrder: (state, action: PayloadAction<string>) => {
            const orderIdx = state.orders.findIndex((order) => order._id === action.payload);
            const todayOrderIdx = state.lastTwoDaysOrders.today.findIndex((order) => order._id === action.payload);
            if (orderIdx >= 0) {
                state.orders.splice(orderIdx, 1);
            }
            if (todayOrderIdx >= 0) {
                state.lastTwoDaysOrders.today.splice(todayOrderIdx, 1);
            }
        },
        updateCurrentOrder: (state, action: PayloadAction<IOrderResponse>) => {
            state.currentOrder = action.payload;
        },
        resetCurrentOrder: (state) => {
            state.currentOrder = initialCurrentOrderState; // Reset to null or initialOrderState based on preference
        }
    }
});

export const { setOrders, setOrdersLastTwoDays, createOrder, updateOrder, deleteOrder, updateCurrentOrder, resetCurrentOrder } = orderSlice.actions;
export default orderSlice.reducer;