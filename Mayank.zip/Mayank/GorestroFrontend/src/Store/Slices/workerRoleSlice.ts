import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IWorkerRoleResponse } from "../../Types";

interface Iworkers {
    workerRoles: IWorkerRoleResponse[] | [];
};
const initialState: Iworkers = {
    workerRoles: []
};
const workerRoleSlice = createSlice({
    name: "workerRole",
    initialState,
    reducers: {
        setWorkerRole: (state, action: PayloadAction<IWorkerRoleResponse[] | []>) => {
            state.workerRoles = action.payload;
        },
        createWorkerRole: (state, action: PayloadAction<IWorkerRoleResponse>) => {
            state.workerRoles = [...state.workerRoles, action.payload];
        },
        updateWorkerRole: (state, action: PayloadAction<IWorkerRoleResponse>) => {
            const workerIdx = state.workerRoles.findIndex((workerRole: IWorkerRoleResponse) => workerRole._id === action.payload._id);
            if (workerIdx !== -1) {
                state.workerRoles[workerIdx] = { ...action.payload };
            }
        },
        deleteWorkerRole: (state, action: PayloadAction<string>) => {
            const workerIdx = state.workerRoles.findIndex((workerRole: IWorkerRoleResponse) => workerRole._id === action.payload);
            if (workerIdx !== -1) {
                state.workerRoles.splice(workerIdx, 1);
            }
        },
    },
});

export const { setWorkerRole, createWorkerRole, updateWorkerRole, deleteWorkerRole } = workerRoleSlice.actions;
export default workerRoleSlice.reducer;
