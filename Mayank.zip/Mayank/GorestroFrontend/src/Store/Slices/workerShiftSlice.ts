import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IWorkerRoleResponse } from "../../Types"; // Update import to shift response type

interface IWorkers {
    workerShifts: IWorkerRoleResponse[] | [];
}

const initialState: IWorkers = {
    workerShifts: []
};

const workerShiftSlice = createSlice({
    name: "workerShift",
    initialState,
    reducers: {
        setWorkerShift: (state, action: PayloadAction<IWorkerRoleResponse[] | []>) => {
            state.workerShifts = action.payload;
        },
        createWorkerShift: (state, action: PayloadAction<IWorkerRoleResponse>) => {
            state.workerShifts = [...state.workerShifts, action.payload];
        },
        updateWorkerShift: (state, action: PayloadAction<IWorkerRoleResponse>) => {
            const shiftIdx = state.workerShifts.findIndex((workerShift: IWorkerRoleResponse) => workerShift._id === action.payload._id);
            if (shiftIdx !== -1) {
                state.workerShifts[shiftIdx] = { ...action.payload };
            }
        },
        deleteWorkerShift: (state, action: PayloadAction<string>) => {
            const shiftIdx = state.workerShifts.findIndex((workerShift: IWorkerRoleResponse) => workerShift._id === action.payload);
            if (shiftIdx !== -1) {
                state.workerShifts.splice(shiftIdx, 1);
            }
        },
    },
});

export const { setWorkerShift, createWorkerShift, updateWorkerShift, deleteWorkerShift } = workerShiftSlice.actions;
export default workerShiftSlice.reducer;
