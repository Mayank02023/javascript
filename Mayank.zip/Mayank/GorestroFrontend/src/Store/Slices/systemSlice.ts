import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { ISystem, Theme } from "../../Types";


interface SystemState {
    system: ISystem;
}

const initialState: SystemState = {
    system: {
        id: null,
        name: null,
        theme: Theme.Light,
        lang: "en",
        location: null,
        timeZone: null
    }
};

const systemSlice = createSlice({
    name: "system",
    initialState,
    reducers: {
        setSystem: (state, action: PayloadAction<ISystem>) => {
            state.system = action.payload;
        },

    },
});

export const { setSystem } = systemSlice.actions;
export default systemSlice.reducer;
