export interface IUser {
  name: string;
  avatar?: string;
  username: string;
  email?: string;
  role: "owner" | "manager" | "staff";
  isLoggedIn?: boolean;
  status: "active" | "inactive";
}