import { Types } from "mongoose";
import { ApiError, ApiResponse } from "../Utils"; // Adjust the path to your ApiError utility
import { IUser } from "../Interfaces/User.interface";
import userRepository from "../Repositories/User.Repository";

const generateAccessAndRefereshToken = async (userId: string) => {
    const user = await userRepository.findById(userId);
    if (!user) {
        throw new ApiError(400, "User does not exist!");
    }

    const accessToken = user.generateAccessToken();
    const refreshToken = user.generateRefreshToken();

    const userResponse = await userRepository.updateRefreshToken(userId, refreshToken);

    return { userResponse, accessToken, refreshToken };
};


const userService = {
    createUser: async (userData: IUser) => {
        const user = await userRepository.create(userData);
        return user;
    },
    loginUser: async (username: string, password: string) => {
        try {
            
        } catch (error) {
            
        }
        if (!username || !password) {
            throw ApiError.badRequest("Username and password are required");
        }

        const user = await userRepository.findByUsername(username);
        if (!user?._id) {
            throw ApiError.badRequest("User does not exist!");
        }

        const isPasswordValid = await user.isPasswordCorrect(password);
        if (!isPasswordValid) {
            throw ApiError.forbidden("Invalid credentials");
        }

        const userId: string = user._id?.toString() ?? "";
        const { userResponse, accessToken, refreshToken } = await generateAccessAndRefereshToken(userId);
        return ApiResponse.success(
            {
                user: userResponse,
                accessToken,
                refreshToken
            },
            "User logged in successfully",
            200
        );
    },
    logoutUser: async (userId: string): Promise<{ success: boolean; message: string }> => {
        const user = await userRepository.updateRefreshToken(userId);

        if (!user) {
            throw ApiError.badRequest("User does not exist!");
        }
        return ApiResponse.success(
            { success: true },
            "Login successful"
        );
    }
};

export default userService;
