import movieRepository from '../Repositories/Movie.Repository';
import { IMovie, IMovieFilter } from '../Interfaces/Movie.interface';

class MovieService {
    async createMovie(data: IMovie): Promise<IMovie> {
        return await movieRepository.create(data);
    }

    async getMovies(): Promise<IMovie[]> {
        return await movieRepository.getAll();
    }

    async getMoviesByPage(
        page: number = 1,
        search: string = "",
        filter?: IMovieFilter): Promise<IMovie[]> {
        return await movieRepository.getMoviesByPage(
            page,
            search,
            filter
        );
    }

    async getMovieById(id: string): Promise<IMovie | null> {
        return await movieRepository.getById(id);
    }

    async updateMovie(id: string, data: Partial<IMovie>): Promise<IMovie | null> {
        return await movieRepository.update(id, data);
    }

    async deleteMovie(id: string): Promise<IMovie | null> {
        return await movieRepository.delete(id);
    }
}

const movieService = new MovieService();
export default movieService;
