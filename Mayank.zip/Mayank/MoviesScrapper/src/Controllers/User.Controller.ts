import { Request, Response } from 'express';
import useService from '../Services/User.service';
import { ApiError, asyncHandler } from "../Utils";
import { ApiResponse } from '../utils/apiResponse';
import { options } from "../constants";
import { AuthRequest } from '../types/AuthResquest';
import { data } from 'cheerio/dist/commonjs/api/attributes';
const userController = {
    loginUser: asyncHandler(async (req: Request, res: Response) => {
        try {
            const { username, password } = req.body;

            const { data, message, statusCode } = await useService.loginUser(username, password);
          
            return res
                .status(statusCode || 200)
                .cookie("accessToken", data.accessToken, options)
                .cookie("refreshToken", data.refreshToken, options)
                .json(ApiResponse.success(data, message, statusCode || 200));
        } catch (error: any) {
            return res.status(error.statusCode || 500).json(ApiResponse.error(
                error.message || "An error occurred during login",
                error.statusCode || 500,
                null
            ));
        }
    }),
    logoutUser: asyncHandler(async (req: AuthRequest, res: Response) => {
        try {
            const userId = req?.user?._id; // Assuming `userId` is available in `req.user` from middleware

            if (!userId) {
                throw ApiError.badRequest("User ID is required for logout.");
            }

            // Call the service function
            const result = await useService.logoutUser(userId);

            // Send the response based on the service result
            if (result.success) {
                res.status(200).json(result);
            } else {
                res.status(400).json(result);
            }
        } catch (error: any) {
            // Handle unexpected errors
            console.error("Error in logoutController:", error);

            // Send a generic error response
            res.status(500).json({
                success: false,
                message: "Internal server error during logout.",
            });

        }

    })
};
export default userController;
