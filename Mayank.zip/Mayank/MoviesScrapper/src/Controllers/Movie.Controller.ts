import { Request, Response } from 'express';
import movieService from '../Services/Movie.Service';
import { IMovieFilter } from '../Interfaces/Movie.interface';

class MovieController {
    async createMovie(req: Request, res: Response): Promise<void> {
        try {
            const movie = await movieService.createMovie(req.body);
            res.status(201).json(movie);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    async getMovies(req: Request, res: Response): Promise<void> {
        try {
            const movies = await movieService.getMovies();
            res.status(200).json(movies);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    async getMoviesByPage(req: Request, res: Response): Promise<void> {
        try {
            const page = parseInt(req.params.page);
            const search = req.body.search as string;
            const filter = req.body.filter as IMovieFilter | undefined;
            const movies = await movieService.getMoviesByPage(page || 1, search || "", filter || {});
            res.status(200).json(movies);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    async getMovieById(req: Request, res: Response): Promise<void> {
        try {
            const movie = await movieService.getMovieById(req.params.id);
            res.status(200).json(movie);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    async updateMovie(req: Request, res: Response): Promise<void> {
        try {
            const movie = await movieService.updateMovie(req.params.id, req.body);
            res.status(200).json(movie);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    async deleteMovie(req: Request, res: Response): Promise<void> {
        try {
            const movie = await movieService.deleteMovie(req.params.id);
            res.status(200).json(movie);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }
}

const movieController = new MovieController();
export default movieController;
