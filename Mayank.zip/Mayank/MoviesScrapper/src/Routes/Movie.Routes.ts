import { Router } from 'express';
import movieController from '../Controllers/Movie.Controller';
import VerifyJWT from '../Middlewares/Auth.Middleware';

const router = Router();

router.post('/', VerifyJWT(), movieController.createMovie);
router.get('/:page?', VerifyJWT(), movieController.getMoviesByPage);
router.get('/:id', movieController.getMovieById);
router.put('/:id', VerifyJWT(), movieController.updateMovie);
router.delete('/:id', VerifyJWT(), movieController.deleteMovie);

export default router;
