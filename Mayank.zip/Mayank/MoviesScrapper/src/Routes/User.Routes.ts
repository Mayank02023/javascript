import { Router } from 'express';
import userController from '../Controllers/User.Controller';

const router = Router();

router.post('/login', userController.loginUser);

export default router;
