export interface IDownloadServer {
    name: string;
    url: string;
}

export interface IDownloadLinkAndServer {
    url: string;
    servers: IDownloadServer[];
}

export interface IQualitySizeDownloadLink {
    resolution: string | null;
    fileSize: string | null;
    downloadDetails: IDownloadLinkAndServer[];
}

export interface IMovie {
    title: string;
    thumbnail: string;
    streamingUrl: string;
    screenshots: string[];
    downloadOptions?: IQualitySizeDownloadLink[];
    genre: string;
    director: string;
    writer: string;
    cast: string[];
    synopsis: string;
    releaseDate: string;
    imdbRating: string;
    countries: string;
    languages: string;
}
