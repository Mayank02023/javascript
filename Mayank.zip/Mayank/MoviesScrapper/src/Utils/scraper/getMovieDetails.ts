import * as cheerio from 'cheerio';
import getHTMLContent from './getHTMLContent';
import { IDownloadLinkAndServer, IQualitySizeDownloadLink } from '../../types/Scrapper';
import getLinks from './getDownloadLinks';
interface Movie {
    title: string;
    imdbRating: string | undefined;
    genre: string;
    releaseDate: string;
    director: string;
    writer: string;
    cast: string[];
    synopsis: string;
    countries: string;
    languages: string;
    screenshots: string[];
    downloadOptions: IQualitySizeDownloadLink[];
}

/**
 * Extracts the text content from a specific element.
 * @param $ - The Cheerio instance.
 * @param selector - The selector to find the element.
 * @returns Extracted text or undefined.
 */
const extractText = ($: cheerio.CheerioAPI, selector: string): string | undefined => {
    return $(selector).text().trim() || undefined;
};

/**
 * Extracts the list of cast names.
 * @param $ - The Cheerio instance.
 * @param selector - The selector to find the cast elements.
 * @returns List of cast members' names.
 */
const extractList = ($: cheerio.CheerioAPI, selector: string): string[] => {
    return $(selector).map((_, el) => $(el).text().trim()).get();
};
const extractSize = (input: string): string | null => {
    const match = input.match(/\[(.*?)\]/); // Match content within square brackets
    return match ? match[1] : null; // Return the matched content inside the brackets
};

const extractResolution = (input: string): string | null => {
    // Find the position of the last opening bracket
    const lastOpenBracketIndex = input.lastIndexOf('[');

    // If no bracket is found, return null
    if (lastOpenBracketIndex === -1) {
        return null;
    }

    // Extract the string before the bracket
    const beforeBracket = input.slice(0, lastOpenBracketIndex).trim();

    // Use a regular expression to extract the resolution pattern
    const match = beforeBracket.match(/\b(\d{3,4}p)\b/);

    // Return the resolution if found, otherwise null
    return match ? match[1] : null;
};


/**
 * Extracts download links from the page.
 * @param $ - The Cheerio instance.
 * @returns List of download links.
 */
const extractDownloadLinks = async ($: cheerio.CheerioAPI): Promise<IQualitySizeDownloadLink[]> => {
    const downloadLinks: IQualitySizeDownloadLink[] = [];
    const contentBox = $('.entry-content.simple-grid-clearfix');
    const elements = contentBox.find('[style="text-align: center;"]');

    let currentResolution: string | null = null;
    let currentFileSize: string | null = null;

    for (const element of elements) {
        const tagName = $(element).prop('tagName')?.toLowerCase();

        if (tagName === 'h4') {
            const heading = $(element).text().trim();
            currentResolution = extractResolution(heading);
            currentFileSize = extractSize(heading);
        } else if (tagName === 'p') {
            const links: IDownloadLinkAndServer[] = [];

            $(element).find('a').each((_, link) => {
                const href = $(link).attr('href');
                if (href && href.includes('dflinks')) {
                    links.push({ url: href, servers: [] }); // Placeholder for servers
                }
            });

            if (currentResolution && !downloadLinks.some(dl => dl.resolution === currentResolution)) {
                const resolvedServers = await Promise.all(
                    links.map(async (link) => {
                        const servers = await getLinks(link.url);
                        return { url: link.url, servers };
                    })
                );

                downloadLinks.push({
                    resolution: currentResolution,
                    fileSize: currentFileSize,
                    downloadDetails: resolvedServers,
                });
            }
        }
    }

    return downloadLinks;
};

/**
 * Scrapes movie data from the given link.
 * @param link - The URL of the movie page to scrape.
 * @returns {Promise<Movie | null>} - Returns movie data or null in case of an error.
 */
const scrapeMovieData = async (link: string): Promise<Movie | null> => {
    try {
        const $ = await getHTMLContent(link);
        const content = $('.entry-content.simple-grid-clearfix');
        if (!content.length) {
            throw new Error('Content not found on page');
        }
        const imdbRating = content.find('b:contains("IMDB Rating")').parent().text().match(/IMDB Rating:(\d+(\.\d+)?)/)?.[1];
        const genre = content.find('strong:contains("Genre:")').parent().text().match(/Genre:\s*([\w\s,]+)/)?.[1]?.trim().split('\n')[0];
        const releaseDate = content.find('strong:contains("Released Date:")').parent().text().match(/Released Date:\s*([\d\w\s]+)/)?.[1]?.trim().split('\n')[0];

        const title = extractText($, '#movie_title a') || 'Untitled';
        const director = extractText($, 'span:contains("Director:") a') || '';
        const writer = extractText($, 'span:contains("Writer:") a') || '';
        const cast = extractList($, 'span:contains("Stars:") a').filter((_, i, arr) => i !== 0 && i !== arr.length - 1);
        const synopsis = $('#summary').text().replace('Summary: ', '').trim();
        const countries = extractText($, 'span:contains("Countries:")')?.replace('Countries:', '').trim() || '';
        const languages = extractText($, 'span:contains("Languages:")')?.replace('Languages:', '').trim() || '';

        const screenshots: string[] = [];
        const imgContent = content.find('img.aligncenter[decoding="async"]');
        imgContent.each((index, element) => {
            if (index === 0 || index === imgContent.length - 1) return;
            const imageUrl = $(element).attr('data-src');
            if (imageUrl && !imageUrl.startsWith('data:image/')) {
                screenshots.push(imageUrl);
            }
        });

        const downloadOptions = await extractDownloadLinks($);
        return {
            title,
            imdbRating,
            genre: genre || '',
            releaseDate: releaseDate || '',
            director,
            writer,
            cast,
            synopsis,
            countries,
            languages,
            screenshots,
            downloadOptions,
        };
    } catch (error: any) {
        console.error(`Error scraping movie data from link (${link}):`, error.message);
        return null;
    }
};

export default scrapeMovieData;
