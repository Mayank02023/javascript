import { IMovie } from '../../types/Scrapper';
import scrapeMovieData from './getMovieDetails';
import getHTMLContent from './getHTMLContent';

/**
 * Scrapes movies from a website and returns an array of movie objects with details.
 * @param url - The URL of the website to scrape movies from.
 * @returns {Promise<IMovie[]>} - Returns an array of movie objects.
 */
const getMovies = async (url: string): Promise<any[]> => {
    try {
        const $ = await getHTMLContent(url); // Fetch HTML content from the URL
        const movieContainers = $('.simple-grid-grid-post'); // Select all the movie containers

        const moviePromises = movieContainers.map(async (_, element) => {
            const linkElement = $(element).find('a.simple-grid-grid-post-thumbnail-link');
            const imgElement = $(element).find('img.simple-grid-grid-post-thumbnail-img');
            const image = imgElement.attr('data-src') || imgElement.attr('src') || 'not available';
            const link = linkElement.attr('href');

            if (!link) return null;

            try {
                const movieData = await scrapeMovieData(link); // Scrape movie details
                if (movieData) {
                    return {
                        ...movieData,
                        imdbRating: movieData.imdbRating || 'not available',
                        streamingUrl: link,
                        thumbnail: image,
                        screenshots: movieData.screenshots || [],
                    };
                }
            } catch (err: any) {
                console.error(`Error scraping movie data: ${err.message}`);
            }
            return null; // Return null for skipped movies
        }).get();

        const movies = (await Promise.all(moviePromises)).filter((movie): movie is any => movie !== null);
        return movies;
    } catch (error: any) {
        console.error("Error scraping movies:", error.message);
        return [];
    }
};

export default getMovies;
