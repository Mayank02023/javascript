import axios from 'axios';
import * as cheerio from 'cheerio';

/**
 * Fetches the raw HTML content from a specified URL.
 *
 * @param url - The URL of the webpage to fetch HTML from.
 * @returns A promise that resolves to the HTML content of the page as a string.
 */
async function getHTMLContent(url: string): Promise<cheerio.CheerioAPI> {
    try {
        const { data } = await axios.get<any>(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            },
        });
        const htmlContent = cheerio.load(data);
        return htmlContent; // Return the raw HTML content
    } catch (error) {
        console.error('Error fetching HTML content:', (error as Error).message);
        throw error;
    }
}

export default getHTMLContent;