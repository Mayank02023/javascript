import getHTMLContent from './getHTMLContent';
import { IDownloadServer } from '../../types/Scrapper';

/**
 * Scrapes text and links from a specified div with a given class name.
 *
 * @param {string} url - The URL of the page to scrape.
 * @param {string} divClassName - The class name of the div to target.
 * @returns {Promise<IDownloadServer[]>} - A promise that resolves to an array of objects containing text and links.
 */
async function getLinks(url: string,): Promise<IDownloadServer[]> {
    const divClassName = 'timed-content-client_show_0_5';
    try {
        // Fetch the page content
        const $ = await getHTMLContent(url);

        // Select the specified div
        const contentDiv = $(`.${divClassName}`);

        // Extract links and text
        const DownloadServerAndLinks: IDownloadServer[] = [];
        contentDiv.find('a').each((_, element) => {
            const name = $(element).text().trim();
            const url = $(element).attr('href') || ''; // Default to an empty string if link is undefined
            DownloadServerAndLinks.push({ name, url });
        });

        return DownloadServerAndLinks;
    } catch (error: any) {
        console.error('Error scraping the page:', error.message);
        throw error;
    }
}

export default getLinks;
