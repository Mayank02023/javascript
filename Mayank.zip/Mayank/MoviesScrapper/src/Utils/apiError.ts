class ApiError extends Error {
    statusCode: number;
    data: any | null;
    success: boolean;
    errors: any[];

    constructor(
        statusCode: number,
        message: string = "Something went wrong",
        errors: any[] = [],
        data: any = null
    ) {
        super(message);
        this.statusCode = statusCode;
        this.data = data;
        this.success = false;
        this.errors = errors;

        Error.captureStackTrace(this, this.constructor);
    }

    static badRequest(message: string, errors: any[] = []): ApiError {
        return new ApiError(400, message, errors);
    }

    static unauthorized(message: string): ApiError {
        return new ApiError(401, message);
    }

    static forbidden(message: string): ApiError {
        return new ApiError(403, message);
    }

    static notFound(message: string): ApiError {
        return new ApiError(404, message);
    }

    static internal(message: string): ApiError {
        return new ApiError(500, message);
    }
}

export default ApiError;
