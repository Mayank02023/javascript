import mongoose from "mongoose";
import envConfig from "./envConfig";
import { DB_NAME } from "../constants";

const connectDB = async () => {
    try {
        const baseUri = envConfig.LOCAL_MONGODB_URI || "mongodb://localhost:27017";
        const connectionString = `${baseUri.replace(/\/$/, '')}/${DB_NAME}`;

        // const connectionString = `${envConfig.MONGODB_CONECTION_STRING}`;

        const connectionInstance = await mongoose.connect(connectionString);
        console.log(`\n MONGODB connection !! DB HOST: ${connectionInstance.connection.host}:${connectionInstance.connection.port}`);
    } catch (error: any) {
        console.error("MONGODB connection error ", error);
        process.exit(1);
    }
};

export default connectDB;
