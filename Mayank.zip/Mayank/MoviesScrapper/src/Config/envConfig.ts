import dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

const envConfig = {
    NODE_ENV: process.env.NODE_ENV || 'development',
    PORT: process.env.PORT || 8080,
    LOCAL_CORS_ORIGIN: process.env.LOCAL_CORS_ORIGIN || 'http://localhost:5173',
    MONGODB_CONECTION_STRING: process.env.MONGODB_DB_NAME,
    LOCAL_MONGODB_URI: process.env.LOCAL_MONGODB_URI || 'mongodb://localhost:27017/',

    // Auth secrets and expiries
    ACCESS_TOKEN_SECRET: process.env.ACCESS_TOKEN_SECRET || 'D2DCDC74FD7D3F6FD138F36EDCF18',
    ACCESS_TOKEN_EXPIRY: process.env.ACCESS_TOKEN_EXPIRY || '1d',
    REFRESH_TOKEN_SECRET: process.env.REFRESH_TOKEN_SECRET || '95958DF847436FBCAFA92FA1EF1DD',
    REFRESH_TOKEN_EXPIRY: process.env.REFRESH_TOKEN_EXPIRY || '2d',
};

export default envConfig;
