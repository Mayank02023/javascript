export const DB_NAME = "moviesDB";

export const options = {
    httpOnly: true,
    secure: true
}