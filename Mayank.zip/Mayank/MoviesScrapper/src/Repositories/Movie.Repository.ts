import MovieModel from '../Models/Movies/Movies.model';
import { IMovie, IMovieFilter } from '../Interfaces/Movie.interface';

class MovieRepository {
    async create(movieData: IMovie): Promise<IMovie> {
        const movie = new MovieModel(movieData);
        return await movie.save();
    }

    async getAll(): Promise<IMovie[]> {
        return await MovieModel.find().exec();
    }

    async getMoviesByPage(
        page: number = 1,
        search: string = "",
        filter?: IMovieFilter
    ): Promise<IMovie[]> {
        const limit = 20;
    
        // Build the query object
        let query: any = {};
    
        if (search) {
            query.title = { $regex: search, $options: "i" };  // Case-insensitive search
        }
    
        if (filter?.genre) {
            query.genre = filter?.genre;
        }
    
        if (filter?.year) {
            query.releaseDate = { $gte: new Date(`${filter?.year}-01-01`), $lt: new Date(`${filter?.year + 1}-01-01`) };
        }
    
        if (filter?.rating) {
            query.imdbRating = { $gte: filter?.rating };
        }
    
        if (filter?.language) {
            // Split the language string into an array
            query.languages = { $in: filter?.language.split(', ') };
        }
    
        if (filter?.country) {
            // Split the country string into an array
            query.countries = { $in: filter?.country.split(', ') };
        }
    
        // Fetch movies with the query and apply pagination
        const movies = await MovieModel.find(query)
            .skip((page - 1) * limit)
            .limit(limit)
            .exec();
        return movies;
    }
    

    async getById(id: string): Promise<IMovie | null> {
        return await MovieModel.findById(id).exec();
    }

    async update(id: string, data: Partial<IMovie>): Promise<IMovie | null> {
        return await MovieModel.findByIdAndUpdate(id, data, { new: true }).exec();
    }

    async delete(id: string): Promise<IMovie | null> {
        return await MovieModel.findByIdAndDelete(id).exec();
    }
}

const movieRepository = new MovieRepository();
export default movieRepository;
