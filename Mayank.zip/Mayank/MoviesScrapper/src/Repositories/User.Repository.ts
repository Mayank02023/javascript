import UserModel from "../Models/User/User.model";
import { IUser } from "../Interfaces/User.interface";

const userRepository = {
    create: async (userData: IUser) => {
        return await UserModel.create(userData);
    },
    findById: async (userId: string) => {
        return UserModel.findById(userId).select("-password -refreshToken");
    },
    findByUsername: async (username: string) => {
        return UserModel.findOne({ username }).select("-password -refreshToken").exec();
    },
    updateRefreshToken: async (userId: string, refreshToken: string | undefined = undefined) => {
        return UserModel.findByIdAndUpdate(
            userId,
            { refreshToken },
            { new: true, validateBeforeSave: false }
        ).select("-password -refreshToken");
    },
    getUserWithoutSensitiveFields: async (userId: string) => {
        return UserModel.findById(userId).select("-password -refreshToken");
    }
};



export default userRepository;