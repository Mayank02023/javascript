import { Request, Response, NextFunction } from 'express';
import jwt, { JwtPayload } from 'jsonwebtoken';
import { ApiError } from "../Utils";
import { AuthRequest } from '../types/AuthResquest';
import UserModel, { IUserSchema } from '../Models/User/User.model';


// Function to decode JWT and return the payload
const decodedJWT = async (accessToken: string, accessTokenSecret: string): Promise<JwtPayload | null> => {
    if (!accessToken) throw new ApiError(401, "Unauthorized request");
    try {
        const decodedToken = jwt.verify(accessToken, accessTokenSecret) as JwtPayload;
        return decodedToken;
    } catch (error) {
        console.error("Error decoding JWT:", error);
        return null;
    }
};
// This middleware will check if the logged-in user has the required role
const VerifyJWT = () => {
    return async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
        try {
            // Get the token from the authorization header
            const accessToken = req.cookies?.accessToken || req.header("Authorization")?.replace("Bearer ", "");

            // Verify the token and decode the user info
            const decoded = await decodedJWT(accessToken, String(process.env.ACCESS_TOKEN_SECRET));

            if (!decoded) {
                throw new ApiError(401, "Invalid access token");
            }
            // Check the role in the user's model
            let user: IUserSchema | null = null;

            // Check for User
            user = await UserModel.findById(decoded._id);

            // If user does not exist or is inactive, deny access
            if (!user || user.status === 'inactive') {
                throw new ApiError(403, "Access denied");
            }

            // If everything is okay, attach the user info to the request object and proceed
            req.user = user;
            next();
        } catch (error: any) {
            console.error("Error verifying JWT:", error.message);
            return next(error);
        }
    };
};

export default VerifyJWT;