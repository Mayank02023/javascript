import mongoose, { Document, Model, Schema } from 'mongoose';
import { IMovie, IQualitySizeDownloadLink, IDownloadLinkAndServer } from '../../types/Scrapper';


// Renamed interface to PascalCase
interface IMovieSchema extends IMovie, Document { }; // Added this line
interface IQualitySizeDownloadLinkSchema extends IQualitySizeDownloadLink, Document { }; // Added this line
interface IDownloadLinkAndServerSchema extends IDownloadLinkAndServer, Document { }; // Added this line

const downloadLinkAndServerSchema: Schema<IDownloadLinkAndServerSchema> = new mongoose.Schema<IDownloadLinkAndServerSchema>(
    {
        url: { type: String, default: null },
        servers: [{
            name: { type: String, default: null },
            url: { type: String, default: null }
        }]
    },
    { _id: false }
);

const qualitySizeDownloadLinkSchema: Schema<IQualitySizeDownloadLinkSchema> = new mongoose.Schema<IQualitySizeDownloadLinkSchema>(
    {
        resolution: { type: String, default: null },
        fileSize: { type: String, default: null },
        downloadDetails: { type: [downloadLinkAndServerSchema], default: [] }
    }, { _id: false }
);

const movieSchema: Schema<IMovieSchema> = new mongoose.Schema<IMovieSchema>(
    {
        title: { type: String, default: null },
        thumbnail: { type: String, default: null },
        streamingUrl: { type: String, default: null },
        screenshots: { type: [String], default: [] },
        downloadOptions: { type: [qualitySizeDownloadLinkSchema], default: [] },
        genre: { type: String, default: null },
        director: { type: String, default: null },
        writer: { type: String, default: null },
        cast: { type: [String], default: [] },
        synopsis: { type: String, default: null },
        releaseDate: { type: String, default: null },
        imdbRating: { type: String, default: null },
        countries: { type: String, default: null },
        languages: { type: String, default: null }
    },
    {
        timestamps: true // Automatically manage createdAt and updatedAt fields
    }
);

// Create the model based on the schema
const Movie: Model<IMovieSchema> = mongoose.model<IMovieSchema>("Movie", movieSchema, "movies");


// Export the MenuItem model for use in other files
export default Movie;