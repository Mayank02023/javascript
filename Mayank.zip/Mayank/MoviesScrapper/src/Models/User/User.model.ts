import mongoose, { Document, Model, Schema, Types } from "mongoose";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { ApiError } from "../../Utils"; // Adjust the path as per your project structure
import envConfig from "../../Config/envConfig";
import { IUser } from "../../Interfaces/User.interface";
export interface IUserSchema extends IUser, Document {
  password: string;
  refreshToken?: string;
  createdAt?: Date;
  updatedAt?: Date;
  isPasswordCorrect(password: string): Promise<boolean>;
  generateAccessToken(): string;
  generateRefreshToken(): string;
}

const userSchema: Schema<IUserSchema> = new mongoose.Schema<IUserSchema>(
  {
    name: { type: String, required: true },
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    email: { type: String, required: false, unique: true },
    role: {
      type: String,
      enum: ["owner", "manager", "staff"],
      required: true,
      default: "owner",
    },
    avatar: { type: String, default: null },
    refreshToken: { type: String, required: false },
    isLoggedIn: { type: Boolean, default: false },
    status: {
      type: String,
      enum: ["active", "inactive"],
      default: "active",
    },
  },
  {
    timestamps: true,
  }
);

// Pre-save hook to hash the password
userSchema.pre<IUserSchema>("save", async function (next) {
  if (!this.isModified("password")) return next();

  try {
    const hashedPassword = await bcrypt.hash(this.password, 10);
    this.password = hashedPassword;
    next();
  } catch (err: any) {
    next(err);
  }
});

// Method to compare passwords
userSchema.methods.isPasswordCorrect = async function (password: string) {
  return await bcrypt.compare(password, this.password);
};

// Method to generate an access token
userSchema.methods.generateAccessToken = function () {
  try {
    const token = jwt.sign(
      {
        id: this._id,
        name: this.name,
        username: this.username,
        role: this.role,
      },
      envConfig.ACCESS_TOKEN_SECRET,
      {
        expiresIn: envConfig.ACCESS_TOKEN_EXPIRY,
      }
    );
    console.log("Access Token generated successfully:", token);
    return token;
  } catch (err) {
    console.error("Error generating access token:", err);
    throw new ApiError(500, "Failed to generate access token.");
  }
};

// Method to generate a refresh token
userSchema.methods.generateRefreshToken = function () {
  try {
    const token = jwt.sign(
      {
        id: this._id,
      },
      envConfig.REFRESH_TOKEN_SECRET,
      {
        expiresIn: envConfig.REFRESH_TOKEN_EXPIRY,
      }
    );
    console.log("Refresh Token generated successfully:", token);
    return token;
  } catch (err) {
    console.error("Error generating refresh token:", err);
    throw new ApiError(500, "Failed to generate refresh token.");
  }
};

// Create and export the model
const User: Model<IUserSchema> = mongoose.model<IUserSchema>("User", userSchema);

export default User;
