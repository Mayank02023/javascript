import dotenv from "dotenv";
import connectDB from './Config/connectDB';
import envConfig from './Config/envConfig';
import app from "./app";

dotenv.config({
    path: './.env'
})

connectDB()
    .then(() => {
        const port = envConfig.PORT || 8000;

        app.on("error", (err) => {
            console.log("Error", err);
            throw err;
        });

        app.listen(port, () => {
            console.log(`Server running at http://localhost:${port}`);
        });
    })
    .catch((err) => {
        console.log("MONGODB connection failed !! ", err);
    });

// const fetchAndSaveMovies = async () => {
//     for (let i = 1; i < 207; i++) {
//         let url = `https://dudefilms.im/page/${i}/`;
//         if (i === 1) {
//             url = 'https://dudefilms.im/';
//         }

//         try {
//             let movies = await getMovies(url);
//             movies.map((movie: IMovie) => {
//                 if (!movie.writer) {
//                     console.log(movie);
//                 }
//             });
//             if (movies.length) {
//                 await MovieSchema.insertMany(movies);
//                 console.log(`Movies from page ${i} saved successfully.`);
//             }
//         } catch (error) {
//             console.error(`Error processing page ${i}:`, error);
//         }
//     }
// };

// fetchAndSaveMovies();

