import Joi from "joi";

export const validateUser = (data: any) => {
    const schema = Joi.object({
        name: Joi.string().required(),
        username: Joi.string().required(),
        password: Joi.string().min(6).required(),
        email: Joi.string().email().optional(),
        role: Joi.string().valid("owner", "manager", "staff").required(),
        avatar: Joi.string().optional(),
    });
    return schema.validate(data);
};

export const validateLogin = (data: any) => {
    const schema = Joi.object({
        username: Joi.string().required(),
        password: Joi.string().required(),
    });
    return schema.validate(data);
};
